package com.calcvault.app

enum class Role(val title: String, val files: Boolean, val admin: Boolean, val timeoutMs: Long) {
    ADMIN("مدیر", true, true, 30 * 60_000L),
    A("سطح A", true, false, 30 * 60_000L),
    M("سطح M", true, false, 30 * 60_000L),
    S("سطح S", false, false, 30 * 60_000L),
    TEMPORARY("موقت", false, false, 30 * 60_000L)
}
