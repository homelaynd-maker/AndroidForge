package com.calcvault.app

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.nio.ByteBuffer
import java.text.Normalizer
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val exec = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private var role: Role? = null
    private var picking = false
    private val lockTask = Runnable { lock() }

    // calculator state
    private var angle = Angle.DEG
    private var fmt = 0
    private var mem = 0.0
    private var ans = 0.0
    private val hist = ArrayList<String>()
    private val tracker = Gate.Tracker(this, exec, ui) { r -> enter(r) }

    private var image: Uri? = null
    private var carrier: Uri? = null
    private var file: Uri? = null
    private var onOpen: ((Uri) -> Unit)? = null
    private var onSave: ((Uri?) -> Unit)? = null

    private val openDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) onOpen?.invoke(u) }
    private val savePng = registerForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { u -> onSave?.invoke(u) }
    private val saveAny = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u -> onSave?.invoke(u) }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        showCalculator()
    }

    override fun onResume() { super.onResume(); picking = false }
    override fun onStop() { super.onStop(); if (!picking) lock() }
    override fun onDestroy() { exec.shutdownNow(); ui.removeCallbacks(lockTask); super.onDestroy() }
    @Deprecated("") override fun onBackPressed() { if (role != null) showDashboard() else super.onBackPressed() }

    private fun enter(r: Role) {
        role = r
        ui.removeCallbacks(lockTask); ui.postDelayed(lockTask, r.timeoutMs)
        showDashboard()
    }

    private fun lock() {
        ui.removeCallbacks(lockTask)
        if (role == null) return
        role = null; image = null; carrier = null; file = null; onOpen = null; onSave = null
        hist.clear(); mem = 0.0; ans = 0.0
        showCalculator()
    }

    // ---------- tiny UI kit ----------
    private val BG = 0xFF0B1211.toInt(); private val KEY = 0xFF172827.toInt()
    private val LINE = 0xFF38514D.toInt(); private val ACC = 0xFF287E6D.toInt(); private val RED = 0xFF613D45.toInt()
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, r: Int = 14) = GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(fill); setStroke(1, LINE) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun text(t: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun page(title: String): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        col.addView(text(title, 21f, true))
        val sv = ScrollView(this).apply { setBackgroundColor(BG); fitsSystemWindows = true; addView(col) }
        setContentView(sv)
        return col
    }

    private fun LinearLayout.btn(t: String, click: () -> Unit) {
        addView(Button(this@MainActivity).apply {
            text = t; isAllCaps = false; setTextColor(Color.WHITE); background = box(KEY)
            setOnClickListener { click() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun LinearLayout.back() = btn("↩ بازگشت") { showDashboard() }

    private fun field(hint: String, lines: Int) = EditText(this).apply {
        this.hint = hint; minLines = lines; gravity = Gravity.TOP; setTextColor(Color.WHITE)
        setHintTextColor(0xFF80908D.toInt()); background = box(0xFF111C1B.toInt())
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun LinearLayout.add(v: View) = addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

    private fun work(msg: String, block: () -> Unit) {
        toast(msg)
        exec.execute { try { block() } catch (e: Throwable) { ui.post { toast(e.message ?: "عملیات ناموفق بود.") } } }
    }

    // ---------- file helpers ----------
    private fun pick(mime: String, cb: (Uri) -> Unit) { onOpen = cb; picking = true; openDoc.launch(arrayOf(mime)) }
    private fun savePng(cb: (Uri?) -> Unit) { onSave = cb; picking = true; savePng.launch("IMG_${System.currentTimeMillis()}.png") }
    private fun saveAny(name: String, cb: (Uri?) -> Unit) { onSave = cb; picking = true; saveAny.launch(name) }

    private fun nameOf(u: Uri): String {
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "file"
        }
        return "file"
    }

    private fun copyToUri(src: File, dst: Uri) {
        contentResolver.openOutputStream(dst)?.use { o -> src.inputStream().use { it.copyTo(o, 64 * 1024) } } ?: error("مقصد قابل نوشتن نیست.")
    }

    // ---------- engineering calculator (the only thing visible by default) ----------
    private fun showCalculator() {
        tracker.reset()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(BG); fitsSystemWindows = true; layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val history = text("", 12f).apply { gravity = Gravity.END or Gravity.BOTTOM; setTextColor(0xFF8CA9A3.toInt()); maxLines = 3 }
        val status = text("", 11f).apply { gravity = Gravity.START; setTextColor(0xFF6FD3B8.toInt()) }
        val display = text("", 32f).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL; setSingleLine(); ellipsize = TextUtils.TruncateAt.START
            setPadding(dp(12), 0, dp(12), 0); background = box(0xFF111C1B.toInt(), 16)
        }
        root.addView(history, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(status, LinearLayout.LayoutParams(-1, dp(18)))
        root.addView(display, LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(4) })

        var second = false; var hyp = false; var justEvaluated = false
        val relabel = ArrayList<() -> Unit>()
        fun fmtName() = arrayOf("NORM", "SCI", "ENG")[fmt]
        fun refresh() {
            status.text = "${angle.name}  ${fmtName()}${if (mem != 0.0) "  M" else ""}${if (second) "  2nd" else ""}${if (hyp) "  hyp" else ""}"
            relabel.forEach { it() }
        }
        fun showHist() { history.text = hist.takeLast(3).joinToString("\n") }
        showHist(); refresh()

        fun put(t: String, token: String) {
            if (justEvaluated) {
                if (t[0] !in "+-*/%^!") display.text = ""
                justEvaluated = false
            }
            display.append(t); tracker.key(token)
        }
        fun curValue(): Double = try { Calc.eval(display.text.toString(), angle, ans) } catch (_: Exception) { ans }
        fun fn(base: String, token: String?) {
            val name = (if (second) "a" else "") + base + (if (hyp) "h" else "")
            put("$name(", if (!second && !hyp && token != null) token else "#")
            second = false; hyp = false; refresh()
        }
        fun equals() {
            val expr = display.text.toString()
            if (expr.isBlank()) return
            tracker.key("=")
            try {
                val v = Calc.eval(expr, angle, ans)
                ans = v
                val r = Calc.format(v, fmt)
                hist.add("$expr = $r"); showHist()
                display.text = r; justEvaluated = true; tracker.reset(); refresh()
            } catch (_: Exception) { status.text = "Error" }
        }

        fun row(weightRow: Float = 1f, build: LinearLayout.() -> Unit) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.build()
            root.addView(r, LinearLayout.LayoutParams(-1, 0, weightRow))
        }
        fun LinearLayout.key(a: String, b: String? = null, fill: Int = KEY, dyn: (() -> String)? = null, h: () -> Unit) {
            val tv = TextView(this@MainActivity).apply {
                gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = box(fill, 14)
                setOnClickListener { h() }
            }
            val upd = {
                val t = dyn?.invoke() ?: if (second && b != null) b else a
                tv.text = t; tv.textSize = if (t.length > 3) 13f else 17f
            }
            upd(); relabel.add(upd)
            addView(tv, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        fun LinearLayout.num(c: String) = key(c) { put(c, c) }
        fun LinearLayout.op(label: String, ins: String) = key(label) { put(ins, ins) }
        fun LinearLayout.sym(label: String, ins: String, alt: String? = null, altIns: String? = null) =
            key(label, alt) { val t = if (second && altIns != null) altIns else ins; put(t, "#"); second = false; refresh() }

        row { key("2nd", fill = ACC) { second = !second; refresh() }; key("hyp", fill = ACC) { hyp = !hyp; refresh() }
              key("", dyn = { angle.name }) { angle = Angle.values()[(angle.ordinal + 1) % 3]; refresh() }
              key("", dyn = { fmtName() }) { fmt = (fmt + 1) % 3; refresh() }
              key("AC", fill = RED) { display.text = ""; justEvaluated = false; tracker.clear(); refresh() } }
        row { key("sin", "sin\u207b\u00b9") { fn("sin", "Sin") }; key("cos", "cos\u207b\u00b9") { fn("cos", "Cos") }
              key("tan", "tan\u207b\u00b9") { fn("tan", "Tan") }; key("cot", "cot\u207b\u00b9") { fn("cot", "Cot") }
              key("\u232b", fill = RED) {
                  if (justEvaluated) { display.text = ""; justEvaluated = false }
                  else { val t = display.text.toString(); display.text = Regex("[a-zA-Z]+\\($").replace(t, "").let { if (it.length < t.length) it else t.dropLast(1) }; tracker.back() }
              } }
        row { sym("ln", "ln(", "e\u02e3", "exp("); sym("log", "log(", "10\u02e3", "10^(")
              sym("\u221a", "sqrt(", "\u221b", "cbrt("); sym("x\u00b2", "^2", "x\u00b3", "^3"); sym("x\u02b8", "^", "\u02b8\u221ax", "root(") }
        row { op("(", "("); op(")", ")"); sym("\u03c0", "\u03c0"); sym("e", "e"); sym("n!", "!", "|x|", "abs(") }
        row { num("7"); num("8"); num("9"); op("\u00f7", "/"); key("MC") { mem = 0.0; refresh() } }
        row { num("4"); num("5"); num("6"); op("\u00d7", "*"); key("MR") { put(Calc.format(mem, 0), "#") } }
        row { num("1"); num("2"); num("3"); op("\u2212", "-"); key("M+") { mem += curValue(); refresh() } }
        row { num("0"); num("."); op("%", "%"); op("+", "+"); key("M\u2212") { mem -= curValue(); refresh() } }
        row { sym("nCr", "nCr(", "nPr", "nPr("); sym("1/x", "1/("); sym(",", ","); sym("Ans", "Ans"); key("=", fill = ACC) { equals() } }
        setContentView(root)
    }

    // ---------- dashboard ----------
    private fun showDashboard() {
        val r = role ?: return showCalculator()
        val root = page("ابزارها")
        root.add(text("سطح دسترسی: ${r.title}", 13f))
        root.btn("🔐 رمزنگاری و رمزگشایی پیام") { showText() }
        root.btn("🔢 متن و Binary") { showBinary() }
        if (r.files) {
            root.btn("🖼️ پیام رمزنگاری‌شده داخل تصویر") { showMsgStego() }
            root.btn("📦 رمزنگاری فایل") { showFileCrypto() }
            root.btn("🖼️📦 فایل رمزنگاری‌شده داخل تصویر") { showFileStego() }
            root.btn("💬 اتاق پیام محلی") { showChat() }
        }
        if (r.admin) root.btn("⚙️ پنل مدیریت") { showAdmin() }
        root.btn("🛡️ وضعیت امنیتی") { showSecurity() }
        root.btn("🚪 خروج امن") { lock() }
    }

    private fun showText() {
        val root = page("🔐 رمزنگاری پیام")
        val input = field("متن (هر زبانی)…", 7); val output = field("خروجی…", 7)
        root.add(input); root.add(output)
        root.btn("🔐 رمزنگاری") {
            val t = Normalizer.normalize(input.text.toString(), Normalizer.Form.NFC)
            if (t.isBlank()) return@btn toast("متنی وارد نشده")
            work("در حال رمزنگاری…") { val e = Vault.encryptText(t); ui.post { output.setText(e) } }
        }
        root.btn("🔓 رمزگشایی") {
            val c = input.text.toString().ifBlank { output.text.toString() }
            work("در حال رمزگشایی…") { val p = Vault.decryptText(c); ui.post { output.setText(p) } }
        }
        root.btn("↔️ انتقال خروجی به ورودی") { input.setText(output.text) }
        root.btn("🧹 پاک کردن") { input.text.clear(); output.text.clear() }
        root.back()
    }

    private fun showBinary() {
        val root = page("🔢 متن و Binary")
        val input = field("ورودی…", 5); val output = field("نتیجه…", 8)
        root.add(input); root.add(output)
        root.btn("متن → Binary") {
            output.setText(input.text.toString().toByteArray(Charsets.UTF_8).joinToString(" ") {
                Integer.toBinaryString(it.toInt() and 255).padStart(8, '0')
            })
        }
        root.btn("Binary → متن") {
            try {
                val parts = input.text.toString().trim().split(Regex("\\s+"))
                output.setText(String(ByteArray(parts.size) { parts[it].toInt(2).toByte() }, Charsets.UTF_8))
            } catch (_: Exception) { toast("Binary نامعتبر است") }
        }
        root.back()
    }

    private fun showMsgStego() {
        val root = page("🖼️ پیام داخل تصویر")
        root.add(text("خروجی همیشه PNG است تا داده حفظ شود. ارسال تصویر از طریق پیام‌رسان‌ها (که فشرده می‌کنند) داده را خراب می‌کند؛ آن را به‌صورت «فایل» بفرستید.", 13f))
        val msg = field("پیام…", 6); root.add(msg)
        val status = text(if (image == null) "تصویری انتخاب نشده" else "تصویر انتخاب شد", 13f); root.add(status)
        root.btn("🖼️ انتخاب تصویر") { pick("image/*") { image = it; status.text = "تصویر انتخاب شد" } }
        root.btn("🔐 جاسازی و ذخیره PNG") {
            val img = image ?: return@btn toast("ابتدا تصویر را انتخاب کنید")
            val t = Normalizer.normalize(msg.text.toString(), Normalizer.Form.NFC)
            if (t.isBlank()) return@btn toast("پیامی وارد نشده")
            work("در حال جاسازی…") {
                val bm = Stego.decode(contentResolver, img)
                val blob = Vault.encryptBytes(t.toByteArray(Charsets.UTF_8), Vault.AAD_STEGO)
                val out = Stego.embed(bm, Stego.TYPE_TEXT, blob)
                ui.post { savePng { u -> if (u != null) work("در حال ذخیره…") { contentResolver.openOutputStream(u)?.use { o -> check(out.compress(Bitmap.CompressFormat.PNG, 100, o)) } ; ui.post { toast("ذخیره شد") } } } }
            }
        }
        root.btn("🔓 استخراج پیام") {
            val img = image ?: return@btn toast("ابتدا تصویر را انتخاب کنید")
            work("در حال استخراج…") {
                val (type, payload) = Stego.extract(Stego.decode(contentResolver, img))
                require(type == Stego.TYPE_TEXT) { "این تصویر حاوی فایل است نه پیام." }
                val plain = String(Vault.decryptBytes(payload, Vault.AAD_STEGO), Charsets.UTF_8)
                ui.post { msg.setText(plain); status.text = "پیام استخراج شد" }
            }
        }
        root.back()
    }

    private fun showFileCrypto() {
        val root = page("📦 رمزنگاری فایل")
        root.add(text("فایل به‌صورت جریانی پردازش می‌شود و کلید فقط روی همین دستگاه است؛ فایل رمزنگاری‌شده روی دستگاه دیگر یا بعد از حذف برنامه باز نمی‌شود.", 13f))
        root.btn("🔐 انتخاب فایل و رمزنگاری") {
            pick("*/*") { src ->
                val name = nameOf(src)
                work("در حال رمزنگاری…") {
                    val tmp = File(cacheDir, "enc_${System.nanoTime()}")
                    try {
                        contentResolver.openInputStream(src)!!.use { i -> tmp.outputStream().buffered().use { Vault.encryptStream(i, it) } }
                    } catch (e: Throwable) { tmp.delete(); throw e }
                    ui.post { saveAny("$name.cvf") { u -> finishSave(tmp, u) } }
                }
            }
        }
        root.btn("🔓 انتخاب فایل .cvf و رمزگشایی") {
            pick("*/*") { src ->
                val name = nameOf(src).removeSuffix(".cvf").ifBlank { "decrypted" }
                work("در حال رمزگشایی…") {
                    val tmp = File(cacheDir, "dec_${System.nanoTime()}")
                    try {
                        contentResolver.openInputStream(src)!!.use { i -> tmp.outputStream().buffered().use { Vault.decryptStream(i, it) } }
                    } catch (e: Throwable) { tmp.delete(); throw e }
                    ui.post { saveAny(name) { u -> finishSave(tmp, u) } }
                }
            }
        }
        root.back()
    }

    private fun finishSave(tmp: File, u: Uri?) {
        if (u == null) { tmp.delete(); return }
        work("در حال ذخیره…") { try { copyToUri(tmp, u) } finally { tmp.delete() }; ui.post { toast("ذخیره شد") } }
    }

    private fun showFileStego() {
        val root = page("🖼️📦 فایل داخل تصویر")
        val st = text("", 13f); root.add(st)
        fun refresh() { st.text = "فایل: ${if (file == null) "—" else "انتخاب شد"}  |  تصویر: ${if (carrier == null) "—" else "انتخاب شد"}" }
        refresh()
        root.btn("1) انتخاب فایل") { pick("*/*") { file = it; refresh() } }
        root.btn("2) انتخاب تصویر حامل") { pick("image/*") { carrier = it; refresh() } }
        root.btn("3) رمزنگاری، جاسازی و ذخیره PNG") {
            val f = file; val c = carrier
            if (f == null || c == null) return@btn toast("فایل و تصویر را انتخاب کنید")
            work("در حال پردازش…") {
                val bm = Stego.decode(contentResolver, c)
                val raw = contentResolver.openInputStream(f)!!.use { it.readBytes() }
                val name = nameOf(f).toByteArray(Charsets.UTF_8)
                require(name.size < 60000) { "نام فایل خیلی بلند است." }
                require(raw.size.toLong() + name.size + 100 <= Stego.maxPayload(bm)) { "ظرفیت تصویر (${Stego.maxPayload(bm)} بایت) کافی نیست." }
                val blob = Vault.encryptBytes(raw, Vault.AAD_STEGO)
                val payload = ByteBuffer.allocate(2 + name.size + blob.size).putShort(name.size.toShort()).put(name).put(blob).array()
                val out = Stego.embed(bm, Stego.TYPE_FILE, payload)
                ui.post { savePng { u -> if (u != null) work("در حال ذخیره…") { contentResolver.openOutputStream(u)?.use { o -> check(out.compress(Bitmap.CompressFormat.PNG, 100, o)) }; ui.post { toast("ذخیره شد") } } } }
            }
        }
        root.btn("4) استخراج فایل از تصویر") {
            pick("image/*") { img ->
                work("در حال استخراج…") {
                    val (type, payload) = Stego.extract(Stego.decode(contentResolver, img))
                    require(type == Stego.TYPE_FILE) { "این تصویر حاوی فایل نیست." }
                    val bb = ByteBuffer.wrap(payload)
                    val n = bb.short.toInt() and 0xFFFF
                    val nameBytes = ByteArray(n); bb.get(nameBytes)
                    val blob = ByteArray(bb.remaining()); bb.get(blob)
                    val plain = Vault.decryptBytes(blob, Vault.AAD_STEGO)
                    val tmp = File(cacheDir, "ext_${System.nanoTime()}"); tmp.writeBytes(plain)
                    val name = String(nameBytes, Charsets.UTF_8).replace(Regex("[\\\\/]"), "_").ifBlank { "extracted" }
                    ui.post { saveAny(name) { u -> finishSave(tmp, u) } }
                }
            }
        }
        root.back()
    }

    private fun showChat() {
        val root = page("💬 اتاق پیام محلی")
        val log = text("فقط روی همین دستگاه و فقط تا بسته شدن نشست در حافظه می‌ماند.", 14f); root.add(log)
        val input = field("پیام…", 2); root.add(input)
        root.btn("ارسال") { if (input.text.isNotBlank()) { log.append("\n\nشما: ${input.text}"); input.text.clear() } }
        root.back()
    }

    private fun showAdmin() {
        val root = page("⚙️ پنل مدیریت")
        root.add(text("قفل ورود: ${if (Gate.lockedForMs(this) > 0) "فعال" else "غیرفعال"}", 14f))
        root.btn("پاک‌سازی فایل‌های موقت") { cacheDir.listFiles()?.forEach { it.delete() }; toast("انجام شد") }
        root.back()
    }

    private fun showSecurity() {
        val root = page("🛡️ وضعیت امنیتی")
        root.add(text("• برنامه کاملاً آفلاین است و مجوز اینترنت ندارد\n• ضبط/اسکرین‌شات مسدود است\n• بکاپ غیرفعال است\n• کلید رمزنگاری در Android Keystore است و از دستگاه خارج نمی‌شود\n• با خروج از برنامه، قفل خودکار فعال می‌شود\n• ${role?.let { "خروج خودکار پس از ${it.timeoutMs / 60000} دقیقه" } ?: ""}", 14f))
        root.back()
    }
}
