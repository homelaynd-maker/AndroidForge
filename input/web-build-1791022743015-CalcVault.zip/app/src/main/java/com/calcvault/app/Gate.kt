package com.calcvault.app

import android.content.Context
import android.os.Handler
import java.security.MessageDigest
import java.util.concurrent.Executor
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Hidden entry. The unlock code is a KEY SEQUENCE (sin/cos/tan/cot keys count as "Sin"/"Cos"/"Tan"/"Cot",
 * other keys as themselves, "=" included). Only salted PBKDF2 hashes of the codes are stored.
 * A sequence must start right after AC / app start with one of the four function keys.
 */
object Gate {
    private const val PREFS = "gate_guard"
    private const val FREE_TRIES = 5
    private const val BASE_LOCK_MS = 30_000L
    private const val MAX_LOCK_MS = 15 * 60_000L
    const val MAX_SEQ = 24
    const val MIN_FAIL_LEN = 8
    val FUNCS = setOf("Sin", "Cos", "Tan", "Cot")

    fun hasLength(n: Int) = GateHashes.ENTRIES.any { it.len == n }

    fun lockedForMs(ctx: Context): Long {
        val until = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("until", 0L)
        return (until - System.currentTimeMillis()).coerceAtLeast(0L)
    }

    /** Blocking (PBKDF2): call off the UI thread. Wrong guesses are counted by the Tracker, not here. */
    fun verify(ctx: Context, seq: String): Role? {
        if (lockedForMs(ctx) > 0) return null
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        var hit: Role? = null
        for (e in GateHashes.ENTRIES) {
            if (e.len != seq.length || !seq.startsWith(e.prefix)) continue
            val h = f.generateSecret(PBEKeySpec(seq.toCharArray(), unhex(e.salt), GateHashes.ITER, 256)).encoded
            if (MessageDigest.isEqual(h, unhex(e.hash)) && hit == null) hit = Role.valueOf(e.role)
        }
        if (hit != null) ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        return hit
    }

    fun fail(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val n = p.getInt("fails", 0) + 1
        val ed = p.edit().putInt("fails", n)
        if (n >= FREE_TRIES) {
            val lock = (BASE_LOCK_MS shl (n - FREE_TRIES).coerceAtMost(10)).coerceAtMost(MAX_LOCK_MS)
            ed.putLong("until", System.currentTimeMillis() + lock)
        }
        ed.apply()
    }

    private fun unhex(s: String) = ByteArray(s.length / 2) {
        ((Character.digit(s[it * 2], 16) shl 4) or Character.digit(s[it * 2 + 1], 16)).toByte()
    }

    class Tracker(
        private val ctx: Context, private val exec: Executor, private val ui: Handler,
        private val onRole: (Role) -> Unit
    ) {
        private val tokens = ArrayList<String>()

        fun key(token: String) {
            if (token == "(" || token == ")") { tokens.clear(); return }       // real calculation, not a code
            if (tokens.isEmpty() && token !in FUNCS) return
            tokens.add(token)
            val seq = tokens.joinToString("")
            if (seq.length > MAX_SEQ) { fail(ctx); tokens.clear(); return }
            if (hasLength(seq.length)) exec.execute {
                val r = try { verify(ctx, seq) } catch (_: Throwable) { null }
                if (r != null) ui.post { tokens.clear(); onRole(r) }
            }
        }

        fun back() { if (tokens.isNotEmpty()) tokens.removeAt(tokens.size - 1) }

        /** AC pressed: an abandoned long sequence counts as one failed attempt. */
        fun clear() {
            if (tokens.joinToString("").length >= MIN_FAIL_LEN) fail(ctx)
            tokens.clear()
        }

        /** Silent reset (valid calculation finished, lock, start-up). */
        fun reset() = tokens.clear()
    }
}
