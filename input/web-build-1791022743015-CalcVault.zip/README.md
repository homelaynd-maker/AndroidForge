# CalcVault - engineering calculator with hidden vault

Opens straight to a scientific/engineering calculator named "Calculator". No setup screen. applicationId `com.calcvault.app`.

Calculator: + - x / mod(%), ^ , !, parentheses (auto-closed), implicit multiplication, sin/cos/tan/cot + inverse (2nd) + hyperbolic (hyp),
ln, log, log2-style via 10^x/e^x, sqrt/cbrt/x^y/y-th root, nCr, nPr, |x|, 1/x, pi, e, Ans, memory (MC MR M+ M-),
DEG/RAD/GRAD, NORM/SCI/ENG display, 3-line history, EE-style input (1.5E3).

Unlock (original default codes, levels unchanged): press AC, then type the keys exactly (sin/cos/tan/cot keys, no 2nd/hyp):
 ADMIN  Sin + - * / 1 1 5 1 % = 1 3 6 8
 A      Tan / + - * % = 5 7
 M      Cot * + % / - = 2 2
 S      Cos + * % - / = 0 1
 TEMP   Cos + % % = 0
Levels: S/TEMP = message crypto + Binary. A/M = + image stego, file crypto, file-in-image, local chat. ADMIN = + admin panel. 30 min auto-lock; leaving the app locks it.
Abandoned/overlong attempts count as failures: 5 -> 30 s lock, doubling up to 15 min.
Change codes: tools/make_hashes.py. Build: Android Studio or `gradle assembleRelease` (SDK 35, JDK 17).
