package com.securestudio.v1

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.media.MediaPlayer
import android.widget.VideoView
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("secure_studio", MODE_PRIVATE) }
    private val rooms = mutableListOf<String>()
    private var currentRoom = "عمومی"
    private val chatCache = mutableMapOf<String, MutableList<String>>()
    private val ADMIN_TRIGGER = "Sin+-%/*1151=68"
    private val ADMIN_TRIGGER_HASH = "BI9bLrfBLKhdm8A2Ot/p1+bKumBencZNZpou1SzhSc4="
    private val ACCESS_CODE_A = "Tan+*-%=57"
    private val ACCESS_CODE_M = "Cot/*+%-=22"
    private val ACCESS_CODE_S = "Cos-*%/+=01"
    private val DEFAULT_GATE_ENABLED = false
    private var pendingImage: Bitmap? = null
    private var pendingMessage: String = ""
    private val PICK_IMAGE = 1001
    private val PICK_LOGO = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rooms.addAll(prefs.getStringSet("rooms", setOf("عمومی"))!!.toList().sorted())
        if (rooms.isEmpty()) rooms.add("عمومی")
        currentRoom = rooms.first()
        // نسخه تستی بدون ورودی و رمز: برنامه مستقیماً با دسترسی کامل باز می‌شود.
        // هیچ کد، PIN یا صفحه احراز هویتی در شروع برنامه نمایش داده نمی‌شود.
        prefs.edit()
            .putBoolean("program_unlocked", true)
            .putBoolean("admin_session", true)
            .putString("license_prefix", "a")
            .remove("temporary_session")
            .apply()
        showEngineeringCalculator()
    }

    private fun showFirstRunSetup() {
        val box = page("🔐 راه‌اندازی اولیه برنامه")
        box.addView(TextView(this).apply {
            text = "در اولین اجرا، خودتان رمز مدیر را تعیین کنید. این برنامه هیچ رمز پیش‌فرضی ندارد و رمز مدیر در صفحه ورود نمایش داده نمی‌شود. رمز را در جای امن نگه دارید؛ سپس مدیر می‌تواند برای کاربران کد دائمی یا موقت صادر کند."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val input = EditText(this).apply {
            hint = "رمز مدیر: ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val question = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(
                "نام اولین مدرسه شما چه بود؟",
                "نام اولین شهر محل زندگی شما چه بود؟",
                "نام یک دوست دوران کودکی شما چه بود؟",
                "غذای مورد علاقه شما چیست؟"
            ))
        }
        val answer = EditText(this).apply { hint = "پاسخ سؤال امنیتی را وارد کنید" }
        btn(box, "💾 ثبت رمز مدیر و سؤال امنیتی") {
            val p = input.text.toString()
            val a = answer.text.toString().trim()
            if (!validAdminPassword(p)) {
                toast("رمز مدیر باید ۸ تا ۲۲ کاراکتر و دارای حداقل ۲ نماد باشد.")
            } else if (a.length < 2) {
                toast("پاسخ سؤال امنیتی را وارد کنید.")
            } else {
                prefs.edit().putString("admin_password", hash(p))
                    .putInt("security_question", question.selectedItemPosition)
                    .putString("security_answer", hash(a))
                    .putBoolean("program_unlocked", true).putBoolean("admin_session", true).remove("license_prefix").apply()
                showAdminPanel()
            }
        }
        box.addView(input, 1)
        box.addView(TextView(this).apply { text = "سؤال امنیتی بازیابی رمز"; setTextColor(0xFFEAF7F4.toInt()); setPadding(0,12,0,6) })
        box.addView(question)
        box.addView(answer)
        setContentView(box)
    }

    private fun showProgramAccessGate() { showEngineeringCalculator() }

    private fun showEngineeringCalculator() {
        val box = page("🧮 ماشین حساب مهندسی")
        box.addView(TextView(this).apply {
            text = "ماشین حساب مهندسی است. برای ورود به امکانات برنامه، کدهای تعریف‌شده را دقیقاً با همین کلیدها وارد و با = تأیید کنید. حروف بزرگ/کوچک و ترتیب نمادها مهم است."
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 0, 0, 12)
        })
        val display = EditText(this).apply {
            hint = "عدد یا عبارت ریاضی"
            textSize = 22f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            gravity = Gravity.END
        }
        box.addView(display)

        val history = TextView(this).apply {
            text = "تاریخچه: —"
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 6, 0, 12)
        }
        box.addView(history)

        fun key(label: String, value: String = label) { btn(box, label) { display.append(value) } }
        key("Sin", "Sin"); key("Cos", "Cos"); key("Tan", "Tan"); key("Cot", "Cot")
        key("7"); key("8"); key("9"); key("÷", "/")
        key("4"); key("5"); key("6"); key("×", "*")
        key("1"); key("2"); key("3"); key("−", "-")
        key("0"); key("."); key("%"); key("+", "+")
        key("("); key(")")

        btn(box, "π  عدد پی") { display.setText("${Math.PI}") }
        btn(box, "e  عدد نپر") { display.setText("${Math.E}") }
        btn(box, "√  جذر") { applyUnary(display, history, "√") { Math.sqrt(it) } }
        btn(box, "x²  مربع") { applyUnary(display, history, "x²") { it * it } }
        btn(box, "1/x  معکوس") { applyUnary(display, history, "1/x") { if (it == 0.0) throw ArithmeticException() else 1.0 / it } }
        btn(box, "sin  سینوس") { applyUnary(display, history, "sin") { Math.sin(Math.toRadians(it)) } }
        btn(box, "cos  کسینوس") { applyUnary(display, history, "cos") { Math.cos(Math.toRadians(it)) } }
        btn(box, "tan  تانژانت") { applyUnary(display, history, "tan") { Math.tan(Math.toRadians(it)) } }
        btn(box, "cot  کتانژانت") { applyUnary(display, history, "cot") { val t = Math.tan(Math.toRadians(it)); if (kotlin.math.abs(t) < 1e-12) throw ArithmeticException() else 1.0 / t } }
        btn(box, "log  لگاریتم دهدهی") { applyUnary(display, history, "log") { if (it <= 0) throw ArithmeticException() else Math.log10(it) } }
        btn(box, "ln  لگاریتم طبیعی") { applyUnary(display, history, "ln") { if (it <= 0) throw ArithmeticException() else Math.log(it) } }

        btn(box, "⌫ حذف یک رقم") {
            if (display.text.isNotEmpty()) display.text.delete(display.text.length - 1, display.text.length)
        }
        btn(box, "🧹 پاک کردن همه") { display.setText(""); history.text = "تاریخچه: —" }
        btn(box, "=  محاسبه / ورود") {
            val expr = display.text.toString().trim()
            when {
                expr == ADMIN_TRIGGER || hash(expr) == ADMIN_TRIGGER_HASH -> {
                    prefs.edit().putBoolean("program_unlocked", true).putBoolean("admin_session", true)
                        .remove("license_prefix").remove("temporary_session").apply()
                    history.text = "کد مدیر شناسایی شد"
                    showAdminLogin()
                }
                expr == ACCESS_CODE_A -> {
                    history.text = "کد سطح a شناسایی شد"
                    openUserAfterCode("a", false)
                }
                expr == ACCESS_CODE_M -> {
                    history.text = "کد سطح m شناسایی شد"
                    openUserAfterCode("m", false)
                }
                expr == ACCESS_CODE_S -> {
                    history.text = "کد سطح s شناسایی شد"
                    openUserAfterCode("s", false)
                }
                else -> {
                    val result = evaluateEngineeringCalculator(expr)
                    if (result != null) {
                        history.text = "تاریخچه: $expr = $result"
                        display.setText(result)
                    } else toast("عبارت ریاضی یا کد ورود نامعتبر است.")
                }
            }
        }

        box.addView(TextView(this).apply {
            text = "کدهای ورود:
مدیر: Sin+-%/*1151=68
سطح a: Tan+*-%=57
سطح m: Cot/*+%-=22
سطح s: Cos-*%/+=01"
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 10, 0, 12)
        })
        setContentView(box)
    }

    private fun applyUnary(display: EditText, history: TextView, label: String, operation: (Double) -> Double) {
        val value = display.text.toString().trim().toDoubleOrNull()
        if (value == null) { toast("ابتدا یک عدد وارد کنید."); return }
        try {
            val result = operation(value)
            if (!result.isFinite()) throw ArithmeticException()
            val shown = result.toString()
            history.text = "تاریخچه: $label($value) = $shown"
            display.setText(shown)
        } catch (_: Exception) { toast("محاسبه برای این عدد امکان‌پذیر نیست.") }
    }

    private fun evaluateEngineeringCalculator(expr: String): String? {
        if (expr.isBlank()) return null
        if (expr.any { !(it.isDigit() || it in "+-*/%.() ") }) return null
        return try {
            val normalized = expr.replace("%", "/100")
            val tokens = Regex("(?<=[+\\-*/()])|(?=[+\\-*/()])")
                .split(normalized).map { it.trim() }.filter { it.isNotEmpty() }
            val vals = java.util.ArrayDeque<Double>()
            val ops = java.util.ArrayDeque<Char>()
            fun prec(c: Char) = if (c == '+' || c == '-') 1 else 2
            fun apply() {
                if (vals.size < 2 || ops.isEmpty()) throw ArithmeticException()
                val b = vals.removeLast(); val a = vals.removeLast()
                when (ops.removeLast()) {
                    '+' -> vals.addLast(a + b)
                    '-' -> vals.addLast(a - b)
                    '*' -> vals.addLast(a * b)
                    '/' -> { if (b == 0.0) throw ArithmeticException(); vals.addLast(a / b) }
                    else -> throw ArithmeticException()
                }
            }
            for (t in tokens) {
                when {
                    t.matches(Regex("[0-9]+(?:\\.[0-9]+)?")) -> vals.addLast(t.toDouble())
                    t == "(" -> ops.addLast('(')
                    t == ")" -> {
                        while (ops.isNotEmpty() && ops.peekLast() != '(') apply()
                        if (ops.isEmpty()) throw ArithmeticException()
                        ops.removeLast()
                    }
                    t.length == 1 && t[0] in "+-*/" -> {
                        while (ops.isNotEmpty() && ops.peekLast() != '(' && prec(ops.peekLast()) >= prec(t[0])) apply()
                        ops.addLast(t[0])
                    }
                    else -> throw ArithmeticException()
                }
            }
            while (ops.isNotEmpty()) { if (ops.peekLast() == '(') throw ArithmeticException(); apply() }
            if (vals.size != 1) throw ArithmeticException()
            val result = vals.peekLast()
            if (!result.isFinite()) throw ArithmeticException()
            result.toString()
        } catch (_: Exception) { null }
    }

    private fun openUserAfterCode(prefix:String,temporary:Boolean){
        prefs.edit().putBoolean("program_unlocked",true).putBoolean("admin_session",false).putString("license_prefix",prefix).putBoolean("temporary_session",temporary).apply();showUserPasswordLogin(prefix,temporary)
    }

    private fun showUserPasswordLogin(prefix:String,temporary:Boolean){
        val key="user_password_$prefix"; val existing=prefs.getString(key,null)
        if(existing==null){
            val box=page("🔐 تنظیم رمز شخصی");box.addView(TextView(this).apply{text="رمز شخصی ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد باشد. این رمز سطح دسترسی را تغییر نمی‌دهد.";setTextColor(0xFF9FCBC1.toInt())})
            val p1=EditText(this).apply{hint="رمز جدید";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val p2=EditText(this).apply{hint="تکرار رمز";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            btn(box,"💾 ثبت"){val a=p1.text.toString();if(!validAdminPassword(a))toast("رمز باید ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد داشته باشد.")else if(a!=p2.text.toString())toast("دو رمز یکسان نیستند.")else{prefs.edit().putString(key,hash(a)).apply();showHome()}};box.addView(p1);box.addView(p2);setContentView(box);return
        }
        val input=EditText(this).apply{hint="رمز شخصی";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};AlertDialog.Builder(this).setTitle("🔐 ورود کاربر $prefix").setView(input).setNegativeButton("انصراف",null).setPositiveButton("ورود"){_,_->if(hash(input.text.toString())==existing)showHome()else toast("رمز شخصی نادرست است.")}.show()
    }

    private fun page(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(0xFF0B1412.toInt())
        layoutParams = ViewGroup.LayoutParams(-1, -1)
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 25f; setTextColor(0xFFEAF7F4.toInt()); setPadding(0, 8, 0, 18)
        })
    }

    private fun btn(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            isEnabled = true
            alpha = 1.0f
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun back(parent: LinearLayout) = btn(parent, "← بازگشت") { showHome() }

    private fun showHome() {
        val root = page("")
        val branding = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 10)
        }
        val logo = ImageView(this).apply {
            val uri = prefs.getString("app_logo_uri", null)
            if (!uri.isNullOrBlank()) {
                try { setImageURI(Uri.parse(uri)) } catch (_: Exception) { setImageResource(android.R.drawable.ic_lock_lock) }
            } else setImageResource(android.R.drawable.ic_lock_lock)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        branding.addView(logo, LinearLayout.LayoutParams(64,64).apply { marginEnd = 12 })
        branding.addView(TextView(this).apply {
            text = prefs.getString("app_display_name", "Secure Studio")
            textSize = 28f; setTextColor(0xFFEAF7F4.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(branding, 1)
        root.addView(TextView(this).apply {
            text = if (prefs.getBoolean("admin_session", false)) "سطح دسترسی: مدیر (کامل)" else "سطح دسترسی: ${prefs.getString("license_prefix", "")}"
            textSize = 14f; setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,18)
        }, 2)

        val prefix = if (prefs.getBoolean("admin_session", false)) "a" else (prefs.getString("license_prefix", "") ?: "")
        fun allowed(area:String) = when(prefix) {
            "s" -> area == "crypto" || area == "binary"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary"
            "a" -> true
            else -> false
        }
        if (allowed("crypto")) btn(root, "🔐 رمزنگاری / رمزگشایی متن") { showCrypto() }
        if (allowed("chat")) btn(root, "💬 اتاق‌های پیام خصوصی") { showChat() }
        if (allowed("image")) btn(root, "🖼️ پیام رمزگذاری‌شده داخل تصویر") { showStego() }
        if (allowed("binary")) btn(root, "💻 متن ↔ Binary") { showBinary() }
        btn(root, "🛡️ قفل برنامه و امنیت") { showSecurity() }
        if (prefix == "a") {
            btn(root, "📸 ویرایشگر تصویر") { showImageEditor() }
            btn(root, "🎬 ویرایشگر ویدیو") { showVideoEditor() }
            btn(root, "🎵 ویرایشگر صوت") { showAudioEditor() }
            btn(root, "🌐 مترجم آفلاین") { showTranslator() }
            btn(root, "🎙️ ابزار صوت و گفتار") { showVoiceTools() }
        }
        if (!prefs.getBoolean("admin_session", false)) btn(root, "🔑 تغییر رمز شخصی") { changeUserPassword() }
        btn(root, "🚪 بازگشت به صفحه اصلی") { showHome() }
        setContentView(root)
    }

    private fun requireSecure(area: String, onSuccess: () -> Unit) {
        val prefix = if (prefs.getBoolean("admin_session", false)) "a" else (prefs.getString("license_prefix", "") ?: "")
        val allowed = when (prefix) {
            "s" -> area == "crypto" || area == "binary"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary"
            "a" -> true
            else -> false
        }
        if (allowed) { onSuccess(); return }
        showProgramAccessGate()
    }

    private fun areaTitle(area: String) = when(area) {
        "crypto" -> "رمزنگاری پیام"
        "chat" -> "پیام‌های خصوصی"
        "image" -> "پیام مخفی در تصویر"
        "binary" -> "رمزنگاری و Binary"
        else -> "بخش محافظت‌شده"
    }

    private fun showCrypto() {
        val box = page("🔐 رمزنگاری متن")
        val input = EditText(this).apply { hint = "متن یا متن رمزگذاری‌شده"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"🔐 رمزنگاری") {
            val value = input.text.toString()
            if (value.isBlank()) {
                toast("متن را وارد کنید.")
            } else {
                try {
                    output.setText(encrypt(value))
                    toast("رمزنگاری با موفقیت انجام شد.")
                } catch (e: Exception) {
                    output.setText("")
                    toast("خطا در رمزنگاری: ${e.message ?: "خطای نامشخص"}")
                }
            }
        }
        btn(box,"🔓 رمزگشایی") {
            // اگر کاربر بلافاصله بعد از رمزنگاری روی رمزگشایی بزند، ciphertext داخل خروجی است.
            // بنابراین ابتدا ورودی و در صورت خالی بودن آن، خروجی را امتحان می‌کنیم.
            val candidate = input.text.toString().trim().ifBlank { output.text.toString().trim() }
            if (candidate.isBlank()) {
                toast("متن رمزنگاری‌شده را وارد کنید یا ابتدا رمزنگاری کنید.")
            } else {
                try {
                    val plain = decrypt(candidate)
                    output.setText(plain)
                    toast("رمزگشایی با موفقیت انجام شد.")
                } catch (e: Exception) {
                    toast("رمزگشایی ناموفق؛ متن رمزنگاری‌شده معتبر نیست یا با این دستگاه تولید نشده است.")
                }
            }
        }
        btn(box,"↔️ انتقال خروجی به ورودی") {
            val value = output.text.toString()
            if (value.isBlank()) toast("خروجی خالی است.") else { input.setText(value); toast("خروجی به ورودی منتقل شد.") }
        }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input, 1); box.addView(output, 6); back(box); setContentView(box)
    }

    private fun showBinary() {
        val box = page("💻 متن و Binary")
        val input = EditText(this).apply { hint = "متن یا Binary با فاصله"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"متن → Binary") { output.setText(input.text.toString().toByteArray(StandardCharsets.UTF_8).joinToString(" ") { String.format("%8s", Integer.toBinaryString(it.toInt() and 255)).replace(' ','0') }) }
        btn(box,"Binary → متن") { try { output.setText(String(input.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.toInt(2).toByte() }.toByteArray(), StandardCharsets.UTF_8)) } catch (_: Exception) { output.setText("Binary معتبر نیست.") } }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input,1); box.addView(output,6); back(box); setContentView(box)
    }

    private fun showChat() {
        val box = page("💬 اتاق‌های پیام خصوصی")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rooms)
        spinner.setSelection(rooms.indexOf(currentRoom).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { currentRoom = rooms[pos]; refreshChat() }
        }
        box.addView(TextView(this).apply { text="اتاق فعلی"; setTextColor(0xFFEAF7F4.toInt()) })
        box.addView(spinner)
        val messages = TextView(this).apply { minHeight=260; setTextColor(0xFFEAF7F4.toInt()); setPadding(8,16,8,16) }
        val input = EditText(this).apply { hint="پیام" }
        val send = Button(this).apply { text="ارسال رمزگذاری‌شده"; isAllCaps=false }
        send.setOnClickListener {
            val msg=input.text.toString(); if(msg.isNotBlank()) { val list=chatCache.getOrPut(currentRoom){mutableListOf()}; list.add("شما: "+encrypt(msg)); input.text.clear(); refreshChat(messages) }
        }
        btn(box,"➕ ساخت اتاق جدید") { createRoomAndRefresh() }
        box.addView(messages); box.addView(input); box.addView(send); back(box)
        refreshChat(messages); setContentView(box)
    }

    private fun refreshChat(target: TextView? = null) {
        val t = target ?: return
        val list=chatCache.getOrPut(currentRoom){mutableListOf()}
        t.text = if(list.isEmpty()) "این اتاق هنوز پیامی ندارد." else list.joinToString("\n\n")
    }

    private fun createRoomAndRefresh() {
        val input=EditText(this).apply { hint="نام اتاق" }
        AlertDialogBuilder("ساخت اتاق", input) { val n=input.text.toString().trim(); if(n.isNotEmpty()&&!rooms.contains(n)){rooms.add(n);prefs.edit().putStringSet("rooms",rooms.toSet()).apply();currentRoom=n;showChat()} }.show()
    }

    private fun showStego() {
        val box=page("🖼️ پیام رمزگذاری‌شده داخل تصویر")
        val message=EditText(this).apply{hint="پیامی که باید داخل تصویر قرار بگیرد";minLines=4;gravity=48}
        val info=TextView(this).apply{text="برای حفظ کیفیت، خروجی به PNG ذخیره می‌شود. تصویر اصلی تغییر محتوایی قابل مشاهده ندارد.";setTextColor(0xFF9FCBC1.toInt())}
        btn(box,"📂 انتخاب تصویر و جاسازی پیام"){pendingMessage=message.text.toString(); if(pendingMessage.isBlank()){toast("ابتدا پیام را وارد کنید.")}else{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE)}}
        btn(box,"📂 انتخاب تصویر و استخراج پیام"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/png";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE+1)}
        box.addView(message,1);box.addView(info,2);back(box);setContentView(box)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!
        if(requestCode==PICK_LOGO){
            try{
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }catch(_:Exception){}
            prefs.edit().putString("app_logo_uri",uri.toString()).apply()
            toast("لوگوی برنامه ذخیره شد.")
            showHome()
        } else if(requestCode==PICK_MEDIA_IMAGE){
            val bmp=loadBitmap(uri); if(bmp==null){toast("تصویر قابل خواندن نیست.");return}; selectedImageBitmap=bmp; showImageEditor()
        } else if(requestCode==PICK_MEDIA_VIDEO){
            // VideoView is created by the screen; reopen screen and store URI for future expansion.
            selectedMediaUri=uri; showVideoEditor(); toast("ویدیو انتخاب شد؛ برای پخش مستقیم دوباره انتخاب لازم است.")
        } else if(requestCode==PICK_AUDIO_ENCRYPT){
            encryptAudio(uri); showAudioEditor()
        } else if(requestCode==PICK_AUDIO_DECRYPT){
            decryptAudio(uri); showAudioEditor()
        } else if(requestCode==PICK_MEDIA_AUDIO){
            try{audioPlayer?.release();audioPlayer=MediaPlayer.create(this,uri);showAudioEditor();toast("فایل صوتی آماده پخش است.")}catch(_:Exception){toast("فایل صوتی قابل پخش نیست.")}
        } else if(requestCode==PICK_IMAGE){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{saveBitmap(embedMessage(bmp,pendingMessage))}catch(e:Exception){toast("خطا: ظرفیت تصویر کافی نیست یا فرمت مناسب نیست.")}}
        else if(requestCode==PICK_IMAGE+1){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{showExtracted(decrypt(extractMessage(bmp)))}catch(e:Exception){toast("پیام رمزگذاری‌شده معتبری در تصویر پیدا نشد.")}}
    }

    private fun embedMessage(src: Bitmap, text: String): Bitmap {
        val data = encrypt(text).toByteArray(StandardCharsets.UTF_8)
        val payload = ByteBuffer.allocate(4 + data.size).putInt(data.size).put(data).array()
        val capacity = src.width * src.height * 3
        require(payload.size * 8 <= capacity)

        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        var bit = 0
        for (y in 0 until out.height) {
            for (x in 0 until out.width) {
                val pixel = out.getPixel(x, y)
                val channels = intArrayOf(
                    (pixel shr 16).and(255),
                    (pixel shr 8).and(255),
                    pixel.and(255)
                )
                for (channel in 0..2) {
                    if (bit < payload.size * 8) {
                        val byteValue = payload[bit / 8].toInt().and(255)
                        val bitValue = (byteValue shr (7 - (bit % 8))).and(1)
                        channels[channel] = channels[channel].and(254).or(bitValue)
                        bit++
                    }
                }
                out.setPixel(x, y, (0xFF000000.toInt() or (channels[0] shl 16) or (channels[1] shl 8) or channels[2]))
                if (bit >= payload.size * 8) return out
            }
        }
        return out
    }

    private fun extractMessage(bmp: Bitmap): String {
        val bits = ArrayList<Int>()
        for (y in 0 until bmp.height) {
            for (x in 0 until bmp.width) {
                val pixel = bmp.getPixel(x, y)
                bits.add((pixel shr 16).and(1))
                bits.add((pixel shr 8).and(1))
                bits.add(pixel.and(1))
            }
        }

        fun readInt(start: Int): Int {
            var value = 0
            for (i in 0 until 32) {
                value = value.shl(1).or(bits[start + i])
            }
            return value
        }

        require(bits.size >= 32)
        val length = readInt(0)
        require(length > 0 && length < 10_000_000 && 32 + length * 8 <= bits.size)

        val out = ByteArray(length)
        for (i in 0 until length) {
            var value = 0
            for (j in 0 until 8) {
                value = value.shl(1).or(bits[32 + i * 8 + j])
            }
            out[i] = value.toByte()
        }
        return String(out, StandardCharsets.UTF_8)
    }
    private fun saveBitmap(bmp:Bitmap){val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"SecureStudio_${System.currentTimeMillis()}.png");put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/SecureStudio")};val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:throw Exception();contentResolver.openOutputStream(uri)!!.use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)};toast("تصویر در Pictures/SecureStudio ذخیره شد.")}
    private fun loadBitmap(uri:Uri):Bitmap?=contentResolver.openInputStream(uri).use{BitmapFactory.decodeStream(it)}

    private fun changeUserPassword(){val prefix=prefs.getString("license_prefix",null)?:return;val box=page("🔑 تغییر رمز شخصی");val p1=EditText(this).apply{hint="رمز جدید";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val p2=EditText(this).apply{hint="تکرار رمز";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};btn(box,"💾 ذخیره"){val a=p1.text.toString();if(!validAdminPassword(a))toast("رمز باید ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد داشته باشد.")else if(a!=p2.text.toString())toast("دو رمز یکسان نیستند.")else{prefs.edit().putString("user_password_$prefix",hash(a)).putBoolean("admin_session",false).putString("license_prefix",prefix).apply();toast("رمز تغییر کرد؛ سطح دسترسی $prefix حفظ شد.");showHome()}};box.addView(p1);box.addView(p2);back(box);setContentView(box)}

    private fun showSecurity(){
        val box=page("🛡️ امنیت برنامه")
        val status=TextView(this).apply{setTextColor(0xFFEAF7F4.toInt())}
        status.text=if(prefs.contains("pin"))"قفل PIN فعال است." else "قفل PIN هنوز تنظیم نشده است."
        btn(box,"🔑 تنظیم / تغییر PIN"){setPin()}
        btn(box,"🗑️ حذف PIN"){prefs.edit().remove("pin").apply();status.text="قفل PIN غیرفعال شد."}
        btn(box,"🔒 آزمایش قفل"){if(prefs.contains("pin"))verifyPin()else toast("ابتدا PIN تنظیم کنید.")}
        btn(box,"👑 ورود به پنل مدیریت"){showAdminLogin()}
        box.addView(status,1); back(box); setContentView(box)
    }

    private fun showAdminLogin(){
        if(!prefs.contains("admin_password")){
            val first=EditText(this).apply{hint="رمز مدیر، حداقل 8 و حداکثر 22 کاراکتر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            AlertDialogBuilder("👑 ایجاد رمز اولیه مدیر",first){val p=first.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).putBoolean("admin_session", true).putBoolean("program_unlocked", true).apply();toast("رمز مدیر ثبت شد. آن را در جای امن نگه دارید.");showAdminPanel()}else toast("رمز باید 8 تا 22 کاراکتر و دارای حداقل 2 نماد باشد.")}.show()
            return
        }
        val input=EditText(this).apply{hint="رمز ورود پنل مدیر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        android.app.AlertDialog.Builder(this).setTitle("🔐 ورود مدیر").setView(input)
            .setNegativeButton("فراموشی رمز"){_,_->showAdminRecovery()}
            .setPositiveButton("ورود"){_,_->if(hash(input.text.toString())==prefs.getString("admin_password",null)){prefs.edit().putBoolean("admin_session",true).putBoolean("program_unlocked",true).remove("license_prefix").apply();showAdminPanel()}else toast("رمز مدیر نادرست است.")}
            .show()
    }

    private fun showAdminRecovery(){
        val qIndex = prefs.getInt("security_question", 0)
        val questions = listOf(
            "نام اولین مدرسه شما چه بود؟",
            "نام اولین شهر محل زندگی شما چه بود؟",
            "نام یک دوست دوران کودکی شما چه بود؟",
            "غذای مورد علاقه شما چیست?"
        )
        val box=page("🛡️ بازیابی رمز مدیر")
        box.addView(TextView(this).apply{
            text = "سؤال امنیتی ثبت‌شده:\n${questions.getOrElse(qIndex){questions[0]}}"
            setTextColor(0xFFEAF7F4.toInt()); setPadding(0,0,0,16)
        })
        val answer=EditText(this).apply{hint="پاسخ سؤال امنیتی"}
        val newPass=EditText(this).apply{hint="رمز جدید مدیر: ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        // تنظیم نوع ورودی جداگانه برای جلوگیری از نمایش رمز در صفحه
        newPass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        btn(box,"🔓 بازیابی و تعیین رمز جدید"){
            val a=answer.text.toString().trim(); val p=newPass.text.toString()
            if(hash(a)==prefs.getString("security_answer",null) && validAdminPassword(p)){
                prefs.edit().putString("admin_password",hash(p)).apply()
                toast("رمز مدیر با موفقیت تغییر کرد."); showAdminLogin()
            } else if(hash(a)!=prefs.getString("security_answer",null)) toast("پاسخ سؤال امنیتی نادرست است.")
            else toast("رمز جدید باید ۸ تا ۲۲ کاراکتر و دارای حداقل ۲ نماد باشد.")
        }
        box.addView(answer); box.addView(newPass); back(box); setContentView(box)
    }

    private fun showAdminPanel(){
        if(!prefs.getBoolean("admin_session",false)){toast("دسترسی مدیر فقط برای جلسه مدیر مجاز است.");showEngineeringCalculator();return}
        val box=page("👑 پنل مدیریت ویژه")
        box.addView(TextView(this).apply{text="مدیر از اینجا می‌تواند کدهای دسترسی دائمی یا یک‌بارمصرف برای کاربران صادر کند. پیشوند کد سطح دسترسی را مشخص می‌کند: s، m یا a.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)})
        btn(box,"🎨 تغییر نام و لوگوی برنامه"){showBrandingSettings()}
        btn(box,"🔄 تغییر رمز مدیر"){changeAdminPassword()}
        btn(box,"🛡️ تغییر سؤال امنیتی"){changeSecurityQuestion()}
        btn(box,"🔓 خروج از برنامه و بازگشت به صفحه ورود"){prefs.edit().putBoolean("program_unlocked",false).remove("license_prefix").remove("temporary_session").remove("admin_session").apply();showProgramAccessGate()}
        back(box); setContentView(box)
    }

    private fun showLicenseGenerator(){
        val box=page("🔑 صدور رمز دائمی کاربر")
        box.addView(TextView(this).apply{
            text="این نسخه کاملاً آفلاین است. برنامه دارای ۱۰۰۰ رمز دائمی از پیش‌قرارگرفته است و هر رمز مستقل از گوشی مدیر روی دستگاه‌های دیگر همین نسخه نیز قابل شناسایی است.\n\nسطح‌ها:\ns = پیام + Binary: ۴۰۰ رمز\nm = پیام + چت + تصویر + Binary: ۳۵۰ رمز\na = دسترسی کامل: ۲۵۰ رمز"
            setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)
        })
        val type=Spinner(this)
        type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(
            "s — پیام + Binary (۴۰۰ رمز)",
            "m — چهار بخش اصلی (۳۵۰ رمز)",
            "a — دسترسی کامل (۲۵۰ رمز)"
        ))
        box.addView(TextView(this).apply{text="سطح دسترسی";setTextColor(0xFFEAF7F4.toInt())})
        box.addView(type)
        btn(box,"🔑 صدور رمز دائمی"){
            val prefix=when(type.selectedItemPosition){0->"s";1->"m";else->"a"}
            val code=generateBuiltinLicense(prefix)
            if(code==null){toast("همه رمزهای این سطح قبلاً در این گوشی صادر شده‌اند.");return@btn}
            addLicenseRecord(code,prefix,false)
            val view=TextView(this).apply{
                text="رمز صادرشده:\n\n$code\n\nنوع: دائمی\nسطح: $prefix\n\nاین رمز در برنامه به‌صورت آفلاین تعریف شده و روی دستگاه‌های دیگر همین نسخه نیز قابل استفاده است."
                textSize=17f;setTextColor(0xFFEAF7F4.toInt());setPadding(24,24,24,24);setTextIsSelectable(true)
            }
            android.app.AlertDialog.Builder(this).setTitle("رمز دائمی آماده شد").setView(view)
                .setPositiveButton("کپی رمز"){_,_->copyText(code);toast("رمز کپی شد.")}.setNegativeButton("بستن",null).show()
        }
        back(box);setContentView(box)
    }


    // کدهای جدید قابل انتقال بین دستگاه‌ها هستند. برای کارکرد آفلاین، اعتبار کد با HMAC داخلی برنامه بررسی می‌شود.
    // توجه: «یک‌بار مصرف سراسری بین همه دستگاه‌ها» بدون سرور/همگام‌سازی قابل تضمین نیست؛ کد موقت در هر دستگاه یک‌بار مصرف می‌شود.
    private val BUILTIN_LICENSES: Map<String, List<String>> = mapOf(
        "s" to listOf("s-E2yVSEtc6HByf2WMFi", "s-jN3c$3zf4PHi@Pu6t8", "s-RQ55TKYzqeL9UF@T4m", "s-7d6LrQm@SZz%2MqKsR", "s-ySVF56NzV@zG7jY#&J", "s-xU4zPeQ$qPkKUtdB$u", "s-k3qd#7C6i8&wz8X$%P", "s-#Nsx$nq6m#txRSTTt2", "s-*nTZBe!PHexSBDjZUH", "s-@t#ye*C*MnEMnUWSDt", "s-mQPf*sM7AhLE37nsCk", "s-R56Kzu$9TTMhJ4&BR&", "s-9nRywB$SY3SWH8bVDb", "s-UwStSCfx5tGa68&RUN", "s-mG%K8iAb&WDb9Uf*p@", "s-VP!B5xxgdgBTYdyd%k", "s-rqbHfYBrLap45MN44z", "s-YuVbHRQJ#w&@sx2&Hk", "s-P4eaBL$qyUuYDx2bR4", "s-grTFTN2nEHN9yikbap", "s-mmqKpn6hXR4gy&oMsv", "s-LoL2$Ze8b&zkFpUWH4", "s-FSs#Z9i58yP*v8Z!ch", "s-JgFC7wTjv2CnbpYKXk", "s-t$*P2J4%gBZVgugxQh", "s-mJqKhdV9PaKmgTPRzS", "s-7zuk9R6fkUMAQK9XUi", "s-vsmzCJ$AsC!vJ5DTLM", "s-AoaShR9Gn84M3i6P4$", "s-bZTRngdHs6mjFeHh4V", "s-!N$NZNL8PNS&nq!VM4", "s-azcfuV&i&e!GrKb%3N", "s-mVYwK*7oZ%SNpJfMz&", "s-PWtscpjx6ogEGGLbEE", "s-fQkVz74HRuuSNMf9w$", "s-aXVKohnBM879qp4bzz", "s-2j3&FAeS9L!6RZeVtm", "s-JuHJMtYMgKEcK6RnS&", "s-W$hT69z!56M*CYG5aX", "s-c6BrjPSf4KX@sHu$dB", "s-c&NK8ftW3#kUer3Gm#", "s-oqZYQ23Hfn!56C7TC7", "s-iXHhjBUDsF3SiG6&ER", "s-oaxUSrbZ2TXKj7axfg", "s-xshkWz2iW!gQ9*4WTo", "s-Y&7SQfwsQ2TRFD*ciC", "s-LYz7xLz#*$q*VV*Git", "s-6tjf&Au*ycdMYs%WGE", "s-n8oLPm6xwHmUta7fiu", "s-F4o7bQaLrTL$d7dnbF", "s-e9E6EBKZH*4ea67&yg", "s-qKsBRa!yqUJLou2YXv", "s-rRtuD%iXTosPWm&uq&", "s-3RFrinDtyNGvXHnbFd", "s-yhPNGBGTGChvbuJGXk", "s-!@yLShFh&YCvYmsgpU", "s-*z2hX#RH8KQ#kc$&*!", "s-rj$Wbu2%dsnG6agrNf", "s-68*LjXx&xXs&wX%gYV", "s-E23$rp96n3m&LTBZPW", "s-rpqpciLLoNgJzFe7DG", "s-xMhAL#yjm5uud6GdkR", "s-7$wRgsr%MBhvLyE#@#", "s-nFK5kE2DuQD2hWbWbf", "s-fFnS4k&kEiAZf$S$2j", "s-TUw*&AT8u9JgW&D*wH", "s-42!JHtsGDrphdgLLUi", "s-MFTj%TphGGN5sC3@!W", "s-D5p86azCQb7Ywjmttb", "s-AEPdHS3i9ZPomFw6FU", "s-fN!@Sakoe$y!agk*WL", "s-#w2m8p!F*Hgbv97GgB", "s-jBA4fmkq8%iW$QcYzC", "s-Tr*G43Zk*GJwdh64HB", "s-XA*AUsQhAAZwdNgxxV", "s-D#RD7nZp5*x6o!sDjT", "s-&!Ki#wfsgkqzdpn&#r", "s-F*K5oi5gUBEUQK8iif", "s-gZ3EiB@CLTa6eUoeK&", "s-TpiBYCK4NnHTgcuq8y", "s-gP4ue!PgH$4AJZW89h", "s-enq&vzSSTCUeLBakk!", "s-mY5w#K39NHkdauV&Sf", "s-VKRd%Yn$F4aZySo&Dc", "s-h4TAmnzT5dfB#tEtqT", "s-xH*GFG#%6P%NViFKA%", "s-ii&#uWG&goD*fN@bi6", "s-fg35zc#4xRCMQT$ae9", "s-N8EWxoqgA3oGvxLHS$", "s-Qd8G2&j3vgx!J9G6hR", "s-kLDt7wg33fsw&wQjje", "s-EKPDN6QvKYRnGEPvtJ", "s-#wp3S7$3HZZfkSbfrX", "s-KwK&H2dJqGQwze7d76", "s-FCBSg2ySRBDQ8@jX!d", "s-&VVZFZgfi4pGS9br&n", "s-36x5#QQqTX&tr665aD", "s-egmQuWqiWSUSF5EUQ4", "s-4mc6nRWuLkWgNTNPKd", "s-C%%BKb!UsM*rKzqXDg", "s-J*A6CA&q!Ztt3ok$by", "s-y9H5CbFaGwh6ofMfgp", "s-CcHn*Ka%YJj$3%$RjG", "s-Qr@JWhGeAX#wwZQFqX", "s-H68$eFthbMBq#jAM&$", "s-tByKSipj#VcW5KJryJ", "s-yy7Js4Lb&dTfM2K&RB", "s-6s#dAQiA3mzZrRztEE", "s-rUX$FZjM#vcZweQbwZ", "s-eh@nBK4LRWWf*Ug8Pr", "s-M4VktZ9L5TEXW9*4i3", "s-9gzf3N!946Xh6eoNH4", "s-DTM@DEKoj7JLrRB6SN", "s-yyCpYAt&%954WVhg4L", "s-n3ssxeVjC#$3&yV5nH", "s-YrsTQpoLo@5kvUwWZH", "s-Czk&9ZnWFMvR$Te5tq", "s-thPrccbZt&ExT8j2eR", "s-!@HiPPPJs69N8FA!*x", "s-49mf3c2s*eVrYzm#hn", "s-bAYF5V!GMSZ2zbe5Zw", "s-@HGPHs4BxgZqkP!ypr", "s-EwGGpVuw!!qj$KD7bs", "s-hr@rb595LmGN5%P73E", "s-JmZR#J#i&gy74pQWgG", "s-6U$VE%*VS68wqRn82c", "s-Yz27zefK7NDK2psxfQ", "s-zZ7dpuP6&zFFWybe8%", "s-ycsoo3bjSABthhP&5S", "s-W5!*j$e#H7GmN!*o8d", "s-62jr$ZTwzGL@&%PcBs", "s-csdYsh#XjE*%hod5Gr", "s-73a9@fyoq3vqjDDUmM", "s-haeXgoKvS725!WjhoR", "s-oMLcuo6F@g&7Yiu$uz", "s-Z#&kSQ$DKAMWapQfy8", "s-6Y!VhUtatTSZnz29Tq", "s-v&JzT5hhst#!o%S$57", "s-CQsiVchwrDDYo$XM5e", "s-32odzQ2eZ4Y5C8b!bi", "s-pK5Qk9n8s$ehpKgme$", "s-dH5g8G*xo98&Kq7Rcu", "s-zirf#58FDQDmKPHYNd", "s-EKcTWMoWbqyWRkPn*a", "s-D%7SVynbnL3Gu*NCa9", "s-!EhTHaYntrtoX4Bhvp", "s-9EcCF7Y7oHAt7ovG7N", "s-pDE2ACwrzo#CRM4tUf", "s-iMBvKxSPqADQ$DH#&2", "s-@@moAT$c6rZ75rjMxX", "s-!hNnoN2#oRNSPMAW9T", "s-c5TQpHH4adzVX6ridh", "s-Ck4rt2Wzsa*K*rJRrs", "s-*9eW68PFTXXEgVU%tJ", "s-kGEmiZxecooH5@FhnS", "s-X*TDCiwnsMy5Z&By36", "s-GLDUkrfux%q%exPok$", "s-hjQ9C9HSs%WFaSqPTj", "s-p@gxqRGhhuYw2!2Nkk", "s-9&aJbfAW%ojmqdFyQC", "s-&6cYebGAuBHbMoV#Ka", "s-!nsT4gRH2%y8Unkksp", "s-cmKRUJ2LmGQP44apEG", "s-Q8PYMzH!Q@MRxcQ$gn", "s-!!%M&FPau66&TX&7mi", "s-a4rHa%sC#RCGnat$Wi", "s-tqqhfKrqzt@RnaA3jJ", "s-jeRpijQSxNfsyMxyfD", "s-c%SaWvz@XW@Nf$J*7#", "s-q3kk%ZuT4YGc6gVx2Q", "s-ZsoiaApR4y9#DkiExs", "s-*YefbZs25eNXg8NiSm", "s-@G@Gc2rhFcnzBF4&QY", "s-E6xf3hD#o2tsZ6EPVn", "s-PJvag6fS#dAtq#CNVP", "s-RyFxjqNY8WVroGWe5c", "s-k#KDUeAv4EAdF3G&uP", "s-NueQSQBi5T7#ab#qe7", "s-6viU$qrfXqMus3t4Tb", "s-4NUGKwMbL5RfSu%%KS", "s-fYqC2Nv4fUEe9PDimR", "s-8UB$ZuWkwNWnwHVeex", "s-9fbMvP@TvtZZijrvn&", "s-&XqYng5SVh77TeFjLo", "s-9kL!PK6JZ$36JjQ6b%", "s-Ty&U6cfvki$Nz%kdvE", "s-NDePvGo!cCJyjNtKas", "s-*QEfT*enGugF9SZ%NW", "s-iNZEYdJoVbggU9F@d5", "s-jfUXR5ZJJayz6ihWP4", "s-Y@zgSEAGndcuVkFDzk", "s-2y73gPfxmhCVscvVLy", "s-ipybVhrpL!nNmHNxkA", "s-hoz4bXZQ$t4wJBjYAk", "s-zt!MSZrfFG%JoCQRv&", "s-L8nLsT2LmxxC%FHu!t", "s-2VhN9PgZL424N!kypi", "s-UuWcNa4C*j9imw*Dki", "s-L37ss&d!QnBnznYJpF", "s-XNiCz%Z#uKz$Xqw8nE", "s-WFurdUigG#Y#8moKVn", "s-D3kxk6EXG2Q$vbfB2m", "s-Jn2P&4i3jfgNM6v6K$", "s-NqV*dhCsNjs4HH$5ts", "s-CrSE&nwnJR%##NyqZS", "s-u@@MWRyMvxz$Bw$@re", "s-wn@s7YXWZURxN42x*o", "s-juF*3vAy4%9esc$xoV", "s-dSU@8QZRoteS6ozbfC", "s-YBG&o8eisVeCAS8GJm", "s-a2zCQawfhpk4XjLDWn", "s-%pAvzDHd9YeC*g9dAg", "s-Z&immykWp9bjThhRfn", "s-vjJzevypzvm$r6ZnuD", "s-Q96cRa3QRG&!Prfm57", "s-vjE#UW8s2Ge*pRj@S5", "s-L34neSGPGje5sBUeyS", "s-FVxV!5aVzTqK!ECp8!", "s-iod5ZFZ$hkhcb4NaPN", "s-c32$a5ncevv&W24Qqw", "s-qHEGgnwYxXwCLU6gFX", "s-fT2&hHWS7tRnKLRr7M", "s-ZutQJhzV64gmG!iRRD", "s-AZQ*2FBzZ3Aoac36NU", "s-NpaRhgy#3UTwXkTQ87", "s-ryiB@bHFnZvZxoy3ab", "s-#W$rFhufqtjLfAgGMt", "s-53TRhr$xByZkS#6ZHt", "s-EgukuG2gFgsaM*UL*x", "s-ASipquJ!!#n#3jHv7U", "s-#jk4urzp*kapZ7VdMq", "s-SAAPmdjrQFKFkC5NUY", "s-Yy6$Mbm%jqWyb3BcsR", "s-qGYzMQ@%w5JJDAj99A", "s-2spUzzj2QBk3Jqk&Dr", "s-ScMTo*xta&VuYLHCbY", "s-GvpqBKB@zXk8W%Kdou", "s-cpuoPv%xx&4DUVVFrq", "s-#PR3Y$8y2EA6thfzo&", "s-*atnf!wuWodbAbwqdJ", "s-!pd5MbpYta*m2owaGk", "s-oZkenEbqYth*WjWyBi", "s-YBnwAbVJcCJ2yoeFdg", "s-mGV&oQ#s7tqEF!fqqp", "s-M8jPX&nskYmoY2@$b@", "s-G62b6VA7D*NiTNqYpd", "s-zxTNNJDPoVdruC&ff4", "s-$2rTT!5T9o#9%AakSG", "s-M7xfyB$ume@GV3Tpzf", "s-h2qSjR%&2yxya8enzo", "s-T!Uqtt9kvmPBa5k9x6", "s-gsb85Q@95aZ!MFepez", "s-MvBPt%Mu!rjwV5JmeA", "s-2xazQ9tbq4WFYjMhCd", "s-&yo4$W2iuNGSXKNhQQ", "s-fq%$CdogizZ7v8UQ6*", "s-!3W2ypJX#8f&8Xs%q@", "s-MTtsXokUyyXk!mFroN", "s-iKPyA@vEkN9h$M6r#r", "s-JDJYhWYCwfiHuqyh##", "s-xDwQNoyijq%mVGWht6", "s-CCwK6a@ufp9AXKGVbi", "s-BqnKX$h#p4Au@vWYZG", "s-kFUWDtz7a@Mq%VWpUw", "s-mPCqCV%bssBQ!pWQhr", "s-yhid&Dbd$272UpQYmf", "s-gdXb!EkhwDu#FVjHFh", "s-EyQhvDYg!wy%Rr5pe*", "s-m8$r9ozUYbbpkiJ$@q", "s-tUkmU@VACpffPYtx4V", "s-Qi5dfX@X9g4XTCN@xn", "s-WWgC58Hk$!iy$iE7RM", "s-8SbEwsCvzNsTEsECKW", "s-FYunCF3Qf$%6WA4MHd", "s-txw!#8sTc&22!yJw@k", "s-k!vRfPwuqhcimLe*gc", "s-vXCdy4$w8*qSRm8dQU", "s-#dhMLM*&teRk@t2yZM", "s-@8g4*JUXq&a#Erz%*Z", "s-&xxPeV&HEcAosY7A62", "s-R@ukqKDT5!6ABhFLz5", "s-QBb4$aU9sZYyconcX&", "s-HAZ4TQtz8ZE7w$4zDp", "s-gWtQw2NviVweAcMfb%", "s-iXNseYiUzn@@r#Ku62", "s-m9TsNiEoe7x7UV4Xcw", "s-6eP5Boz3*jXBDsUodc", "s-iu2Win7uvG!ooHpHPg", "s-cXc$XMdsgQZA5t#Tce", "s-rw48LYo@wGoYvhHR9o", "s-Z*t6CUtBXJ87@iQQvc", "s-DnkQfdJXngt4FXWr9Z", "s-Fo9FeyPSLR9whaxYhW", "s-yZ$UkJh%VY8v3rNSrz", "s-X&oBhzGnhwkrFs4bMB", "s-!U8VFEq6GxK4KR6&GF", "s-aJWDq7ya*4*8cLVh8Z", "s-M$FnCg5TCRpbSUTxd8", "s-2CLTs8@oPQzwWEJzg$", "s-kzaqGkUsn7hnvWfKie", "s-%$9i4jvVdkrXd$6*jc", "s-G6ArtR3qmP$Zsrv7nC", "s-4R%wWJE%VcgRuwyTdK", "s-$9EZ$gP@&!7$wMUP#F", "s-jhdPc$%m2$Kv@E9obS", "s-heMVSmARa5BtM%rYNE", "s-shC6uQhfD%&qK4T!@S", "s-fvtEiYH#vggK#GUQ&B", "s-Nr6&wM@ejb*Rn6w@Qs", "s-hGB@q2XgyUeeFQvT4m", "s-N4VHmMx!BRGJ3VSXyh", "s-H&VANKvdRwjbQNwStv", "s-@t#SFHvByQTHASLhKG", "s-G@NL@VkgG7Y!AZ4Lvm", "s-3GbA5uomry*DF6YhY5", "s-iTSzhmA5cqS*KqH#U9", "s-S!X4c@eiNJfYeJAnCi", "s-yg#rxKT6p!D@VJ3iT#", "s-kMwuFzumYTj#bG&jjM", "s-2BTXRpukwr&eRSbZ8g", "s-&E5g3m*Tp6uKWjHC9G", "s-br8BK8Uov7DyVzF&2P", "s-9Mvmv7pWox@CKp8SPG", "s-eRKdMpVmwgvjyGu@jg", "s-VPN6T7SiQb*a$Urmp2", "s-Kt9yeXn*nEY7Cq&awJ", "s-fLx$QANethnRAiMF6Z", "s-DaVb4vPfa2wbWPv!Tp", "s-h&gML58W3ZzsZqgRJ7", "s-7ot#Ffi4c98mZMAm3%", "s-EnU%WrAgtm299B9i7H", "s-%4WE5W6XspX*QZMRyj", "s-g#o3r!QGXkoNtAFVNG", "s-dpb9!Sr*6*s!n#eJ%X", "s-m8v@WbFw8a6XD2puqV", "s-#87GzwsrTNt2rxqVy$", "s-ktmgxY8UKCG5tuSWWJ", "s-Y#VHij6zqX5eW8@22P", "s-*Ady9f3N7STZfWm@b*", "s-5@!s3XH2ZZdaZ*KHkP", "s-m$D7aXZRHGiT5kixQf", "s-RxhjKvXawN7vRXoiuF", "s-GkFVHgRBsp8aDGma9z", "s-yzU8jje8Tf%i%yFwF5", "s-sFESedR$b#p!HVLjY#", "s-mCiLERYSKnP9BnKSyy", "s-MRJhoC8vHAdNaTVBB3", "s-YQvAgqGuhrAquwJuUB", "s-H$VsN2duK7JUmdH3y4", "s-fJw!E!taFFmXc!Er@j", "s-tgSUnyc394mCgnUt5V", "s-P$F48yEFNkCDbpzffd", "s-NyKnYhCQbKrCDnm$vi", "s-6QWvc#x&7P3oprn92#", "s-NBxuAQ4AGea*t%h4Ty", "s-pbzvvR*AFhFBC*oFvY", "s-g%uJJo5cwuA!K4%f3c", "s-zCtLd3%79MNYiZCRWN", "s-iicMe6%JzLC!nVR@t%", "s-9b&yXWL$ckbq%9Ao$2", "s-QN9q8jkLWeZNYHvoNx", "s-R4a8hbB%dom33ZNHmE", "s-RYzNGHRUVoXDf5i7ni", "s-ZJEsiLuSVKRL*Gxs&T", "s-QoLbRzy9vverxEC#J!", "s-PqC*uE27yJ%DmYGsJ@", "s-sxBCKpFSA9JsVphCba", "s-Q$g&&4wNY2vaHm@EQp", "s-bUYCEMB*PpTE5tDs!c", "s-VbQV%u&!hTqpSYCpQr", "s-w%!Zshu$%Vwasv8dno", "s-sTBqeQ4Ypziyi6Cpsg", "s-4CPiH7ebdpjEDcrino", "s-nmRtG5NjFMVHzmKQ6a", "s-pHt&obD&5!dDVi4rFi", "s-ps&fVS6%!YVkd$8hvk", "s-bGL@tgfjbbMFd@Y7EY", "s-bVFvt$GVX56D$*#jvg", "s-knoxzAuSRBfu$8DV!L", "s-W&5$uUXDmXHa4o#ikF", "s-FgeL&tEk&bRP4xsj*y", "s-*THA3PYryfXdrHnwTo", "s-Uq6$P2MRZZ$tQDg&*g", "s-7yQksgMG6rjHx9w#nZ", "s-JpMKYwg#@26NT2bY!T", "s-$7K9nG93VEbp&DPeF6", "s-CFvQR3fht!H*VH7Y7U", "s-smuKCc8t&aktfSJz36", "s-*HwjQjtv%yQNGeGWZd", "s-wqh%R2ub@JfhNipQ@h", "s-rkbC7@WdnZvj4wLuLp", "s-$uWLj#G9xChiPsdVUZ", "s-tqzasvoH3sZg2uEmMj", "s-kR7ourSx&qkU5zw5EB", "s-ZU$jjFqMTkoUJ9k7CE", "s-uyn&mHX7YZMuwtX8UM", "s-kR7FYFkS8h#p6#H8$G", "s-pKb9CfBLo4umQuDEMH", "s-59muycqcvLnC7pzgGZ", "s-FVvFpv&5jn24L9p@@S"),
        "m" to listOf("m-STWY&XbMXjjE*rmEcW", "m-W8Rqc#YD47Q8gmmrsD", "m-Xi&t&&Cofh68y7s8tg", "m-tCv3C3ZYXDkjmAHWc4", "m-G!*3hGDjyx8i%wWuX#", "m-LUboLHq2S*CcgSMxv2", "m-ewR8LKEKS#u5FNxm4c", "m-ZrpVqTQsxLYaJWLSzU", "m-R#Djsm#@9um@GWVqD&", "m-6qvB@7m8TF3eMYAYy$", "m-nPisSzuzqkcC!n7xY7", "m-TvTAoSmvEG#cxi9!i8", "m-Md$reAczycDUpDXNnK", "m-rFYqtZjJ3H&mUrfi6X", "m-P*5xUMoRXLQDphSM%Y", "m-xbZVFXg52FPge93Ape", "m-HUtZeNVa59wafWetHD", "m-QoWCouTe9MUsAzHYcc", "m-eVDyX4FiK6gJF874U8", "m-%pumtJPwrf%X4P8pkG", "m-Y#ipsMjersV!7hD2Y2", "m-5E2$X8VrLK!dT2p@DB", "m-5b9F8pYMr4$VNLzi#m", "m-D2Lc&S5JtddfETTdYp", "m-XGH!%Y6bTbyMe7qTr9", "m-NM9Xo5jcM6b&7r9sny", "m-!og5ao4UcQRVJroijh", "m-DLGGqHEaRD&F6gJgoZ", "m-6yXpWmkD$uUZz9bGuA", "m-NwnfT&8d$qW9daXodb", "m-U*dDpCp7XyvEi7L!B&", "m-@tQ6847Wvb6G4*A#rM", "m-!H#zyfdGWCp*nvCXfm", "m-D6c77aPqtAx8n94Qok", "m-PoXLzzda6whhc%2xk4", "m-MdrDmc9f&jy$CSRpMo", "m-N@Rf7t*4q$B4ZajsTE", "m-kdrDtLnD@BbEBW%7#f", "m-Qsi$aua3VDUHBjoSzy", "m-d68np@Kb4VCqjHxHu!", "m-9DedL$WvFF8B%Dhyz7", "m-WZa2H*Ziv8@!hF$8@o", "m-CU7v3yhkq2F7V7RNZU", "m-#n5ttfH6eDF@cN7pU9", "m-wBT7rDG!LWgr$VvRfN", "m-p2T#Mfu3tSt3NSarPr", "m-sChV@iwVF9dpUwBEPo", "m-*F8xdrnPqQyivt23vY", "m-HpEs#WRYA!fSir2cX@", "m-izBzgv2jTpVDmwXdi*", "m-@umU2TY6qwQLgLb@oo", "m-jHbruV9&$e45BgVemw", "m-TMo8f!RX!XQkhMzPxN", "m-N8Zq8YG@@rm*dE8974", "m-j7TvCpaq$bNVHqZtNw", "m-ZjvFq7SxTuCLLRuhLh", "m-Ux*#GFKQSjYkKY#k#M", "m-KHVUc4DGLwfeQPkG%N", "m-K9txp%!J!%pFNj@A96", "m-m9kaZb$auvt49YrtmE", "m-fTdmHrcsHTXnhxE!xn", "m-zZ@RemrjCuJxtgmi@J", "m-uSniUXYNUVb%u8ceyb", "m-U5Qr9NtJ4HFxXt9!LM", "m-TxTD$8cUG!96WwZdft", "m-J%$$fQEbBQPYmJre&%", "m-wn4AgR@w*f#k2Waw&b", "m-wxX3k7dUqjDETA5@c4", "m-GxJaFsf%X$HhEkbxcz", "m-fxJHBSgaQi62!Ty#!Z", "m-ZT2#chVoHGCPw*ADUi", "m-xE%T*qpmQFX38dMmGF", "m-fFefjwh9dtF*N4FZXB", "m-LqkqkV@$B8ctEwq5!q", "m-eprwgz#HtFJgjp99jP", "m-csGFJqitoJoCgDB&PY", "m-GwXEj8DW4*iddUuVZr", "m-@Mqj9zZKMKTvDLRFxG", "m-rccVT$HRH2SdyAKe3t", "m-%$Y#PMZ9Cy!Qou@UnE", "m-qF#WE3AYrxs6ut#SuR", "m-StMpz4me*C@8@Z!gxv", "m-Zddu#CQsFbSRjMM4*L", "m-*pKqvDd9vkmn7Q#uHi", "m-HwzoeMB&2uzuPQB!WL", "m-Jyeo4pB365bC8fvzT9", "m-222hHkaznmPRJTNn%B", "m-CLp#MYMrR&XabnmjB*", "m-pJBKo&KsmY@!aRQMyC", "m-xtyL3KnwiAaU4AXZsP", "m-2KS&WjG#WpVLtidpXC", "m-75*UiTRitWEn4uX4Cb", "m-S*ZKfvS9qv%$%dWB23", "m-zwGFX8Es%VLgUidkRw", "m-wYVDWnHE*SUvSHq5aA", "m-MRFHbVB7m#vk&kGY$y", "m-A&U4Ja%mMvMYx8dKbx", "m-85252B#VyhGiV*b5sb", "m-P%XKpfseNAnhYT%zAu", "m-ucbFZdANbvk!ZoB!mb", "m-V@hi8Qx$Fs8T8QqhC#", "m-Gz9&P@mkL8oeVppE2s", "m-sbya%&o%pbqFVr6zyh", "m-dipvU2EYWTwB4CMaPy", "m-fcymkuFM!tkuiXayQA", "m-ry9sJx4JcaqhrbqVzt", "m-MfeDfd&paEZ4q#N7&W", "m-$yTiuy&3C@*JR5vvX2", "m-3mo!@SWv&b#&DYA*2f", "m-a52vQQxs7VEWe7tQtA", "m-jL5Uf7c9ohUqLQS@py", "m-9@KfNUb8anoU3JXYDG", "m-EgA%dmrF4ETT3&xqAt", "m-pP6q#VXMBT&b4NPhi9", "m-RL!@dFBeXatXYCQD&G", "m-6P46NUuQ6vnpc!dbo9", "m-QkHjTE$yY#XceHiXh!", "m-z%kiYTj&yY6VB@yt84", "m-Wf*MxYBTPcWGGF!G5p", "m-mvW9Jz#@f3jD&F%jx$", "m-TFh&ogYtHX4dgjqkk&", "m-ksicyr2##TRtXVoW3T", "m-Br@aMB!ZtwaGT6&3$e", "m-&RJfk@nKWobT%i%wJg", "m-9pKnxHw3g#qs7eFi&q", "m-!rYBnoxHg4ymPHyuuG", "m-iXPMgoBTUT%%SZHLzm", "m-2UFDE&ThzLVX*tHq7T", "m-ok*6VUWHdT29iXyEkF", "m-4Ny8V&3boi4Sz5Vini", "m-eWRqZd!*F!jbaw7zsr", "m-!$9D*aTuuqgT@XBdmT", "m-v@&p*Ng5bFe2a3SqUf", "m-!8#z6n2!bekxb2eYNa", "m-yNcSDeQWhE@5o9s$%7", "m-daAx6Cd3nk!bZfXMKo", "m-Vy38DwRucsruWLJN25", "m-7mXY77HfdGfxtM9dqv", "m-NN3ZfxhHkMD5LNHvNZ", "m-4bDiXpurSqox%8&L7H", "m-j7XhKCbNMNy2%t9daS", "m-C8CgehNG8QYtJwNdbt", "m-FBSEmGbkHcvZuVu2Gg", "m-X$cBR$3Q7p@Ba2tS%i", "m-jTExjHZ4BNUktWrD7b", "m-hE!$UeZHH!sv%7a@UJ", "m-3Ah7GDsC*e$EkWtYk$", "m-TX#YdCj8TYcZY$srJU", "m-fzhKC#3Dge2tPwZ%8c", "m-M7AgwC8u&#yyPzGALm", "m-$jeGVM!w$Tya7Lichz", "m-B6auUrmvEasjuK7Goo", "m-Q2Wu9eiQBK*gv6H2wA", "m-WMJNTmYWYh3fqpkF*m", "m-QE2cpPxvP#LSb3%ACP", "m-34ZTuFcE4BgS6Xv#KB", "m-U$iy#hNvLSZdYxfzcT", "m-Bxw7w4Uq@tLzMKvELv", "m-MoCr7xxFX7scLFoBjE", "m-uUoUtfdZ#*MdqVAw$t", "m-AHjAV&b5s9jd2kYe2X", "m-D&NFYK8Z3DLD@K!BKS", "m-Yoi$5TN#swds7qY*Dy", "m-TFLu!hxQrvXxKMU5A4", "m-JcmJfQ#aVacKVi%c7k", "m-AQY#pAHovrcdUYtpnf", "m-pxfbE$exY9roe%UXjx", "m-C2sWknU$x3nEFcHtXS", "m-cPP4hpj%79NURdP%M7", "m-jih$C%MqzT*cF8WM*Q", "m-33EJvotehWSK$b#mmp", "m-5bi&gD5Amyj#AVoiJJ", "m-Wzspn7uJuV%&odCEZq", "m-dbJAVGLkg8MJRLHxZo", "m-eG#up4nh%Ky$Veypiy", "m-Ni*aLp*tnmhsLndHG2", "m-7iFa5sKuVUm@8pa7Da", "m-S#RH3Eca#$XTsBRurq", "m-nYo@pkixoS4Kq6tB5R", "m-uVzhz8txhxudvssYVQ", "m-#mVr#KoH2chE%nEBR5", "m-9TnVprFnx9$zBm3QgL", "m-qKNj*3KP#KJAhBs&AL", "m-$6Yp7HL7oaec4pTEk3", "m-pAp%Vdhw79iD6YvhQP", "m-nK8aif8jtsVV4G$nDU", "m-wSA3KfrEk7kgLS6ANn", "m-*mEqrujcLTuVFU7@Gr", "m-gJ#jafCjhcNY38UF*C", "m-fUqn9PTNWdbn#tzL9R", "m-AnSSJLPXC5jQJ8DskD", "m-rDV3xaLaD9uim*t@Qv", "m-pJ7Dv4pKZPaPhr#fz!", "m-VxXmuuDKAN$Y6Fhwq$", "m-HG8w8KQ!&&fEnphQcN", "m-ZJxKJNfT6!$Y2xn7kQ", "m-Ybr*Tv$!6uqoAGiLL3", "m-rZ!t3D2KeHSdP8RgjM", "m-mi7JM%BVrCmsyAT@nW", "m-UEqpVJsfbhwRHYE3qS", "m-n4u&#Rwu$W&ceq83rG", "m-LunR$!5jdDYAYJg4*f", "m-DSD!!NYPiGbKffXXvV", "m-phNGdAMEQ4iN!NpAp*", "m-p&&rCxms5srxX@JNX9", "m-Xi$HSFhKcwin!nVsnA", "m-#gtptNM$9dH4XsEz$P", "m-J$J$E%qf87xRZmn88Q", "m-8bB4yY3mYN%qou5Z@r", "m-6h4NDDJWvejCK9p*RR", "m-NWSRvzT@Uc&WTZ7!Kb", "m-ALMmq$$go#iPjCB85L", "m-4c4Q2MNoatAo&DuCi!", "m-2geq8o6yXLqY$v975m", "m-PzUeek8nYnG48wpToG", "m-6zV!Wy8xw#evbZYf63", "m-RW9R5bpQo3Z2FM9AL6", "m-BELWfCEWMwdv8Mj9m@", "m-@MjFJfSaPAUni4czuc", "m-b8kswZCf3E!v&#iF!g", "m-jYpzTr*HEEanCMG8$D", "m-Ra#sChTAUXWjzHFywK", "m-BBR#bPwSt7Adgk&Vxh", "m-b*Wvh#3L3RpqRMeG#E", "m-rjaNaE6MB4n@&uSa!T", "m-2gSDLFWR@bnu&XJ3eR", "m-8EykbeG&83kKaixNBo", "m-8NjHs*QTYba4J%nS9T", "m-DmZs&4NCghaKXhQbno", "m-q9$PhH9&59Lch9j5rg", "m-YM6F9$&cTxf5z#JUH!", "m-h8wjC7soQg#&WUowFF", "m-aqqdfde83Ea9HA@LN*", "m-Gac!G9#tVx3GR4jq5&", "m-HrRQS3&U7D4wa$9P#n", "m-gtZWNvoRSBUKu7CQZR", "m-YdftuSVyQHHoKKm6DL", "m-aHf9qLHCeeG9HU&5AD", "m-5v7bNX#YkW!HE@JVnC", "m-ZY5nu#CH&$pBdGvWdE", "m-np%n2!D5eneeD7mhwf", "m-cAz&Cr22btqdtmMf&#", "m-*5kCj6h&b*k5Hs9!DR", "m-zvgmpf4mFvTh7e&iVS", "m-R3X9%4Z$H#jShc%LiC", "m-FjFf2QraGGk@N8WWMq", "m-t&tGey%F%h8wd%bjum", "m-wrg6SRiNq&r#qZsB9r", "m-LftBw*C$UMNy5GeyQu", "m-%zVL#DWUg!MxKVicg!", "m-X7SFkrQbiu3pgoMPc*", "m-JeyjpTGGKffTsP7RRH", "m-f#xHtojvPZm5Dj6G6E", "m-kmcpmRLzhL%5UoNaeM", "m-qPP44piRswsTfrUhF$", "m-ps%8BJs5fm!4zFEgha", "m-mnGt!#w#ak%!7Lwmgy", "m-UahKnwnFBGCMc34z!j", "m-rUuPx7FjgAFNRxuk9t", "m-#22Pi$7ToYNLszsk28", "m-%$2vVK@oyK%3Qoxi#@", "m-VnFgZ5o*Lwbb$eY7aa", "m-r%#CD#jHV4@PHLZ!d6", "m-rGk@TxcNSf$yUwRTu*", "m-K2tbMR%ooEogbT8%Fh", "m-!EsGpD7foxHmkkaSV!", "m-jM4yQ4QkKSon&yJfvL", "m-PXPkPLj8DM&#%mwWXN", "m-ABFupu$J#Uhbxttfxp", "m-nvU*ToPr%NAuTHUBzd", "m-Nw2&dAxBSLat2kCrnA", "m-aew8V&RP6UaDnv5J#4", "m-azSrg3#2LQoyr6$$tp", "m-qFb!xU%dM#Zgmo8o&t", "m-inm4FBEEXEG7TqVtta", "m-hb%xc$MLsCqRrhgj3h", "m-J9KwLHDnzzNX7cdN@E", "m-w@pGetPZbLBmGSfzHr", "m-RfdN&PF9%NY24eva!D", "m-bRMSZ5HYU$F8zL8KLv", "m-F8$kgQPLGEJPuaR@am", "m-8oN@22KX7Xd8bZZCX*", "m-bbNputRS*CpxrqYAHQ", "m-FY!NYyW9r2@RV$uh6E", "m-4cb#Ury@Vtm*jyKSn4", "m-rthWeCbovQEa#qo%Wk", "m-F%2$J9x68Ja*Z%Gx2w", "m-@VeV5TuTT3L@$9@#@y", "m-KoQhDWG!Tv%o7@qe8r", "m-E8SPGNo#hXQC9vWkFT", "m-qGCuo8co#RoTazhR#X", "m-Pi5hZ$wmjEDUF$njzs", "m-H$t%2gn6GgDaLp3vhx", "m-hpoN@#MJ@Rn%QcSY!z", "m-@m&KdWBVjB*eHPi$L%", "m-%MTobtdyrxmKuZ47&k", "m-dr*oods$gTqjd3qD&q", "m-ATDzvwJrvazeXwZBT6", "m-Ni6s9d*to5yiMry3u&", "m-sG@hoW$o$LDnYd8%vk", "m-u9ebBLGsAa7SdG$!V$", "m-$F5GD#6yN4ne9cso$c", "m-pqS9t9Dpdt!a!u7d$V", "m-yXNQFH6*T@Skn6Rtbg", "m-MfxT3#K5*HYAT8yn!U", "m-3#mRWhNkDXvQ*jg2P3", "m-i6psYzVui$8Bj8wVvW", "m-p6P2ghGpzQQw8pK9vW", "m-xrdUuf2RdgBu%@fj7W", "m-vom!P!adFGpgvX2zyx", "m-&Z!!qMqTm#iE8Zq5iT", "m-Gf7gvDayRuXLk67f@i", "m-2P@AuNx8Smw3%m66vd", "m-&xCBxonD&yWTMH9J&p", "m-j6yjZj9P3Sgm9ES%Xq", "m-SXfixReTRtnTr*W%bd", "m-ocNfT!jnNR@i63NjCg", "m-v@6Vgbt#Fq7#U%m5Cg", "m-fAmAw6ByeHEvC&rMif", "m-DT3%fW5s!vaRrig!Kk", "m-BRKu!QhYqe3kXw$%Wd", "m-K5$N2v3uy*hbJr9KHb", "m-KVruCsvUhVBnFVixAP", "m-LjNpZPFgp2h5d#&6N5", "m-!w&S*Pdsa3h&BFfBaN", "m-iiASVKY&HEFq@hDdp7", "m-gdt#2D5zoi4YM2Hhit", "m-NTC4tVXxAxkhMDhD%P", "m-QHQbcWx$wr9vUcmbUR", "m-h$y@NQnf7FHMmWvN9#", "m-MvATVq*BiqxaKT%m4y", "m-F47P2WPa8*ezpag2o4", "m-J7MFwgA7o!Y93dDoJ8", "m-LJBHaKZHSwkUGnrdt2", "m-e9x!sF9eJeUxAdXGEk", "m-bmGSSC@rHWezMB7HG4", "m-iHwm3Y3ePL3MqB75#G", "m-m9dk5nVg%V@u@8%Jde", "m-ZgbmT8e@L*HgmPHYLz", "m-BGPTgqtx@DPhrV*XAw", "m-n85C*XaszkjyQ@KdCj", "m-YDRVM$J9yG*LcJQCkG", "m-jWZkpfPVEfSy9VQ8#6", "m-Ro4o*yrxiG9Yv9MuDN", "m-2hSQvXEnTuEuUYTiMJ", "m-9dmNwr9VmibywUAhSQ", "m-ps*AGFbf#o8*qcE9*S", "m-dT@t9C#gFTMHH8zkrm", "m-LT$7RXi!Nfbz3griK%", "m-fXSMwUfhAn%faq7L%b"),
        "a" to listOf("a-ETNVoW4Lw8mu3d@beS", "a-j8YMWgkt3sY$HmUgVq", "a-GqTUEUShd!h@wdk#7m", "a-d*nj&UJe%Fw$gGi7a!", "a-Leayf5b7@AgpW2Bzv6", "a-ooZEG$XvT5!LQYUCPs", "a-Z$Qxtb4we26*n&g3Z2", "a-rzLQ*!SvB4f6uqUHr6", "a-v45%C8SrVjCw8&j&Qx", "a-*4BY*3n2Hgu4UB5iB!", "a-5ZB@jb&99smB6#8h6B", "a-Bb%qHMdktZJ*Mu8ZJi", "a-!oGHjoNGVFP9Ao4qTZ", "a-5wQcQq2DVaEqLJR7*N", "a-uiz9eC@f@Z#ccFc&WY", "a-*&dWQnGhix#$CYeVju", "a-JcBjYaYFFqXx@s&R7R", "a-xVb%b*DjA&xzSN3XyL", "a-p7S8%uKqWCM@aG%k5D", "a-jf8a8d4TwkZsbUexJf", "a-CUbt&8oSfTqR$DGw89", "a-Czs$Q*99@nVvBAv$Dp", "a-zAP*V5!ygforDVpWUJ", "a-Y*vMg!SrYemyk3Xupw", "a-5dSeM#*3H@hnXya*5*", "a-FAqXbN9g2K3#dm%6p6", "a-wYp&ZT*3*CBCvah5Gy", "a-WmjURJnHTHZLFSKgar", "a-5MRKxuFtLE4oo#PRxP", "a-UraSzKsXYd3wsKs6!b", "a-D27#Ecbf@a!zFYEufd", "a-%Vwk7W#pySgg@J8r*J", "a-pEcH6&UAkp%%@Tq8Yq", "a-s&Ef44#ecroUHWC3!*", "a-WYrDD35!RRqsyfMAs*", "a-ef6FHTC*T&hooRNdEB", "a-wktYcie53pd!9CxthS", "a-nUiStm8SGLJUjbAL@H", "a-e!PsxnHq2xpqg8wPs3", "a-24QC%&e@Ts@djuAZ&8", "a-oNHP8Dci3UA2Q2DUDD", "a-#u%n3%WbsCyN7!CnKE", "a-3@WBPpq9eejLTU!u4X", "a-LbXnJ*RS7L@JkgM6tL", "a-BX&J64TDQHgALHoWi5", "a-cAi3@4bSqAAtceRSRg", "a-P#k6CPTJQwYL7b#93!", "a-rCX%SSKX$LRo5iMoDN", "a-7K$KSpV2U!Cbxz*uc9", "a-@NDkm$G9KQTh2ivpnP", "a-zZxypEtZrhXKQYkaFX", "a-X$V9NTwAWczuiNa8gN", "a-Tvh7Ckdrxcj6c*HAH*", "a-LerZtQ9T#VG*&dwTs$", "a-tMZh4D9w$55dv6eW#p", "a-Awtt8#5sxv%qHNF5Be", "a-!gg3YLpK&LPhC6Krb8", "a-VsUhYfWaPNU#3HQR3m", "a-JUiMUzj&qYWkWQxFYR", "a-&23M&i4mta%!tCHSG6", "a-gCBT5avgqa&!vTh!y4", "a-a2VCy$DPVvv958rMN8", "a-7*ik2!ngNjR%BgAmy3", "a-LrfjqYwuqZJaG#RK78", "a-2oz7TJuAVhLy92ueKj", "a-rt!9$a6rPDxQq#8Rd$", "a-kSmLG5B%Wet5bk5Prs", "a-xhCEKtZDggaR5WPqzV", "a-XRwj4d!pDbEAz6C@RJ", "a-U#!JnCMSExPpYHGq$b", "a-fvsQEQNMUaS8BEXhd$", "a-9cPhUXPaUtfSWwZ8sA", "a-mQ$PqDy9KRLP$5rX#k", "a-GnQ3QLEUZzhvdjtQ#4", "a-8rAKtDvKVsU%sY!Yg4", "a-qaG!!ZFQpmta&vzCo2", "a-9Sm!m*ky7rTtt!Lf3T", "a-h&9UUnqmNictmyzP7Z", "a-oZ#$tiGA6j*Md#R%bu", "a-j!p4kfNf3Pf#GM&v@n", "a-nBzHin%PKa!grPTz@e", "a-sKjgZ3GnYeKuGiz7Bv", "a-2355hkaTaKNz#585&D", "a-k#iQpE6aM%PCp&uH3u", "a-AW7ixS&i7B&f8w$jyP", "a-$uHs9JPRTLF$F5!KgL", "a-wuHboyYu97UoHT%Hg!", "a-NCEgp@QfkAvhVYBew3", "a-*EdBqSsLLnc24RfDk#", "a-8BpCyn!9DxA9Wpktop", "a-6DPmpssXW72ppGEqW#", "a-zhj7Au36Cz23T5@3xb", "a-@t3$habSR*hqD$&5tU", "a-B5h6wmHguUBY8hKuNx", "a-5U%7$&bWTP&QseHFy7", "a-GobB%vLJS@GNqJcPZr", "a-4eaHdT!gYsbsTetBM&", "a-bRRirZu9@GwJwCh#E3", "a-zYu*Rm7rsn$nB%vNqR", "a-izDQ@ZR%$*9iQuXd!V", "a-bHBW%gkzmXp%@TYuKN", "a-8cNVL7fx8WfAB6XsjK", "a-PNDkr!uGSVDCQaTcAF", "a-xqKrXzShixYbJCbN!a", "a-tM3D*sD32RtPzp!wMX", "a-U6Z*Rp8t3jpGj6v7vC", "a-$Nrud3DEEQCC4hE!Nb", "a-Vku4E353uSCCJu&@wk", "a-5xKAco44H*f@&gcPA2", "a-GpqyyW5LnH&tr&et3U", "a-yWFQyy6&cUMMn9!kor", "a-uADPKAqGnHDzyTBfYh", "a-yhXDbnQ7QEtgqqRmTT", "a-QZftnj9cU5uvURz@b6", "a-&mA$a#3V@aCd4gQH@u", "a-ua2%!v&Ni*5C@bY@7m", "a-PMB6fiDYxKdeHZh!ki", "a-moSWKdAWt@@euzVq8K", "a-bGPyPwbAWYtu3uJmqg", "a-2zYUk2SmdxttysLBnz", "a-Dw3qeAsbwgKvVysQcz", "a-Y88Z5ELNm##b*NNRMV", "a-RsP5LCE8uiZtkK&irf", "a-9sT4zhJDGf@pysbvPH", "a-7sZzKbhKHqj77hV!Tf", "a-K2bxfdMMGbe*KV!DAw", "a-ye76BRQMWQB6pqRH6h", "a-8Qfn3ruEbwxqUa27p!", "a-Myg#yh@hyiFSmhxHSh", "a-2sgZ!WWp2&wCh2e*HF", "a-DyzDYjo6Pb6viXnt&e", "a-#VmYuRUyPU#ijgYHVq", "a-QoQU8AvLheR&!x&7AB", "a-FTEYuT*s9mR6!!EHUx", "a-$vbiL#QWozvX&srnXn", "a-R84QqNVSsANFhuJ#oj", "a-Xg8#txvYpY3W#%gMPw", "a-V3NhVoLbPrn9Cff$&P", "a-@h9c4m&99fm#$bTfwb", "a-$HioJR#jtn#X#fVKUg", "a-MRVohH@ZNU2BET42yx", "a-fT#W6UK@Q#rzG5yu2R", "a-ny7TC6o2kH@5*JBA2d", "a-8%W3F&KPJdtiYZUcyz", "a-MA@7t&WW2aeHNZb5m8", "a-ZCanDgiT9bKswos6AV", "a-$fY!PTjo8Ea95#X8tJ", "a-V@jkP#sKn@dzDSZVob", "a-LVbbfx##SbRaEqsig3", "a-uca!2&X%6BB6&pLsAR", "a-Q!eaPeV4e64ZZFmHs!", "a-5ZTQoJTj5xgFTxwQXJ", "a-2oyjNRNN$Rio7b%3!w", "a-6F9VRi9dtWPf@7#zu!", "a-gpANGLAgH8J&ZV&P!!", "a-Zmc#@3Qt5K!*bQo2TH", "a-37DCca$x5zRoqVE*@P", "a-vRv5WhnVwGmSL3yF6@", "a-2YwL2h59uGR5F!3Kci", "a-@ddQ%hNLec9&d93GFN", "a-*%b@JvVL&LrtJH@jzf", "a-j6p3tT*BCd!ZjiZst!", "a-PUvpR8GweGCM4!S7oe", "a-7ohkXWWgASrHs4jCV@", "a-8eqB$mpa*nk$Z6T3U3", "a-kCL8eQYS3cM&WVZMUX", "a-MzeW&$N3XrwTRHhS7N", "a-PrRGzrrW$H5Qx!3qxR", "a-fstLaY!6#rBWUdF2jF", "a-dD5RPbKW6b%LsLRJX6", "a-oz%AJg%@!L8M*H7gY2", "a-U4Zn#B%*7v3CjZ2GX%", "a-P!!xnaeentpQGdfJ5G", "a-&7mpQYd$cFGwuXvHuR", "a-!8S3CfCJX8!@&Y9&%E", "a-xwcBkYkb!Nahrpn$Ww", "a-gVxqvtQ$F#ugij8PAe", "a-kePUARrQfh&BdoAAFo", "a-mAoQgpQiVxnwePFro5", "a-$FE*c$H@LDC4JjQMuB", "a-y$p2D8Lvp#M@rbxw%y", "a-AkZGk@DbEV@tQcBW92", "a-ehz4gysW5CN4cFtvgq", "a-Lr8*7XhG$j6PLk@m5z", "a-&qYHgG3mCRY#@J!Kat", "a-$S*ojLU@6NpxyDv4gU", "a-DUjT9V9qHKnJt$$PYk", "a-2YoaRc62%xWZ9Xsvwg", "a-P3Jds8JFKP9LfEBNq*", "a-@5sAJ$Z$pM@2Nwgway", "a-xVF6rW#bi#M&Zo*U8L", "a-#hkCwVZ!dJHhmyGxh9", "a-bZ7eSSX9Dfed#3Fg$A", "a-6&xGTgSyE%5N!k$5FS", "a-Sv&L$M3%NX8AdHKSV&", "a-y6ynK2Yp%ajpPAZug$", "a-C*crcF@9oq*LtqVQj7", "a-WJ&ynzx3N@d*XrwqSM", "a-2mTkLtp3zVhijwE3%K", "a-r@TA@*cMG!GBHgYWYX", "a-@c$Ekr8dnmNLNz2vUM", "a-yA5PGeTicyC!V5nuY3", "a-TEkwEBefrHc*V3Jv*f", "a-cXgswuVQNoZkMJVpM2", "a-iiZ4NcM8U&BwHTtuh#", "a-LHuGqNfFJbbvK@!Mre", "a-XosUcsnG@pr!a!vKh$", "a-AhpL7qnv%M6c2GLWHy", "a-fkQ3Daab@qZRK7HF#g", "a-FBt48swgbN!gCVzNUq", "a-NisJb4K9MX5MfQrwN&", "a-CiJ!g$@WyD$2NrWywq", "a-xrYuseFFqy$wj$Zrst", "a-R4oef53qQN&2VEouM5", "a-FpdUn942uiS6MnKZuc", "a-tB!RLzDsSfuR9awNWd", "a-hakbwZ@tZCMuYY$gZi", "a-EoHHNdqS7KAtBjK%j&", "a-ubM2Krzr6cY8TXj!$o", "a-ZEEkoLP3Hz5xMwMvKz", "a-X#YfzJTjY#j2Jsr#F!", "a-AD$czBH*!CA@N47cs4", "a-jeP3f4BqN9!RFNaRAA", "a-gR!Eo6HB66S%noSexJ", "a-inH@TUaQoNRFTG$$Pq", "a-6&t4t3yvfB92Mp8Nmt", "a-g2zui%z!zD#SvjiFQ2", "a-JjPBBbTbEBqoQDuofC", "a-qm459XU4MYcaV3%k7Q", "a-nnQJX#&%L!mQuzsJg$", "a-JDZ*pQY6Nw2QCzLhJ6", "a-jJUaHLZwBD#N!gDNaC", "a-Xwmvmtvfd$CRrKQWj9", "a-4df3myGeAVqWUZ6gHX", "a-bVWdngeh48eG3DL3Wo", "a-ZgsKbjD9dpagKt2S2M", "a-EKgAZ*VRU@p@$%RKQN", "a-YcERBTime3QLwCK7i%", "a-Wat7kc$mG4itLE@sC2", "a-iKKkYmu8n7EcQSM7tA", "a-2Hiz#oRkeXWVvZoas&", "a-Nfv!ds3n!ux6MSxXqx", "a-&nY&XdrivqLgjNEdeJ", "a-%9Jv6Bb3%@vSG*VyuV", "a-9A$6qkc5mT3LcozDX3", "a-wai9t@qLvid9aM6VYM", "a-hEngTTTvv!3Jzomtvu", "a-8RfSzm6LL$ZJPKNmAN", "a-fT48$rUDHGS$w4SQFs", "a-oUQcf567Huojic8XCm")
    )

    private val LICENSE_SECRET = "SS7-LICENSE-2026-v1-7f3c9a2d4e6b8c1a5f0e9d3b7a6c2e4f"

    private fun generatePortableLicense(prefix:String, temporary:Boolean):String{
        val nonce=ByteArray(10).also{SecureRandom().nextBytes(it)}
        val id=Base64.getUrlEncoder().withoutPadding().encodeToString(nonce)
        val type=if(temporary) "T" else "P"
        val data="SS1|$prefix|$type|$id"
        val sig=hmac(data).take(16)
        return "SS1-$prefix-$type-$id-$sig"
    }

    private fun hmac(data:String):String{
        val mac=Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(LICENSE_SECRET.toByteArray(StandardCharsets.UTF_8),"HmacSHA256"))
        return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray(StandardCharsets.UTF_8)))
    }

    private fun generateBuiltinLicense(prefix:String):String?{
        val all=BUILTIN_LICENSES[prefix] ?: return null
        val issued=JSONArray(prefs.getString("licenses","[]"))
        val used=HashSet<String>()
        for(i in 0 until issued.length()) used.add(issued.getJSONObject(i).optString("code"))
        all.firstOrNull{!used.contains(it)}?.let{return it}
        return null
    }

    private fun addLicenseRecord(code:String,prefix:String,temporary:Boolean){
        val arr=JSONArray(prefs.getString("licenses","[]"))
        arr.put(JSONObject().put("code",code).put("prefix",prefix).put("temporary",temporary).put("used",false))
        prefs.edit().putString("licenses",arr.toString()).apply()
    }

    private fun validatePortableLicense(code:String):Pair<String,Boolean>?{
        val parts=code.trim().split('-')
        if(parts.size!=5 || parts[0]!="SS1") return null
        val prefix=parts[1]
        val type=parts[2]
        val id=parts[3]
        val sig=parts[4]
        if(prefix !in listOf("s","m","a") || type !in listOf("P","T") || id.isBlank() || sig.isBlank()) return null
        val data="SS1|$prefix|$type|$id"
        if(!constantTimeEquals(hmac(data).take(16),sig)) return null
        return Pair(prefix,type=="T")
    }

    private fun constantTimeEquals(a:String,b:String):Boolean{
        val aa=a.toByteArray(StandardCharsets.UTF_8); val bb=b.toByteArray(StandardCharsets.UTF_8)
        if(aa.size!=bb.size) return false
        var diff=0
        for(i in aa.indices) diff = diff or (aa[i].toInt() xor bb[i].toInt())
        return diff==0
    }

    private fun temporaryLicenseId(code:String):String?{
        val parts=code.trim().split('-')
        return if(parts.size==5 && parts[0]=="SS1" && parts[2]=="T") parts[3] else null
    }

    private fun isTemporaryUsedOnThisDevice(id:String):Boolean =
        prefs.getStringSet("temporary_used_ids", emptySet())?.contains(id) == true

    private fun consumeTemporaryLicense(code:String){
        val id=temporaryLicenseId(code) ?: return
        val set=(prefs.getStringSet("temporary_used_ids", emptySet()) ?: emptySet()).toMutableSet()
        set.add(id)
        prefs.edit().putStringSet("temporary_used_ids",set).apply()
    }

    private fun validateLicense(code:String):Pair<String,Boolean>?{
        val clean=code.trim()
        for((prefix,list) in BUILTIN_LICENSES){
            if(list.contains(clean)) return Pair(prefix,false)
        }
        val portable=validatePortableLicense(clean)
        if(portable!=null){
            if(portable.second){
                val id=temporaryLicenseId(code) ?: return null
                if(isTemporaryUsedOnThisDevice(id)) return null
            }
            return portable
        }
        // سازگاری با کدهای قدیمی فقط روی همان گوشی؛ کدهای جدید همیشه قابل انتقال‌اند.
        if(code.length<2) return null
        val arr=JSONArray(prefs.getString("licenses","[]")); val h=hash(code)
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i)
            if(o.optString("hash")==h){
                if(o.optBoolean("temporary") && o.optBoolean("used")) return null
                return Pair(o.optString("prefix"),o.optBoolean("temporary"))
            }
        }
        return null
    }

    private fun showLicenseList(){
        val arr=JSONArray(prefs.getString("licenses","[]"));val text=StringBuilder()
        if (arr.length() == 0) {
            text.append("هنوز هیچ کدی صادر نشده است.")
        } else {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val typeLabel = if (o.optBoolean("temporary")) "موقت" else "دائمی"
                val statusLabel = if (o.optBoolean("used")) " — مصرف شده" else " — فعال"
                text.append(i + 1).append(". سطح ").append(o.optString("prefix"))
                    .append(" — ").append(typeLabel).append(statusLabel).append("\n")
            }
        }
        android.app.AlertDialog.Builder(this).setTitle("📋 کدهای صادرشده").setMessage(text.toString()).setPositiveButton("بستن",null).show()
    }

    private fun showBrandingSettings(){
        val box=page("🎨 نام و لوگوی برنامه")
        box.addView(TextView(this).apply{
            text="از این بخش مدیر می‌تواند نام نمایشی برنامه و لوگوی داخل برنامه را تغییر دهد. تغییرات روی صفحه اصلی برنامه ذخیره می‌شود."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val name=EditText(this).apply{
            hint="نام جدید برنامه"
            setText(prefs.getString("app_display_name","Secure Studio"))
        }
        btn(box,"💾 ذخیره نام برنامه"){
            val n=name.text.toString().trim()
            if(n.length in 2..40){prefs.edit().putString("app_display_name",n).apply();toast("نام برنامه تغییر کرد.");showHome()}
            else toast("نام برنامه باید بین ۲ تا ۴۰ کاراکتر باشد.")
        }
        btn(box,"🖼️ انتخاب لوگو از گالری"){
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            },PICK_LOGO)
        }
        btn(box,"↩️ بازگردانی نام و لوگوی پیش‌فرض"){
            prefs.edit().remove("app_display_name").remove("app_logo_uri").apply();toast("نام و لوگوی پیش‌فرض بازگردانده شد.");showHome()
        }
        back(box);setContentView(box)
    }


    private val PICK_MEDIA_IMAGE = 3001
    private val PICK_MEDIA_VIDEO = 3002
    private val PICK_MEDIA_AUDIO = 3003
    private val PICK_AUDIO_ENCRYPT = 3004
    private val PICK_AUDIO_DECRYPT = 3005
    private var selectedMediaUri: Uri? = null
    private var selectedImageBitmap: Bitmap? = null
    private var audioPlayer: MediaPlayer? = null

    private fun showImageEditor(){
        val box=page("📸 ویرایشگر تصویر آفلاین")
        val preview=ImageView(this).apply{minimumHeight=260;scaleType=ImageView.ScaleType.CENTER_INSIDE;setBackgroundColor(0xFF17231F.toInt())}
        val info=TextView(this).apply{text="یک تصویر انتخاب کنید؛ عملیات اصلی کاملاً روی گوشی انجام می‌شود.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        var bitmap:Bitmap?=selectedImageBitmap
        btn(box,"📂 انتخاب تصویر"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_IMAGE)}
        btn(box,"↻ چرخش ۹۰ درجه"){bitmap?.let{val m=Matrix();m.postRotate(90f);bitmap=Bitmap.createBitmap(it,0,0,it.width,it.height,m,true);preview.setImageBitmap(bitmap)}?:toast("ابتدا تصویر را انتخاب کنید.")}
        btn(box,"⚫ سیاه‌وسفید"){bitmap?.let{val b=it.copy(Bitmap.Config.ARGB_8888,true);b.setHasAlpha(false);val c=ColorMatrix();c.setSaturation(0f);preview.colorFilter=ColorMatrixColorFilter(c);bitmap=b}?:toast("ابتدا تصویر را انتخاب کنید.")}
        btn(box,"💾 ذخیره تصویر"){bitmap?.let{saveBitmap(it);preview.clearColorFilter()}?:toast("ابتدا تصویر را انتخاب کنید.")}
        box.addView(info,1);box.addView(preview,2);back(box);setContentView(box)
        bitmap?.let { preview.setImageBitmap(it) }
    }

    private fun showVideoEditor(){
        val box=page("🎬 ابزار ویدیو آفلاین")
        val vv=VideoView(this).apply{setBackgroundColor(0xFF17231F.toInt())}
        val info=TextView(this).apply{text="انتخاب، پخش، توقف و مرور ویدیو روی خود دستگاه انجام می‌شود. برای ویرایش‌های سنگین مثل برش/افکت، موتور رسانه‌ای جداگانه در نسخه توسعه‌یافته لازم است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        btn(box,"📂 انتخاب ویدیو"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_VIDEO)}
        btn(box,"▶️ پخش"){if(vv.duration>0)vv.start()else toast("ابتدا ویدیو را انتخاب کنید.")}
        btn(box,"⏸ توقف"){vv.pause()}
        box.addView(info,1);box.addView(vv,2,LinearLayout.LayoutParams(-1,320));back(box);setContentView(box)
        selectedMediaUri?.let { try { vv.setVideoURI(it) } catch (_:Exception) { toast("ویدیو قابل پخش نیست.") } }
    }

    private fun showAudioEditor(){
        val box=page("🎵 ابزار صوت آفلاین")
        val status=TextView(this).apply{text="فایلی انتخاب نشده است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        btn(box,"📂 انتخاب فایل صوتی برای پخش"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_AUDIO)}
        btn(box,"▶️ پخش"){audioPlayer?.start()?:toast("ابتدا فایل صوتی را انتخاب کنید.")}
        btn(box,"⏸ توقف"){audioPlayer?.pause()?:toast("فایل صوتی انتخاب نشده است.")}
        btn(box,"⏹ توقف کامل"){audioPlayer?.stop();audioPlayer?.release();audioPlayer=null;status.text="پخش متوقف شد."}
        btn(box,"🔐 رمزنگاری فایل صوتی"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_AUDIO_ENCRYPT)}
        btn(box,"🔓 رمزگشایی فایل صوتی"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE)},PICK_AUDIO_DECRYPT)}
        box.addView(status,1);back(box);setContentView(box)
    }

    private fun encryptAudio(uri:Uri){
        try{
            val source=contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل قابل خواندن نیست")
            val data=source.use{it.readBytes()}
            require(data.isNotEmpty())
            val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)}
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE,getKey(),GCMParameterSpec(128,nonce))
            val encrypted=cipher.doFinal(data)
            val name="SecureStudio_EncryptedAudio_${System.currentTimeMillis()}.ssaudio"
            val outUri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                put(MediaStore.Downloads.DISPLAY_NAME,name)
                put(MediaStore.Downloads.MIME_TYPE,"application/octet-stream")
            }) ?: throw IllegalStateException("ساخت فایل خروجی ممکن نشد")
            contentResolver.openOutputStream(outUri)?.use{it.write(nonce);it.write(encrypted)} ?: throw IllegalStateException("نوشتن خروجی ممکن نشد")
            toast("فایل صوتی رمزنگاری شد و در Downloads ذخیره شد.")
        }catch(e:Exception){toast("خطا در رمزنگاری صوت: ${e.message ?: "نامشخص"}")}
    }

    private fun decryptAudio(uri:Uri){
        try{
            val source=contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل قابل خواندن نیست")
            val data=source.use{it.readBytes()}
            require(data.size>28)
            val nonce=data.copyOfRange(0,12)
            val payload=data.copyOfRange(12,data.size)
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE,getKey(),GCMParameterSpec(128,nonce))
            val plain=cipher.doFinal(payload)
            val name="SecureStudio_DecryptedAudio_${System.currentTimeMillis()}.audio"
            val outUri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                put(MediaStore.Downloads.DISPLAY_NAME,name)
                put(MediaStore.Downloads.MIME_TYPE,"audio/*")
            }) ?: throw IllegalStateException("ساخت فایل خروجی ممکن نشد")
            contentResolver.openOutputStream(outUri)?.use{it.write(plain)} ?: throw IllegalStateException("نوشتن خروجی ممکن نشد")
            toast("فایل صوتی با موفقیت رمزگشایی شد و در Downloads ذخیره شد.")
        }catch(e:Exception){toast("رمزگشایی صوت ناموفق است؛ فایل، کلید یا محتوای آن معتبر نیست.")}
    }

    private fun showTranslator(){
        val box=page("🌐 مترجم آفلاین پایه")
        val input=EditText(this).apply{hint="متن فارسی یا انگلیسی";minLines=5;gravity=48}
        val output=EditText(this).apply{hint="ترجمه آفلاین";minLines=5;gravity=48}
        btn(box,"🔄 ترجمه آفلاین"){output.setText(offlineTranslate(input.text.toString()))}
        btn(box,"📋 کپی ترجمه"){copyText(output.text.toString());toast("ترجمه کپی شد.")}
        box.addView(TextView(this).apply{text="این نسخه یک واژه‌نامه آفلاین پایه دارد و برای ترجمه کامل چندزبانه به موتور ترجمه نیاز است.";setTextColor(0xFF9FCBC1.toInt())},1)
        box.addView(input,2);box.addView(output,4);back(box);setContentView(box)
    }

    private fun offlineTranslate(t:String):String{
        val dict=mapOf("hello" to "سلام","hi" to "سلام","thanks" to "ممنون","thank you" to "متشکرم","yes" to "بله","no" to "خیر","good" to "خوب","bad" to "بد","سلام" to "hello","ممنون" to "thanks","بله" to "yes","خیر" to "no","خوب" to "good")
        return dict[t.trim().lowercase()] ?: "برای این عبارت، ترجمه آفلاین در واژه‌نامه فعلی موجود نیست."
    }

    private fun showVoiceTools(){
        val box=page("🎙️ ابزار صوت و گفتار")
        box.addView(TextView(this).apply{text="امکانات صوتی پایه آفلاین\n\n• تبدیل متن به گفتار با موتور داخلی Android\n• پخش و کنترل صوت\n\nتبدیل/کلون‌سازی صدای حرفه‌ای هنوز موتور اختصاصی می‌خواهد و در این نسخه به‌صورت محلی شبیه‌سازی نمی‌شود.";setTextColor(0xFFEAF7F4.toInt());setPadding(0,0,0,16)})
        val input=EditText(this).apply{hint="متن برای خواندن";minLines=4}
        btn(box,"🔊 خواندن متن با صدای دستگاه"){if(input.text.isBlank())toast("متن را وارد کنید.")else{lateinit var tts: android.speech.tts.TextToSpeech
tts = android.speech.tts.TextToSpeech(this){status->if(status==android.speech.tts.TextToSpeech.SUCCESS){tts.speak(input.text.toString(), android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "securestudio_tts")}};toast("در حال آماده‌سازی موتور گفتار...")}}
        box.addView(input,1);back(box);setContentView(box)
    }

    private val ttsLocaleHack: Unit get() = Unit

    private fun validAdminPassword(p:String):Boolean{val symbols=p.count{!it.isLetterOrDigit()};return p.length in 8..22&&symbols>=2}
    private fun changeSecurityQuestion(){
        val box=page("🛡️ تغییر سؤال امنیتی مدیر")
        val question = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(
                "نام اولین مدرسه شما چه بود؟",
                "نام اولین شهر محل زندگی شما چه بود؟",
                "نام یک دوست دوران کودکی شما چه بود؟",
                "غذای مورد علاقه شما چیست؟"
            ))
            setSelection(prefs.getInt("security_question",0))
        }
        val answer=EditText(this).apply{hint="پاسخ جدید سؤال امنیتی"}
        btn(box,"💾 ذخیره سؤال امنیتی جدید"){
            val a=answer.text.toString().trim()
            if(a.length>=2){prefs.edit().putInt("security_question",question.selectedItemPosition).putString("security_answer",hash(a)).apply();toast("سؤال امنیتی تغییر کرد.");showAdminPanel()}
            else toast("پاسخ سؤال امنیتی را وارد کنید.")
        }
        box.addView(question);box.addView(answer);back(box);setContentView(box)
    }

    private fun changeAdminPassword(){
        val input=EditText(this).apply{hint="رمز جدید مدیر (8 تا 22 کاراکتر، حداقل 2 نماد)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialogBuilder("🔄 تغییر رمز مدیر",input){val p=input.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).apply();toast("رمز مدیر تغییر کرد.")}else toast("رمز شرایط لازم را ندارد.")}.show()
    }

    private fun setPin(){val input=EditText(this).apply{hint="PIN حداقل 6 رقم";inputType=2};AlertDialogBuilder("تنظیم PIN",input){val p=input.text.toString();if(p.length>=6){prefs.edit().putString("pin",hash(p)).apply();toast("PIN ذخیره شد.")}else toast("PIN باید حداقل 6 رقم باشد.")}.show()}
    private fun verifyPin(){val input=EditText(this).apply{hint="PIN";inputType=2};AlertDialogBuilder("باز کردن قفل",input){if(hash(input.text.toString())==prefs.getString("pin",null))toast("قفل باز شد.")else toast("PIN نادرست است.")}.show()}

    private fun copyText(value:String){
        val clip=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clip.setPrimaryClip(android.content.ClipData.newPlainText("SecureStudio",value))
    }

    private fun hash(s:String):String{val md=java.security.MessageDigest.getInstance("SHA-256");return Base64.getEncoder().encodeToString(md.digest(s.toByteArray(StandardCharsets.UTF_8)))}
    private fun encrypt(text:String):String{
        require(text.isNotEmpty())
        val key=getKey()
        val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)}
        val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE,key,GCMParameterSpec(128,nonce))
        val encrypted=c.doFinal(text.toByteArray(StandardCharsets.UTF_8))
        return Base64.getEncoder().encodeToString(nonce+encrypted)
    }
    private fun decrypt(encoded:String):String{
        val clean=encoded.trim()
        require(clean.isNotEmpty())
        val all=try{Base64.getDecoder().decode(clean)}catch(e:IllegalArgumentException){throw IllegalArgumentException("Base64 نامعتبر",e)}
        require(all.size>12)
        val nonce=all.copyOfRange(0,12)
        val payload=all.copyOfRange(12,all.size)
        require(payload.size>=16)
        val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE,getKey(),GCMParameterSpec(128,nonce))
        return String(c.doFinal(payload),StandardCharsets.UTF_8)
    }
    private fun getKey():SecretKey{val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)};if(ks.containsAlias("SecureStudioKey"))return(ks.getKey("SecureStudioKey",null) as SecretKey);val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(KeyGenParameterSpec.Builder("SecureStudioKey",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return kg.generateKey()}
    private fun showExtracted(text:String){AlertDialogBuilder("پیام استخراج‌شده",TextView(this).apply{this.text=text;setTextColor(0xFFEAF7F4.toInt());setPadding(20,20,20,20)}){}.show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun AlertDialogBuilder(title:String,view:android.view.View,onOk:()->Unit):android.app.AlertDialog=android.app.AlertDialog.Builder(this).setTitle(title).setView(view).setNegativeButton("انصراف",null).setPositiveButton("تأیید"){_,_->onOk()}.create()
}
