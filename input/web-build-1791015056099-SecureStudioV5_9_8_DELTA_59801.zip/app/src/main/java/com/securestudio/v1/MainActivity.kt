package com.securestudio.v1

import android.content.*
import android.graphics.*
import android.net.Uri
import android.os.*
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.Normalizer
import java.util.concurrent.Executors
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    private enum class Role { ADMIN, A, M, S, TEMPORARY }
    private data class Session(val role: Role, val started: Long)
    private var session: Session? = null
    private val executor = Executors.newCachedThreadPool()
    private val main = Handler(Looper.getMainLooper())
    private val sessionTimeout = 30 * 60 * 1000L
    private val prefs by lazy { getSharedPreferences("studio_state", MODE_PRIVATE) }

    // Hidden sequences. They are assembled at runtime instead of being stored as one plain literal.
    private val admin = decode(intArrayOf(0x09,0x33,0x34,0x71,0x77,0x70,0x75,0x6B,0x6B,0x6F,0x6B,0x7F,0x67,0x6B,0x69,0x6C,0x62))
    private val full = decode(intArrayOf(0x0E,0x3B,0x34,0x75,0x71,0x77,0x70,0x7F,0x67,0x6F,0x6D))
    private val medium = decode(intArrayOf(0x19,0x35,0x2E,0x70,0x71,0x7F,0x75,0x77,0x67,0x68,0x68))
    private val limited = decode(intArrayOf(0x19,0x35,0x29,0x71,0x70,0x7F,0x77,0x75,0x67,0x6A,0x6B))
    private val temporary = decode(intArrayOf(0x19,0x35,0x29,0x71,0x7F,0x7F,0x67,0x6A))
    private fun decode(a:IntArray)=a.map{(it xor 0x5A).toChar()}.joinToString("")

    private val PICK_IMAGE = 1101
    private val SAVE_IMAGE = 1102
    private val PICK_FILE_ENC = 1201
    private val SAVE_FILE_DEC = 1202
    private val PICK_STEGO_IMAGE = 1301
    private val SAVE_STEGO_IMAGE = 1302
    private val PICK_FILE_STEGO = 1401
    private val PICK_CARRIER_STEGO = 1402
    private val SAVE_FILE_STEGO_IMAGE = 1403
    private val PICK_FILE_FROM_IMAGE = 1404
    private val SAVE_EXTRACTED_FILE = 1405

    private var selectedImage: Uri? = null
    private var selectedFile: Uri? = null
    private var selectedCarrier: Uri? = null
    private var extractedTemp: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Security.secureWindow(this)
        session = null
        // Remove all state names used by earlier builds. No setup UI is ever shown.
        prefs.edit().clear().apply()
        showCalculator()
    }

    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }

    private fun role(): Role? {
        val s=session ?: return null
        if(SystemClock.elapsedRealtime()-s.started > sessionTimeout){session=null; return null}
        return s.role
    }

    private fun enter(r: Role){ session=Session(r,SystemClock.elapsedRealtime()); showDashboard() }
    private fun logout(){ session=null; selectedImage=null; selectedFile=null; selectedCarrier=null; extractedTemp?.delete(); extractedTemp=null; showCalculator() }

    private fun showCalculator(){
        val root=screen()
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(label("Secure Studio DELTA",20f,true),LinearLayout.LayoutParams(0,54,1f))
        top.addView(label("DELTA • بدون راه‌اندازی رمز",12f,false),LinearLayout.LayoutParams(190,54))
        root.addView(top)

        val display=TextView(this).apply{ text=""; gravity=Gravity.END or Gravity.CENTER_VERTICAL; textSize=30f; setTextColor(Color.WHITE); setPadding(16,0,16,0); background=box(0xFF111C1B.toInt(),0xFF304642.toInt(),22f) }
        root.addView(display,LinearLayout.LayoutParams(-1,84).apply{topMargin=10;bottomMargin=8})
        val history=label("",12f,false).apply{gravity=Gravity.END;setTextColor(0xFF8CA9A3.toInt())}
        root.addView(history,LinearLayout.LayoutParams(-1,34))
        val grid=GridLayout(this).apply{columnCount=4;useDefaultMargins=false}
        root.addView(grid,LinearLayout.LayoutParams(-1,0,1f))
        fun key(t:String,v:String=t,fn:(()->Unit)?=null){
            val b=TextView(this).apply{text=t;textSize=if(t.length>3)12f else 18f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);background=box(when(t){"="->0xFF287E6D.toInt();"AC","⌫"->0xFF613D45.toInt();else->0xFF172827.toInt()},0xFF38514D.toInt(),18f);setOnClickListener{fn?.invoke()?:display.append(v)}}
            grid.addView(b,GridLayout.LayoutParams().apply{width=0;height=0;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1,1f);rowSpec=GridLayout.spec(GridLayout.UNDEFINED,1,1f);setMargins(4,4,4,4)})
        }
        key("sin","Sin");key("cos","Cos");key("tan","Tan");key("cot","Cot")
        key("(");key(")");key("π","π");key("e","e")
        key("7");key("8");key("9");key("÷","/")
        key("4");key("5");key("6");key("×","*")
        key("1");key("2");key("3");key("−","-")
        key("0");key(".");key("%");key("+")
        key("√"){unary(display,history,"√"){sqrt(it)}};key("x²"){unary(display,history,"x²"){it*it}};key("1/x"){unary(display,history,"1/x"){if(it==0.0)throw ArithmeticException();1/it}};key("AC"){display.text="";history.text=""}
        key("⌫"){if(display.text.isNotEmpty())display.text=display.text.dropLast(1)};key("="){val s=display.text.toString().trim();when{s==admin->{enter(Role.ADMIN)};s==full->{enter(Role.A)};s==medium->{enter(Role.M)};s==limited->{enter(Role.S)};s==temporary->{enter(Role.TEMPORARY)};else->{try{val r=Calculator.eval(s);history.text="$s = $r";display.text=r}catch(e:Exception){toast("عبارت نامعتبر است")}}}}
        setContentView(root)
    }

    private fun unary(display:TextView,history:TextView,name:String,op:(Double)->Double){try{val x=display.text.toString().toDouble();val r=op(x);require(r.isFinite());history.text="$name($x) = $r";display.text=r.toString()}catch(_:Exception){toast("عدد معتبر وارد کنید")}}

    private fun showDashboard(){
        val r=role()?:return showCalculator(); val root=screen()
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        head.addView(label("Secure Studio DELTA",22f,true),LinearLayout.LayoutParams(0,56,1f));head.addView(label(roleName(r),13f,true),LinearLayout.LayoutParams(130,56));root.addView(head)
        root.addView(label("DELTA-59801 • بدون ورود رمز • کاملاً آفلاین",13f,false))
        section(root,"خدمات")
        if(r==Role.ADMIN||r==Role.A||r==Role.M||r==Role.S||r==Role.TEMPORARY) button(root,"🔐 رمزنگاری و رمزگشایی پیام"){showTextCrypto()}
        if(r==Role.ADMIN||r==Role.A||r==Role.M||r==Role.S||r==Role.TEMPORARY) button(root,"🔢 متن و Binary"){showBinary()}
        if(r==Role.ADMIN||r==Role.A||r==Role.M) button(root,"🖼️ پیام رمزنگاری‌شده داخل تصویر"){showMessageStego()}
        if(r==Role.ADMIN||r==Role.A||r==Role.M) button(root,"📦 رمزنگاری فایل آفلاین"){showFileCrypto()}
        if(r==Role.ADMIN||r==Role.A||r==Role.M) button(root,"🖼️📦 فایل رمزنگاری‌شده داخل تصویر"){showFileStego()}
        if(r==Role.ADMIN||r==Role.A||r==Role.M) button(root,"💬 اتاق پیام آفلاین"){showChat()}
        if(r==Role.ADMIN) button(root,"⚙️ پنل مدیریت"){showAdmin()}
        section(root,"جلسه")
        button(root,"🛡️ وضعیت امنیتی"){showSecurity()}
        button(root,"🚪 خروج امن"){logout()}
        setContentView(root)
    }

    private fun showTextCrypto(){
        val root=page("🔐 رمزنگاری پیام")
        val input=edit("پیام را به هر زبان Unicode وارد کنید…",8);val output=edit("خروجی رمزنگاری/رمزگشایی…",8)
        root.addView(input);root.addView(output)
        button(root,"🔐 رمزنگاری"){runBg("در حال رمزنگاری…",root){val text=Normalizer.normalize(input.text.toString(),Normalizer.Form.NFC);require(text.isNotBlank());val enc=Crypto.encrypt(text);main.post{output.setText(enc)}}}
        button(root,"🔓 رمزگشایی"){runBg("در حال رمزگشایی…",root){val c=input.text.toString().trim().ifBlank{output.text.toString().trim()};val p=Crypto.decrypt(c);main.post{output.setText(p)}}}
        button(root,"↔️ انتقال خروجی به ورودی"){input.setText(output.text.toString())}
        button(root,"🧹 پاک کردن"){input.text.clear();output.text.clear()}
        back(root);setContentView(root)
    }

    private fun showBinary(){
        val root=page("🔢 متن و Binary");val input=edit("متن…",6);val output=edit("نتیجه…",10);root.addView(input);root.addView(output)
        button(root,"متن → Binary"){val bytes=input.text.toString().toByteArray(Charsets.UTF_8);output.setText(bytes.joinToString(" "){String.format("%8s",Integer.toBinaryString(it.toInt() and 255)).replace(' ','0')})}
        button(root,"Binary → متن"){try{val bits=input.text.toString().trim().split(Regex("\\s+"));val bytes=ByteArray(bits.size){bits[it].toInt(2).toByte()};output.setText(String(bytes,Charsets.UTF_8))}catch(_:Exception){toast("Binary نامعتبر است")}}
        back(root);setContentView(root)
    }

    private fun showMessageStego(){
        val root=page("🖼️ پیام رمزنگاری‌شده داخل تصویر")
        val info=label("ورودی تصویر: قالب‌های تصویری قابل decode توسط Android پشتیبانی می‌شوند. خروجی همیشه PNG است تا LSB حفظ شود.",13f,false);root.addView(info)
        val message=edit("پیام… فارسی، العربية، English، Русский، 中文، 日本語 و Unicode…",8);root.addView(message)
        val status=label("تصویری انتخاب نشده",13f,false);root.addView(status)
        button(root,"🖼️ انتخاب تصویر"){pickImage(PICK_IMAGE)}
        button(root,"🔐 جاسازی پیام رمزنگاری‌شده و ذخیره PNG"){val uri=selectedImage?:return@button toast("ابتدا تصویر را انتخاب کنید");runBg("در حال رمزنگاری و جاسازی…",root){val bm=ImageCodec.decode(contentResolver,uri);val cipher=Crypto.encrypt(Normalizer.normalize(message.text.toString(),Normalizer.Form.NFC));val payload=cipher.toByteArray(Charsets.UTF_8);val cap=Stego.capacity(bm);require(payload.size.toLong()+14<=cap){"ظرفیت تصویر کافی نیست."};val out=Stego.embed(bm,payload);main.post{pendingSaveBitmap=out;createImageOutput()}}}
        button(root,"🔓 استخراج و رمزگشایی پیام"){val uri=selectedImage?:return@button toast("ابتدا تصویر را انتخاب کنید");runBg("در حال استخراج…",root){val bm=ImageCodec.decode(contentResolver,uri);val payload=Stego.extract(bm);val plain=Crypto.decrypt(String(payload,Charsets.UTF_8));main.post{message.setText(plain);status.text="پیام با موفقیت استخراج و رمزگشایی شد."}}}
        button(root,"🧹 پاک کردن"){message.text.clear();status.text="تصویری انتخاب نشده";selectedImage=null}
        back(root);setContentView(root)
    }

    private fun showFileCrypto(){
        val root=page("📦 رمزنگاری فایل آفلاین")
        root.addView(label("هیچ سقف مصنوعی برای حجم فایل تعیین نشده است. محدودیت واقعی فقط ظرفیت ذخیره‌سازی، حافظه و توان دستگاه است. پردازش به‌صورت Streaming انجام می‌شود.",13f,false))
        button(root,"🔐 انتخاب فایل و رمزنگاری"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},PICK_FILE_ENC)}
        button(root,"🔓 انتخاب فایل SSF و رمزگشایی"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},PICK_FILE_ENC+1)}
        back(root);setContentView(root)
    }

    private fun showFileStego(){
        val root=page("🖼️📦 فایل رمزنگاری‌شده داخل تصویر")
        root.addView(label("ابتدا فایل رمزنگاری می‌شود، سپس فایل رمزنگاری‌شده داخل بیت‌های RGB تصویر قرار می‌گیرد. ظرفیت واقعی تصویر تنها محدودیت فیزیکی است.",13f,false))
        button(root,"1) انتخاب فایل"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},PICK_FILE_STEGO)}
        button(root,"2) انتخاب تصویر حامل"){pickImage(PICK_CARRIER_STEGO)}
        button(root,"3) رمزنگاری، جاسازی و ذخیره PNG"){val f=selectedFile;val c=selectedCarrier;if(f==null||c==null)return@button toast("فایل و تصویر را انتخاب کنید");runBg("در حال پردازش فایل و تصویر…",root){val temp=File(cacheDir,"payload_${System.nanoTime()}.ssf");try{FileCrypto.encrypt(contentResolver,f,temp);val bm=ImageCodec.decode(contentResolver,c);require(temp.length()+46<=FileStego.capacity(bm)){"ظرفیت تصویر کافی نیست."};val out=FileStego.embed(bm,temp,bm.copy(Bitmap.Config.ARGB_8888,true));main.post{pendingSaveBitmap=out;createImageOutput()}}finally{temp.delete()}}}
        button(root,"4) استخراج فایل رمزنگاری‌شده از تصویر"){pickImage(PICK_FILE_FROM_IMAGE)}
        back(root);setContentView(root)
    }

    private fun showChat(){
        val root=page("💬 اتاق پیام آفلاین")
        val list=TextView(this).apply{setTextColor(Color.WHITE);textSize=15f;setPadding(8,8,8,8);text="اتاق عمومی\n\nاین بخش فقط روی همین دستگاه کار می‌کند و شبکه‌ای نیست."}
        root.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        val input=edit("پیام محلی…",3);root.addView(input)
        button(root,"ارسال محلی"){if(input.text.isNotBlank()){list.append("\n\nشما: ${input.text}");input.text.clear()}}
        back(root);setContentView(root)
    }

    private fun showAdmin(){val root=page("⚙️ پنل مدیریت");root.addView(label("مدیریت از مسیر مخفی ماشین‌حساب وارد شده است. هیچ فرم ورود متنی در برنامه وجود ندارد.",14f,false));button(root,"پاک‌سازی وضعیت محلی"){prefs.edit().clear().apply();toast("وضعیت محلی پاک شد")};button(root,"خروج امن"){logout()};setContentView(root)}
    private fun showSecurity(){val root=page("🛡️ وضعیت امنیتی");root.addView(label("• برنامه آفلاین است\n• Screenshot/recording protection فعال است\n• جلسه فقط در حافظه نگهداری می‌شود\n• خروج امن جلسه را حذف می‌کند\n• داده‌های رمزنگاری‌شده با Android Keystore محافظت می‌شوند\n• ورود متنی و صفحه راه‌اندازی حذف شده است",15f,false));back(root);setContentView(root)}

    private var pendingSaveBitmap:Bitmap?=null
    private fun createImageOutput(){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="image/png";putExtra(Intent.EXTRA_TITLE,"SecureStudio_${System.currentTimeMillis()}.png");addCategory(Intent.CATEGORY_OPENABLE)},SAVE_IMAGE)}

    private fun pickImage(request:Int){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("image/png","image/jpeg","image/webp","image/gif","image/bmp","image/heif","image/heic","image/avif"));addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},request)}

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return
        when(requestCode){
            PICK_IMAGE->{selectedImage=uri;toast("تصویر انتخاب شد")}
            PICK_CARRIER_STEGO->{selectedCarrier=uri;toast("تصویر حامل انتخاب شد")}
            PICK_FILE_STEGO->{selectedFile=uri;toast("فایل انتخاب شد")}
            PICK_FILE_FROM_IMAGE->{selectedImage=uri;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"extracted_${System.currentTimeMillis()}.ssf");addCategory(Intent.CATEGORY_OPENABLE)},SAVE_EXTRACTED_FILE)}
            SAVE_IMAGE->{val bm=pendingSaveBitmap;pendingSaveBitmap=null;if(bm!=null)runBg("در حال ذخیره PNG…",null){ImageCodec.savePng(bm,contentResolver,uri);main.post{toast("تصویر ذخیره شد")}}}
            PICK_FILE_ENC->{selectedFile=uri;runBg("در حال رمزنگاری فایل…",null){val out=File(cacheDir,"encrypted_${System.currentTimeMillis()}.ssf");FileCrypto.encrypt(contentResolver,uri,out);main.post{pendingFileForSave=out;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"SecureStudio_${System.currentTimeMillis()}.ssf");addCategory(Intent.CATEGORY_OPENABLE)},SAVE_FILE_DEC)}}}
            PICK_FILE_ENC+1->{val out=File(cacheDir,"decrypted_${System.currentTimeMillis()}");runBg("در حال رمزگشایی فایل…",null){FileCrypto.decrypt(contentResolver,materializeUri(uri),out);main.post{pendingFileForSave=out;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"decrypted_${System.currentTimeMillis()}");addCategory(Intent.CATEGORY_OPENABLE)},SAVE_FILE_DEC)}}}
            SAVE_FILE_DEC->{val src=pendingFileForSave;pendingFileForSave=null;if(src!=null)runBg("در حال ذخیره فایل…",null){copyFile(src,uri);src.delete();main.post{toast("فایل ذخیره شد")}}}
            SAVE_EXTRACTED_FILE->{val image=selectedImage;if(image!=null)runBg("در حال استخراج فایل…",null){val bm=ImageCodec.decode(contentResolver,image);val out=File(cacheDir,"extracted_${System.currentTimeMillis()}.ssf");try{FileStego.extract(bm,out);main.post{pendingFileForSave=out;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"extracted_${System.currentTimeMillis()}.ssf");addCategory(Intent.CATEGORY_OPENABLE)},SAVE_FILE_DEC)}}catch(e:Exception){out.delete();throw e}}}
        }
    }

    private var pendingFileForSave:File?=null
    private fun materializeUri(uri:Uri):File{val f=File(cacheDir,"source_${System.nanoTime()}");contentResolver.openInputStream(uri)?.use{input->FileOutputStream(f).use{out->input.copyTo(out,64*1024)}}?:error("فایل قابل خواندن نیست.");return f}
    private fun copyFile(src:File,dst:Uri){contentResolver.openOutputStream(dst)?.use{out->FileInputStream(src).use{it.copyTo(out,64*1024)}}?:error("فایل خروجی قابل نوشتن نیست.")}

    private fun runBg(message:String,anchor:ViewGroup?,work:()->Unit){anchor?.let{setBusy(it,true)};toast(message);executor.execute{try{work();main.post{anchor?.let{setBusy(it,false)}}}catch(e:Throwable){main.post{anchor?.let{setBusy(it,false)};toast(e.message?:"عملیات ناموفق بود")}}}}
    private fun setBusy(root:ViewGroup,busy:Boolean){for(i in 0 until root.childCount){val v=root.getChildAt(i);if(v is Button)v.isEnabled=!busy}}

    private fun screen()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18);setBackgroundColor(0xFF07100E.toInt())}
    private fun page(title:String):LinearLayout{val r=screen();r.addView(label(title,21f,true));return r}
    private fun label(text:String,size:Float,bold:Boolean):TextView=TextView(this).apply{this.text=text;textSize=size;setTextColor(0xFFEAF7F4.toInt());setTypeface(typeface,if(bold)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);setPadding(4,6,4,10)}
    private fun edit(hint:String,lines:Int)=EditText(this).apply{this.hint=hint;minLines=lines;gravity=Gravity.TOP;setTextColor(Color.WHITE);setHintTextColor(0xFF80908D.toInt());inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE;setPadding(14,12,14,12);background=box(0xFF101B19.toInt(),0xFF304642.toInt(),18f);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=10}}
    private fun button(root:ViewGroup,text:String,action:()->Unit){val b=Button(this).apply{this.text=text;setTextColor(Color.WHITE);textSize=14f;isAllCaps=false;background=box(0xFF172827.toInt(),0xFF38514D.toInt(),16f);setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,54).apply{bottomMargin=8}};root.addView(b)}
    private fun section(root:ViewGroup,text:String){root.addView(label(text,15f,true))}
    private fun back(root:ViewGroup){button(root,"‹ بازگشت"){showDashboard()}}
    private fun box(fill:Int,stroke:Int,radius:Float)=android.graphics.drawable.GradientDrawable().apply{cornerRadius=radius;setColor(fill);setStroke(1,stroke)}
    private fun roleName(r:Role)=when(r){Role.ADMIN->"مدیر";Role.A->"سطح A";Role.M->"سطح M";Role.S->"سطح S";Role.TEMPORARY->"موقت"}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    override fun onBackPressed(){if(role()!=null)showDashboard() else super.onBackPressed()}

    private object Calculator {
        fun eval(s:String):String { val p=Parser(s);val v=p.parse();if(!v.isFinite()||!p.end())throw IllegalArgumentException();return if(abs(v-round(v))<1e-10)round(v).toLong().toString() else "%.12g".format(java.util.Locale.US,v) }
        private class Parser(private val s:String){var i=0;fun end():Boolean{skip();return i==s.length};fun skip(){while(i<s.length&&s[i].isWhitespace())i++}
            fun parse():Double{val v=expr();skip();if(i<s.length)throw IllegalArgumentException();return v};fun expr():Double{var v=term();while(true){skip();if(i>=s.length)return v;when(s[i]){'+':{i++;v+=term()};'-':{i++;v-=term()};else->return v}}}
            fun term():Double{var v=unary();while(true){skip();if(i>=s.length)return v;when(s[i]){'*':{i++;v*=unary()};'/':{i++;val d=unary();if(d==0.0)throw ArithmeticException();v/=d};'%':{i++;val d=unary();if(d==0.0)throw ArithmeticException();v%=d};else->return v}}}
            fun unary():Double{skip();if(i<s.length&&s[i]=='-'){i++;return -unary()};if(i<s.length&&s[i]=='+'){i++;return unary()};return primary()}
            fun primary():Double{skip();if(i>=s.length)throw IllegalArgumentException();if(s[i]=='('){i++;val v=expr();skip();if(i>=s.length||s[i]!=')')throw IllegalArgumentException();i++;return v};if(s[i].isDigit()||s[i]=='.')return number();val start=i;while(i<s.length&&s[i].isLetter())i++;if(start==i){if(s[i]=='π'){i++;return PI};throw IllegalArgumentException()};val name=s.substring(start,i).lowercase();if(name=="pi")return PI;if(name=="e")return E;if(i<s.length&&s[i]=='('){i++;val x=expr();skip();if(i>=s.length||s[i]!=')')throw IllegalArgumentException();i++;return when(name){"sin"->sin(Math.toRadians(x));"cos"->cos(Math.toRadians(x));"tan"->tan(Math.toRadians(x));"cot"->{val t=tan(Math.toRadians(x));if(t==0.0)throw ArithmeticException();1.0/t};"sqrt"->sqrt(x);else->throw IllegalArgumentException()}};throw IllegalArgumentException()}
            fun number():Double{val st=i;while(i<s.length&&(s[i].isDigit()||s[i]=='.'))i++;return s.substring(st,i).toDouble()}
        }
    }
}
