package com.securestudio.v1

import android.os.Bundle
import android.util.Base64
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.nio.charset.StandardCharsets
import java.security.SecureRandom

class MainActivity : AppCompatActivity() {
    private var key: SecretKey? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        key = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(0xFF0B1412.toInt())
        }

        val title = TextView(this).apply {
            text = "🔐 Secure Studio"
            textSize = 28f
            setTextColor(0xFFEAF7F4.toInt())
            setPadding(0, 12, 0, 8)
        }
        val sub = TextView(this).apply {
            text = "نسخه ۱ • هسته امنیتی و ابزارهای چندرسانه‌ای"
            textSize = 14f
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 0, 0, 22)
        }

        root.addView(title)
        root.addView(sub)

        addButton(root, "🔐 رمزنگاری / رمزگشایی متن") { showCrypto() }
        addButton(root, "💻 تبدیل متن و Binary") { showBinary() }
        addButton(root, "🖼️ پیام مخفی در تصویر", "در نسخه بعدی فعال می‌شود")
        addButton(root, "📸 ویرایشگر تصویر", "در نسخه بعدی فعال می‌شود")
        addButton(root, "🎬 ویرایشگر ویدیو", "در نسخه بعدی فعال می‌شود")
        addButton(root, "🎵 ویرایشگر صوت", "در نسخه بعدی فعال می‌شود")
        addButton(root, "🌐 مترجم چندزبانه", "در نسخه بعدی فعال می‌شود")
        addButton(root, "🛡️ امنیت و کلیدها", "در نسخه بعدی فعال می‌شود")

        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, text: String, disabledNote: String? = null, action: (() -> Unit)? = null) {
        val b = Button(this).apply {
            this.text = if (disabledNote == null) text else "$text\n$disabledNote"
            isAllCaps = false
            setPadding(18, 18, 18, 18)
            if (action != null) setOnClickListener { action() } else isEnabled = false
        }
        parent.addView(b, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 10
        })
    }

    private fun showCrypto() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val input = EditText(this).apply {
            hint = "متن را وارد کنید"
            minLines = 5
            gravity = 48
        }
        val output = EditText(this).apply {
            hint = "خروجی"
            minLines = 7
            gravity = 48
        }
        val enc = Button(this).apply {
            text = "🔐 رمزنگاری"
            setOnClickListener {
                output.setText(encrypt(input.text.toString()))
            }
        }
        val dec = Button(this).apply {
            text = "🔓 رمزگشایی"
            setOnClickListener {
                try {
                    output.setText(decrypt(input.text.toString()))
                } catch (_: Exception) {
                    output.setText("رمزگشایی ناموفق بود؛ کلید یا متن معتبر نیست.")
                }
            }
        }
        val back = Button(this).apply {
            text = "← بازگشت"
            setOnClickListener { showHome() }
        }
        box.addView(input)
        box.addView(enc)
        box.addView(dec)
        box.addView(output)
        box.addView(back)
        setContentView(box)
    }

    private fun encrypt(text: String): String {
        val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        val encrypted = cipher.doFinal(text.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(nonce + encrypted, Base64.NO_WRAP)
    }

    private fun decrypt(encoded: String): String {
        val all = Base64.decode(encoded, Base64.NO_WRAP)
        require(all.size > 12)
        val nonce = all.copyOfRange(0, 12)
        val data = all.copyOfRange(12, all.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonce))
        return String(cipher.doFinal(data), StandardCharsets.UTF_8)
    }

    private fun showBinary() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val input = EditText(this).apply { hint = "متن یا Binary"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        val toBin = Button(this).apply {
            text = "متن → Binary"
            setOnClickListener {
                output.setText(input.text.toString().toByteArray(StandardCharsets.UTF_8)
                    .joinToString(" ") { byte -> String.format("%8s", Integer.toBinaryString(byte.toInt() and 0xFF)).replace(' ', '0') })
            }
        }
        val fromBin = Button(this).apply {
            text = "Binary → متن"
            setOnClickListener {
                try {
                    val bytes = input.text.toString().trim().split(Regex("\\s+")).map { it.toInt(2).toByte() }.toByteArray()
                    output.setText(String(bytes, StandardCharsets.UTF_8))
                } catch (_: Exception) {
                    output.setText("Binary معتبر نیست.")
                }
            }
        }
        val back = Button(this).apply { text = "← بازگشت"; setOnClickListener { showHome() } }
        box.addView(input); box.addView(toBin); box.addView(fromBin); box.addView(output); box.addView(back)
        setContentView(box)
    }
}
