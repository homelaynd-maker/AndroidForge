package com.securestudio.v1

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.media.MediaPlayer
import android.widget.VideoView
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("secure_studio", MODE_PRIVATE) }
    private val rooms = mutableListOf<String>()
    private var currentRoom = "عمومی"
    private val chatCache = mutableMapOf<String, MutableList<String>>()
    private val ADMIN_TRIGGER = "Sin+-%/*1151=68"
    private val ADMIN_TRIGGER_HASH = "BI9bLrfBLKhdm8A2Ot/p1+bKumBencZNZpou1SzhSc4="
    private val ACCESS_CODE_A = "Tan+*-%=57"
    private val ACCESS_CODE_M = "Cot/*+%-=22"
    private val ACCESS_CODE_S = "Cos-*%/+=01"
    private val DEFAULT_GATE_ENABLED = false
    private var pendingImage: Bitmap? = null
    private var pendingMessage: String = ""
    private val PICK_IMAGE = 1001
    private val PICK_LOGO = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rooms.addAll(prefs.getStringSet("rooms", setOf("عمومی"))!!.toList().sorted())
        if (rooms.isEmpty()) rooms.add("عمومی")
        currentRoom = rooms.first()
        // نسخه تستی بدون ورودی و رمز: برنامه مستقیماً با دسترسی کامل باز می‌شود.
        // هیچ کد، PIN یا صفحه احراز هویتی در شروع برنامه نمایش داده نمی‌شود.
        prefs.edit()
            .putBoolean("program_unlocked", true)
            .putBoolean("admin_session", true)
            .putString("license_prefix", "a")
            .remove("temporary_session")
            .apply()
        showEngineeringCalculator()
    }

    private fun showFirstRunSetup() {
        val box = page("🔐 راه‌اندازی اولیه برنامه")
        box.addView(TextView(this).apply {
            text = "در اولین اجرا، خودتان رمز مدیر را تعیین کنید. این برنامه هیچ رمز پیش‌فرضی ندارد و رمز مدیر در صفحه ورود نمایش داده نمی‌شود. رمز را در جای امن نگه دارید؛ پنل مدیریت فقط برای تنظیمات و مدیریت خود برنامه استفاده می‌شود و سیستم صدور کد کاربر در این نسخه وجود ندارد."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val input = EditText(this).apply {
            hint = "رمز مدیر: ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val question = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(
                "نام اولین مدرسه شما چه بود؟",
                "نام اولین شهر محل زندگی شما چه بود؟",
                "نام یک دوست دوران کودکی شما چه بود؟",
                "غذای مورد علاقه شما چیست؟"
            ))
        }
        val answer = EditText(this).apply { hint = "پاسخ سؤال امنیتی را وارد کنید" }
        btn(box, "💾 ثبت رمز مدیر و سؤال امنیتی") {
            val p = input.text.toString()
            val a = answer.text.toString().trim()
            if (!validAdminPassword(p)) {
                toast("رمز مدیر باید ۸ تا ۲۲ کاراکتر و دارای حداقل ۲ نماد باشد.")
            } else if (a.length < 2) {
                toast("پاسخ سؤال امنیتی را وارد کنید.")
            } else {
                prefs.edit().putString("admin_password", hash(p))
                    .putInt("security_question", question.selectedItemPosition)
                    .putString("security_answer", hash(a))
                    .putBoolean("program_unlocked", true).putBoolean("admin_session", true).remove("license_prefix").apply()
                showAdminPanel()
            }
        }
        box.addView(input, 1)
        box.addView(TextView(this).apply { text = "سؤال امنیتی بازیابی رمز"; setTextColor(0xFFEAF7F4.toInt()); setPadding(0,12,0,6) })
        box.addView(question)
        box.addView(answer)
        setContentView(box)
    }

    private fun showProgramAccessGate() { showEngineeringCalculator() }

    private fun showEngineeringCalculator() {
        val box = page("🧮 ماشین حساب مهندسی")
        box.addView(TextView(this).apply {
            text = "ماشین حساب مهندسی است. برای ورود به امکانات برنامه، کدهای تعریف‌شده را دقیقاً با همین کلیدها وارد و با = تأیید کنید. حروف بزرگ/کوچک و ترتیب نمادها مهم است."
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 0, 0, 12)
        })
        val display = EditText(this).apply {
            hint = "عدد یا عبارت ریاضی"
            textSize = 22f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            gravity = Gravity.END
        }
        box.addView(display)

        val history = TextView(this).apply {
            text = "تاریخچه: —"
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 6, 0, 12)
        }
        box.addView(history)

        fun key(label: String, value: String = label) { btn(box, label) { display.append(value) } }
        key("Sin", "Sin"); key("Cos", "Cos"); key("Tan", "Tan"); key("Cot", "Cot")
        key("7"); key("8"); key("9"); key("÷", "/")
        key("4"); key("5"); key("6"); key("×", "*")
        key("1"); key("2"); key("3"); key("−", "-")
        key("0"); key("."); key("%"); key("+", "+")
        key("("); key(")")

        btn(box, "π  عدد پی") { display.setText("${Math.PI}") }
        btn(box, "e  عدد نپر") { display.setText("${Math.E}") }
        btn(box, "√  جذر") { applyUnary(display, history, "√") { Math.sqrt(it) } }
        btn(box, "x²  مربع") { applyUnary(display, history, "x²") { it * it } }
        btn(box, "1/x  معکوس") { applyUnary(display, history, "1/x") { if (it == 0.0) throw ArithmeticException() else 1.0 / it } }
        btn(box, "sin  سینوس") { applyUnary(display, history, "sin") { Math.sin(Math.toRadians(it)) } }
        btn(box, "cos  کسینوس") { applyUnary(display, history, "cos") { Math.cos(Math.toRadians(it)) } }
        btn(box, "tan  تانژانت") { applyUnary(display, history, "tan") { Math.tan(Math.toRadians(it)) } }
        btn(box, "cot  کتانژانت") { applyUnary(display, history, "cot") { val t = Math.tan(Math.toRadians(it)); if (kotlin.math.abs(t) < 1e-12) throw ArithmeticException() else 1.0 / t } }
        btn(box, "log  لگاریتم دهدهی") { applyUnary(display, history, "log") { if (it <= 0) throw ArithmeticException() else Math.log10(it) } }
        btn(box, "ln  لگاریتم طبیعی") { applyUnary(display, history, "ln") { if (it <= 0) throw ArithmeticException() else Math.log(it) } }

        btn(box, "⌫ حذف یک رقم") {
            if (display.text.isNotEmpty()) display.text.delete(display.text.length - 1, display.text.length)
        }
        btn(box, "🧹 پاک کردن همه") { display.setText(""); history.text = "تاریخچه: —" }
        btn(box, "=  محاسبه / ورود") {
            val expr = display.text.toString().trim()
            when {
                expr == ADMIN_TRIGGER || hash(expr) == ADMIN_TRIGGER_HASH -> {
                    prefs.edit().putBoolean("program_unlocked", true).putBoolean("admin_session", true)
                        .remove("license_prefix").remove("temporary_session").apply()
                    history.text = "کد مدیر شناسایی شد"
                    showAdminLogin()
                }
                expr == ACCESS_CODE_A -> {
                    history.text = "کد سطح a شناسایی شد"
                    openUserAfterCode("a", false)
                }
                expr == ACCESS_CODE_M -> {
                    history.text = "کد سطح m شناسایی شد"
                    openUserAfterCode("m", false)
                }
                expr == ACCESS_CODE_S -> {
                    history.text = "کد سطح s شناسایی شد"
                    openUserAfterCode("s", false)
                }
                else -> {
                    val result = evaluateEngineeringCalculator(expr)
                    if (result != null) {
                        history.text = "تاریخچه: $expr = $result"
                        display.setText(result)
                    } else toast("عبارت ریاضی یا کد ورود نامعتبر است.")
                }
            }
        }

        box.addView(TextView(this).apply {
            text = "کدهای ورود:
مدیر: Sin+-%/*1151=68
سطح a: Tan+*-%=57
سطح m: Cot/*+%-=22
سطح s: Cos-*%/+=01"
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 10, 0, 12)
        })
        setContentView(box)
    }

    private fun applyUnary(display: EditText, history: TextView, label: String, operation: (Double) -> Double) {
        val value = display.text.toString().trim().toDoubleOrNull()
        if (value == null) { toast("ابتدا یک عدد وارد کنید."); return }
        try {
            val result = operation(value)
            if (!result.isFinite()) throw ArithmeticException()
            val shown = result.toString()
            history.text = "تاریخچه: $label($value) = $shown"
            display.setText(shown)
        } catch (_: Exception) { toast("محاسبه برای این عدد امکان‌پذیر نیست.") }
    }

    private fun evaluateEngineeringCalculator(expr: String): String? {
        if (expr.isBlank()) return null
        if (expr.any { !(it.isDigit() || it in "+-*/%.() ") }) return null
        return try {
            val normalized = expr.replace("%", "/100")
            val tokens = Regex("(?<=[+\\-*/()])|(?=[+\\-*/()])")
                .split(normalized).map { it.trim() }.filter { it.isNotEmpty() }
            val vals = java.util.ArrayDeque<Double>()
            val ops = java.util.ArrayDeque<Char>()
            fun prec(c: Char) = if (c == '+' || c == '-') 1 else 2
            fun apply() {
                if (vals.size < 2 || ops.isEmpty()) throw ArithmeticException()
                val b = vals.removeLast(); val a = vals.removeLast()
                when (ops.removeLast()) {
                    '+' -> vals.addLast(a + b)
                    '-' -> vals.addLast(a - b)
                    '*' -> vals.addLast(a * b)
                    '/' -> { if (b == 0.0) throw ArithmeticException(); vals.addLast(a / b) }
                    else -> throw ArithmeticException()
                }
            }
            for (t in tokens) {
                when {
                    t.matches(Regex("[0-9]+(?:\\.[0-9]+)?")) -> vals.addLast(t.toDouble())
                    t == "(" -> ops.addLast('(')
                    t == ")" -> {
                        while (ops.isNotEmpty() && ops.peekLast() != '(') apply()
                        if (ops.isEmpty()) throw ArithmeticException()
                        ops.removeLast()
                    }
                    t.length == 1 && t[0] in "+-*/" -> {
                        while (ops.isNotEmpty() && ops.peekLast() != '(' && prec(ops.peekLast()) >= prec(t[0])) apply()
                        ops.addLast(t[0])
                    }
                    else -> throw ArithmeticException()
                }
            }
            while (ops.isNotEmpty()) { if (ops.peekLast() == '(') throw ArithmeticException(); apply() }
            if (vals.size != 1) throw ArithmeticException()
            val result = vals.peekLast()
            if (!result.isFinite()) throw ArithmeticException()
            result.toString()
        } catch (_: Exception) { null }
    }

    private fun openUserAfterCode(prefix:String,temporary:Boolean){
        prefs.edit().putBoolean("program_unlocked",true).putBoolean("admin_session",false).putString("license_prefix",prefix).putBoolean("temporary_session",temporary).apply();showUserPasswordLogin(prefix,temporary)
    }

    private fun showUserPasswordLogin(prefix:String,temporary:Boolean){
        val key="user_password_$prefix"; val existing=prefs.getString(key,null)
        if(existing==null){
            val box=page("🔐 تنظیم رمز شخصی");box.addView(TextView(this).apply{text="رمز شخصی ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد باشد. این رمز سطح دسترسی را تغییر نمی‌دهد.";setTextColor(0xFF9FCBC1.toInt())})
            val p1=EditText(this).apply{hint="رمز جدید";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val p2=EditText(this).apply{hint="تکرار رمز";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            btn(box,"💾 ثبت"){val a=p1.text.toString();if(!validAdminPassword(a))toast("رمز باید ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد داشته باشد.")else if(a!=p2.text.toString())toast("دو رمز یکسان نیستند.")else{prefs.edit().putString(key,hash(a)).apply();showHome()}};box.addView(p1);box.addView(p2);setContentView(box);return
        }
        val input=EditText(this).apply{hint="رمز شخصی";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};AlertDialog.Builder(this).setTitle("🔐 ورود کاربر $prefix").setView(input).setNegativeButton("انصراف",null).setPositiveButton("ورود"){_,_->if(hash(input.text.toString())==existing)showHome()else toast("رمز شخصی نادرست است.")}.show()
    }

    private fun page(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(0xFF0B1412.toInt())
        layoutParams = ViewGroup.LayoutParams(-1, -1)
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 25f; setTextColor(0xFFEAF7F4.toInt()); setPadding(0, 8, 0, 18)
        })
    }

    private fun btn(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            isEnabled = true
            alpha = 1.0f
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun back(parent: LinearLayout) = btn(parent, "← بازگشت") { showHome() }

    private fun showHome() {
        val root = page("")
        val branding = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 10)
        }
        val logo = ImageView(this).apply {
            val uri = prefs.getString("app_logo_uri", null)
            if (!uri.isNullOrBlank()) {
                try { setImageURI(Uri.parse(uri)) } catch (_: Exception) { setImageResource(android.R.drawable.ic_lock_lock) }
            } else setImageResource(android.R.drawable.ic_lock_lock)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        branding.addView(logo, LinearLayout.LayoutParams(64,64).apply { marginEnd = 12 })
        branding.addView(TextView(this).apply {
            text = prefs.getString("app_display_name", "Secure Studio")
            textSize = 28f; setTextColor(0xFFEAF7F4.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(branding, 1)
        root.addView(TextView(this).apply {
            text = if (prefs.getBoolean("admin_session", false)) "سطح دسترسی: مدیر (کامل)" else "سطح دسترسی: ${prefs.getString("license_prefix", "")}"
            textSize = 14f; setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,18)
        }, 2)

        val prefix = if (prefs.getBoolean("admin_session", false)) "a" else (prefs.getString("license_prefix", "") ?: "")
        fun allowed(area:String) = when(prefix) {
            "s" -> area == "crypto" || area == "binary"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary"
            "a" -> true
            else -> false
        }
        if (allowed("crypto")) btn(root, "🔐 رمزنگاری / رمزگشایی متن") { showCrypto() }
        if (allowed("chat")) btn(root, "💬 اتاق‌های پیام خصوصی") { showChat() }
        if (allowed("image")) btn(root, "🖼️ پیام رمزگذاری‌شده داخل تصویر") { showStego() }
        if (allowed("binary")) btn(root, "💻 متن ↔ Binary") { showBinary() }
        btn(root, "🛡️ قفل برنامه و امنیت") { showSecurity() }
        if (prefix == "a") {
            btn(root, "📸 ویرایشگر تصویر") { showImageEditor() }
            btn(root, "🎬 ویرایشگر ویدیو") { showVideoEditor() }
            btn(root, "🎵 ویرایشگر صوت") { showAudioEditor() }
            btn(root, "🌐 مترجم آفلاین") { showTranslator() }
            btn(root, "🎙️ ابزار صوت و گفتار") { showVoiceTools() }
        }
        if (!prefs.getBoolean("admin_session", false)) btn(root, "🔑 تغییر رمز شخصی") { changeUserPassword() }
        btn(root, "🚪 بازگشت به صفحه اصلی") { showHome() }
        setContentView(root)
    }

    private fun requireSecure(area: String, onSuccess: () -> Unit) {
        val prefix = if (prefs.getBoolean("admin_session", false)) "a" else (prefs.getString("license_prefix", "") ?: "")
        val allowed = when (prefix) {
            "s" -> area == "crypto" || area == "binary"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary"
            "a" -> true
            else -> false
        }
        if (allowed) { onSuccess(); return }
        showProgramAccessGate()
    }

    private fun areaTitle(area: String) = when(area) {
        "crypto" -> "رمزنگاری پیام"
        "chat" -> "پیام‌های خصوصی"
        "image" -> "پیام مخفی در تصویر"
        "binary" -> "رمزنگاری و Binary"
        else -> "بخش محافظت‌شده"
    }

    private fun showCrypto() {
        val box = page("🔐 رمزنگاری متن")
        val input = EditText(this).apply { hint = "متن یا متن رمزگذاری‌شده"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"🔐 رمزنگاری") {
            val value = input.text.toString()
            if (value.isBlank()) {
                toast("متن را وارد کنید.")
            } else {
                try {
                    output.setText(encrypt(value))
                    toast("رمزنگاری با موفقیت انجام شد.")
                } catch (e: Exception) {
                    output.setText("")
                    toast("خطا در رمزنگاری: ${e.message ?: "خطای نامشخص"}")
                }
            }
        }
        btn(box,"🔓 رمزگشایی") {
            // اگر کاربر بلافاصله بعد از رمزنگاری روی رمزگشایی بزند، ciphertext داخل خروجی است.
            // بنابراین ابتدا ورودی و در صورت خالی بودن آن، خروجی را امتحان می‌کنیم.
            val candidate = input.text.toString().trim().ifBlank { output.text.toString().trim() }
            if (candidate.isBlank()) {
                toast("متن رمزنگاری‌شده را وارد کنید یا ابتدا رمزنگاری کنید.")
            } else {
                try {
                    val plain = decrypt(candidate)
                    output.setText(plain)
                    toast("رمزگشایی با موفقیت انجام شد.")
                } catch (e: Exception) {
                    toast("رمزگشایی ناموفق؛ متن رمزنگاری‌شده معتبر نیست یا با این دستگاه تولید نشده است.")
                }
            }
        }
        btn(box,"↔️ انتقال خروجی به ورودی") {
            val value = output.text.toString()
            if (value.isBlank()) toast("خروجی خالی است.") else { input.setText(value); toast("خروجی به ورودی منتقل شد.") }
        }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input, 1); box.addView(output, 6); back(box); setContentView(box)
    }

    private fun showBinary() {
        val box = page("💻 متن و Binary")
        val input = EditText(this).apply { hint = "متن یا Binary با فاصله"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"متن → Binary") { output.setText(input.text.toString().toByteArray(StandardCharsets.UTF_8).joinToString(" ") { String.format("%8s", Integer.toBinaryString(it.toInt() and 255)).replace(' ','0') }) }
        btn(box,"Binary → متن") { try { output.setText(String(input.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.toInt(2).toByte() }.toByteArray(), StandardCharsets.UTF_8)) } catch (_: Exception) { output.setText("Binary معتبر نیست.") } }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input,1); box.addView(output,6); back(box); setContentView(box)
    }

    private fun showChat() {
        val box = page("💬 اتاق‌های پیام خصوصی")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rooms)
        spinner.setSelection(rooms.indexOf(currentRoom).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { currentRoom = rooms[pos]; refreshChat() }
        }
        box.addView(TextView(this).apply { text="اتاق فعلی"; setTextColor(0xFFEAF7F4.toInt()) })
        box.addView(spinner)
        val messages = TextView(this).apply { minHeight=260; setTextColor(0xFFEAF7F4.toInt()); setPadding(8,16,8,16) }
        val input = EditText(this).apply { hint="پیام" }
        val send = Button(this).apply { text="ارسال رمزگذاری‌شده"; isAllCaps=false }
        send.setOnClickListener {
            val msg=input.text.toString(); if(msg.isNotBlank()) { val list=chatCache.getOrPut(currentRoom){mutableListOf()}; list.add("شما: "+encrypt(msg)); input.text.clear(); refreshChat(messages) }
        }
        btn(box,"➕ ساخت اتاق جدید") { createRoomAndRefresh() }
        box.addView(messages); box.addView(input); box.addView(send); back(box)
        refreshChat(messages); setContentView(box)
    }

    private fun refreshChat(target: TextView? = null) {
        val t = target ?: return
        val list=chatCache.getOrPut(currentRoom){mutableListOf()}
        t.text = if(list.isEmpty()) "این اتاق هنوز پیامی ندارد." else list.joinToString("\n\n")
    }

    private fun createRoomAndRefresh() {
        val input=EditText(this).apply { hint="نام اتاق" }
        AlertDialogBuilder("ساخت اتاق", input) { val n=input.text.toString().trim(); if(n.isNotEmpty()&&!rooms.contains(n)){rooms.add(n);prefs.edit().putStringSet("rooms",rooms.toSet()).apply();currentRoom=n;showChat()} }.show()
    }

    private fun showStego() {
        val box=page("🖼️ پیام رمزگذاری‌شده داخل تصویر")
        val message=EditText(this).apply{hint="پیامی که باید داخل تصویر قرار بگیرد";minLines=4;gravity=48}
        val info=TextView(this).apply{text="برای حفظ کیفیت، خروجی به PNG ذخیره می‌شود. تصویر اصلی تغییر محتوایی قابل مشاهده ندارد.";setTextColor(0xFF9FCBC1.toInt())}
        btn(box,"📂 انتخاب تصویر و جاسازی پیام"){pendingMessage=message.text.toString(); if(pendingMessage.isBlank()){toast("ابتدا پیام را وارد کنید.")}else{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE)}}
        btn(box,"📂 انتخاب تصویر و استخراج پیام"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/png";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE+1)}
        box.addView(message,1);box.addView(info,2);back(box);setContentView(box)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!
        if(requestCode==PICK_LOGO){
            try{
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }catch(_:Exception){}
            prefs.edit().putString("app_logo_uri",uri.toString()).apply()
            toast("لوگوی برنامه ذخیره شد.")
            showHome()
        } else if(requestCode==PICK_MEDIA_IMAGE){
            val bmp=loadBitmap(uri); if(bmp==null){toast("تصویر قابل خواندن نیست.");return}; selectedImageBitmap=bmp; showImageEditor()
        } else if(requestCode==PICK_MEDIA_VIDEO){
            // VideoView is created by the screen; reopen screen and store URI for future expansion.
            selectedMediaUri=uri; showVideoEditor(); toast("ویدیو انتخاب شد؛ برای پخش مستقیم دوباره انتخاب لازم است.")
        } else if(requestCode==PICK_AUDIO_ENCRYPT){
            encryptAudio(uri); showAudioEditor()
        } else if(requestCode==PICK_AUDIO_DECRYPT){
            decryptAudio(uri); showAudioEditor()
        } else if(requestCode==PICK_MEDIA_AUDIO){
            try{audioPlayer?.release();audioPlayer=MediaPlayer.create(this,uri);showAudioEditor();toast("فایل صوتی آماده پخش است.")}catch(_:Exception){toast("فایل صوتی قابل پخش نیست.")}
        } else if(requestCode==PICK_IMAGE){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{saveBitmap(embedMessage(bmp,pendingMessage))}catch(e:Exception){toast("خطا: ظرفیت تصویر کافی نیست یا فرمت مناسب نیست.")}}
        else if(requestCode==PICK_IMAGE+1){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{showExtracted(decrypt(extractMessage(bmp)))}catch(e:Exception){toast("پیام رمزگذاری‌شده معتبری در تصویر پیدا نشد.")}}
    }

    private fun embedMessage(src: Bitmap, text: String): Bitmap {
        val data = encrypt(text).toByteArray(StandardCharsets.UTF_8)
        val payload = ByteBuffer.allocate(4 + data.size).putInt(data.size).put(data).array()
        val capacity = src.width * src.height * 3
        require(payload.size * 8 <= capacity)

        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        var bit = 0
        for (y in 0 until out.height) {
            for (x in 0 until out.width) {
                val pixel = out.getPixel(x, y)
                val channels = intArrayOf(
                    (pixel shr 16).and(255),
                    (pixel shr 8).and(255),
                    pixel.and(255)
                )
                for (channel in 0..2) {
                    if (bit < payload.size * 8) {
                        val byteValue = payload[bit / 8].toInt().and(255)
                        val bitValue = (byteValue shr (7 - (bit % 8))).and(1)
                        channels[channel] = channels[channel].and(254).or(bitValue)
                        bit++
                    }
                }
                out.setPixel(x, y, (0xFF000000.toInt() or (channels[0] shl 16) or (channels[1] shl 8) or channels[2]))
                if (bit >= payload.size * 8) return out
            }
        }
        return out
    }

    private fun extractMessage(bmp: Bitmap): String {
        val bits = ArrayList<Int>()
        for (y in 0 until bmp.height) {
            for (x in 0 until bmp.width) {
                val pixel = bmp.getPixel(x, y)
                bits.add((pixel shr 16).and(1))
                bits.add((pixel shr 8).and(1))
                bits.add(pixel.and(1))
            }
        }

        fun readInt(start: Int): Int {
            var value = 0
            for (i in 0 until 32) {
                value = value.shl(1).or(bits[start + i])
            }
            return value
        }

        require(bits.size >= 32)
        val length = readInt(0)
        require(length > 0 && length < 10_000_000 && 32 + length * 8 <= bits.size)

        val out = ByteArray(length)
        for (i in 0 until length) {
            var value = 0
            for (j in 0 until 8) {
                value = value.shl(1).or(bits[32 + i * 8 + j])
            }
            out[i] = value.toByte()
        }
        return String(out, StandardCharsets.UTF_8)
    }
    private fun saveBitmap(bmp:Bitmap){val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"SecureStudio_${System.currentTimeMillis()}.png");put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/SecureStudio")};val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:throw Exception();contentResolver.openOutputStream(uri)!!.use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)};toast("تصویر در Pictures/SecureStudio ذخیره شد.")}
    private fun loadBitmap(uri:Uri):Bitmap?=contentResolver.openInputStream(uri).use{BitmapFactory.decodeStream(it)}

    private fun changeUserPassword(){val prefix=prefs.getString("license_prefix",null)?:return;val box=page("🔑 تغییر رمز شخصی");val p1=EditText(this).apply{hint="رمز جدید";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val p2=EditText(this).apply{hint="تکرار رمز";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};btn(box,"💾 ذخیره"){val a=p1.text.toString();if(!validAdminPassword(a))toast("رمز باید ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد داشته باشد.")else if(a!=p2.text.toString())toast("دو رمز یکسان نیستند.")else{prefs.edit().putString("user_password_$prefix",hash(a)).putBoolean("admin_session",false).putString("license_prefix",prefix).apply();toast("رمز تغییر کرد؛ سطح دسترسی $prefix حفظ شد.");showHome()}};box.addView(p1);box.addView(p2);back(box);setContentView(box)}

    private fun showSecurity(){
        val box=page("🛡️ امنیت برنامه")
        val status=TextView(this).apply{setTextColor(0xFFEAF7F4.toInt())}
        status.text=if(prefs.contains("pin"))"قفل PIN فعال است." else "قفل PIN هنوز تنظیم نشده است."
        btn(box,"🔑 تنظیم / تغییر PIN"){setPin()}
        btn(box,"🗑️ حذف PIN"){prefs.edit().remove("pin").apply();status.text="قفل PIN غیرفعال شد."}
        btn(box,"🔒 آزمایش قفل"){if(prefs.contains("pin"))verifyPin()else toast("ابتدا PIN تنظیم کنید.")}
        btn(box,"👑 ورود به پنل مدیریت"){showAdminLogin()}
        box.addView(status,1); back(box); setContentView(box)
    }

    private fun showAdminLogin(){
        if(!prefs.contains("admin_password")){
            val first=EditText(this).apply{hint="رمز مدیر، حداقل 8 و حداکثر 22 کاراکتر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            AlertDialogBuilder("👑 ایجاد رمز اولیه مدیر",first){val p=first.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).putBoolean("admin_session", true).putBoolean("program_unlocked", true).apply();toast("رمز مدیر ثبت شد. آن را در جای امن نگه دارید.");showAdminPanel()}else toast("رمز باید 8 تا 22 کاراکتر و دارای حداقل 2 نماد باشد.")}.show()
            return
        }
        val input=EditText(this).apply{hint="رمز ورود پنل مدیر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        android.app.AlertDialog.Builder(this).setTitle("🔐 ورود مدیر").setView(input)
            .setNegativeButton("فراموشی رمز"){_,_->showAdminRecovery()}
            .setPositiveButton("ورود"){_,_->if(hash(input.text.toString())==prefs.getString("admin_password",null)){prefs.edit().putBoolean("admin_session",true).putBoolean("program_unlocked",true).remove("license_prefix").apply();showAdminPanel()}else toast("رمز مدیر نادرست است.")}
            .show()
    }

    private fun showAdminRecovery(){
        val qIndex = prefs.getInt("security_question", 0)
        val questions = listOf(
            "نام اولین مدرسه شما چه بود؟",
            "نام اولین شهر محل زندگی شما چه بود؟",
            "نام یک دوست دوران کودکی شما چه بود؟",
            "غذای مورد علاقه شما چیست?"
        )
        val box=page("🛡️ بازیابی رمز مدیر")
        box.addView(TextView(this).apply{
            text = "سؤال امنیتی ثبت‌شده:\n${questions.getOrElse(qIndex){questions[0]}}"
            setTextColor(0xFFEAF7F4.toInt()); setPadding(0,0,0,16)
        })
        val answer=EditText(this).apply{hint="پاسخ سؤال امنیتی"}
        val newPass=EditText(this).apply{hint="رمز جدید مدیر: ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        // تنظیم نوع ورودی جداگانه برای جلوگیری از نمایش رمز در صفحه
        newPass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        btn(box,"🔓 بازیابی و تعیین رمز جدید"){
            val a=answer.text.toString().trim(); val p=newPass.text.toString()
            if(hash(a)==prefs.getString("security_answer",null) && validAdminPassword(p)){
                prefs.edit().putString("admin_password",hash(p)).apply()
                toast("رمز مدیر با موفقیت تغییر کرد."); showAdminLogin()
            } else if(hash(a)!=prefs.getString("security_answer",null)) toast("پاسخ سؤال امنیتی نادرست است.")
            else toast("رمز جدید باید ۸ تا ۲۲ کاراکتر و دارای حداقل ۲ نماد باشد.")
        }
        box.addView(answer); box.addView(newPass); back(box); setContentView(box)
    }

    private fun showAdminPanel(){
        if(!prefs.getBoolean("admin_session",false)){toast("دسترسی مدیر فقط برای جلسه مدیر مجاز است.");showEngineeringCalculator();return}
        val box=page("👑 پنل مدیریت ویژه")
        box.addView(TextView(this).apply{text="این بخش برای مدیریت تنظیمات خود برنامه است. سیستم صدور و مدیریت کدهای کاربران در این نسخه حذف شده است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)})
        btn(box,"🎨 تغییر نام و لوگوی برنامه"){showBrandingSettings()}
        btn(box,"🔄 تغییر رمز مدیر"){changeAdminPassword()}
        btn(box,"🛡️ تغییر سؤال امنیتی"){changeSecurityQuestion()}
        btn(box,"🔓 خروج از برنامه و بازگشت به صفحه ورود"){prefs.edit().putBoolean("program_unlocked",false).remove("license_prefix").remove("temporary_session").remove("admin_session").apply();showProgramAccessGate()}
        back(box); setContentView(box)
    }

    private fun showBrandingSettings(){
        val box=page("🎨 نام و لوگوی برنامه")
        box.addView(TextView(this).apply{
            text="از این بخش مدیر می‌تواند نام نمایشی برنامه و لوگوی داخل برنامه را تغییر دهد. تغییرات روی صفحه اصلی برنامه ذخیره می‌شود."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val name=EditText(this).apply{
            hint="نام جدید برنامه"
            setText(prefs.getString("app_display_name","Secure Studio"))
        }
        btn(box,"💾 ذخیره نام برنامه"){
            val n=name.text.toString().trim()
            if(n.length in 2..40){prefs.edit().putString("app_display_name",n).apply();toast("نام برنامه تغییر کرد.");showHome()}
            else toast("نام برنامه باید بین ۲ تا ۴۰ کاراکتر باشد.")
        }
        btn(box,"🖼️ انتخاب لوگو از گالری"){
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            },PICK_LOGO)
        }
        btn(box,"↩️ بازگردانی نام و لوگوی پیش‌فرض"){
            prefs.edit().remove("app_display_name").remove("app_logo_uri").apply();toast("نام و لوگوی پیش‌فرض بازگردانده شد.");showHome()
        }
        back(box);setContentView(box)
    }


    private val PICK_MEDIA_IMAGE = 3001
    private val PICK_MEDIA_VIDEO = 3002
    private val PICK_MEDIA_AUDIO = 3003
    private val PICK_AUDIO_ENCRYPT = 3004
    private val PICK_AUDIO_DECRYPT = 3005
    private var selectedMediaUri: Uri? = null
    private var selectedImageBitmap: Bitmap? = null
    private var audioPlayer: MediaPlayer? = null

    private fun showImageEditor(){
        val box=page("📸 ویرایشگر تصویر آفلاین")
        val preview=ImageView(this).apply{minimumHeight=260;scaleType=ImageView.ScaleType.CENTER_INSIDE;setBackgroundColor(0xFF17231F.toInt())}
        val info=TextView(this).apply{text="یک تصویر انتخاب کنید؛ عملیات اصلی کاملاً روی گوشی انجام می‌شود.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        var bitmap:Bitmap?=selectedImageBitmap
        btn(box,"📂 انتخاب تصویر"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_IMAGE)}
        btn(box,"↻ چرخش ۹۰ درجه"){bitmap?.let{val m=Matrix();m.postRotate(90f);bitmap=Bitmap.createBitmap(it,0,0,it.width,it.height,m,true);preview.setImageBitmap(bitmap)}?:toast("ابتدا تصویر را انتخاب کنید.")}
        btn(box,"⚫ سیاه‌وسفید"){bitmap?.let{val b=it.copy(Bitmap.Config.ARGB_8888,true);b.setHasAlpha(false);val c=ColorMatrix();c.setSaturation(0f);preview.colorFilter=ColorMatrixColorFilter(c);bitmap=b}?:toast("ابتدا تصویر را انتخاب کنید.")}
        btn(box,"💾 ذخیره تصویر"){bitmap?.let{saveBitmap(it);preview.clearColorFilter()}?:toast("ابتدا تصویر را انتخاب کنید.")}
        box.addView(info,1);box.addView(preview,2);back(box);setContentView(box)
        bitmap?.let { preview.setImageBitmap(it) }
    }

    private fun showVideoEditor(){
        val box=page("🎬 ابزار ویدیو آفلاین")
        val vv=VideoView(this).apply{setBackgroundColor(0xFF17231F.toInt())}
        val info=TextView(this).apply{text="انتخاب، پخش، توقف و مرور ویدیو روی خود دستگاه انجام می‌شود. برای ویرایش‌های سنگین مثل برش/افکت، موتور رسانه‌ای جداگانه در نسخه توسعه‌یافته لازم است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        btn(box,"📂 انتخاب ویدیو"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_VIDEO)}
        btn(box,"▶️ پخش"){if(vv.duration>0)vv.start()else toast("ابتدا ویدیو را انتخاب کنید.")}
        btn(box,"⏸ توقف"){vv.pause()}
        box.addView(info,1);box.addView(vv,2,LinearLayout.LayoutParams(-1,320));back(box);setContentView(box)
        selectedMediaUri?.let { try { vv.setVideoURI(it) } catch (_:Exception) { toast("ویدیو قابل پخش نیست.") } }
    }

    private fun showAudioEditor(){
        val box=page("🎵 ابزار صوت آفلاین")
        val status=TextView(this).apply{text="فایلی انتخاب نشده است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        btn(box,"📂 انتخاب فایل صوتی برای پخش"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_AUDIO)}
        btn(box,"▶️ پخش"){audioPlayer?.start()?:toast("ابتدا فایل صوتی را انتخاب کنید.")}
        btn(box,"⏸ توقف"){audioPlayer?.pause()?:toast("فایل صوتی انتخاب نشده است.")}
        btn(box,"⏹ توقف کامل"){audioPlayer?.stop();audioPlayer?.release();audioPlayer=null;status.text="پخش متوقف شد."}
        btn(box,"🔐 رمزنگاری فایل صوتی"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_AUDIO_ENCRYPT)}
        btn(box,"🔓 رمزگشایی فایل صوتی"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/octet-stream";addCategory(Intent.CATEGORY_OPENABLE)},PICK_AUDIO_DECRYPT)}
        box.addView(status,1);back(box);setContentView(box)
    }

    private fun encryptAudio(uri:Uri){
        try{
            val source=contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل قابل خواندن نیست")
            val data=source.use{it.readBytes()}
            require(data.isNotEmpty())
            val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)}
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE,getKey(),GCMParameterSpec(128,nonce))
            val encrypted=cipher.doFinal(data)
            val name="SecureStudio_EncryptedAudio_${System.currentTimeMillis()}.ssaudio"
            val outUri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                put(MediaStore.Downloads.DISPLAY_NAME,name)
                put(MediaStore.Downloads.MIME_TYPE,"application/octet-stream")
            }) ?: throw IllegalStateException("ساخت فایل خروجی ممکن نشد")
            contentResolver.openOutputStream(outUri)?.use{it.write(nonce);it.write(encrypted)} ?: throw IllegalStateException("نوشتن خروجی ممکن نشد")
            toast("فایل صوتی رمزنگاری شد و در Downloads ذخیره شد.")
        }catch(e:Exception){toast("خطا در رمزنگاری صوت: ${e.message ?: "نامشخص"}")}
    }

    private fun decryptAudio(uri:Uri){
        try{
            val source=contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل قابل خواندن نیست")
            val data=source.use{it.readBytes()}
            require(data.size>28)
            val nonce=data.copyOfRange(0,12)
            val payload=data.copyOfRange(12,data.size)
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE,getKey(),GCMParameterSpec(128,nonce))
            val plain=cipher.doFinal(payload)
            val name="SecureStudio_DecryptedAudio_${System.currentTimeMillis()}.audio"
            val outUri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,ContentValues().apply{
                put(MediaStore.Downloads.DISPLAY_NAME,name)
                put(MediaStore.Downloads.MIME_TYPE,"audio/*")
            }) ?: throw IllegalStateException("ساخت فایل خروجی ممکن نشد")
            contentResolver.openOutputStream(outUri)?.use{it.write(plain)} ?: throw IllegalStateException("نوشتن خروجی ممکن نشد")
            toast("فایل صوتی با موفقیت رمزگشایی شد و در Downloads ذخیره شد.")
        }catch(e:Exception){toast("رمزگشایی صوت ناموفق است؛ فایل، کلید یا محتوای آن معتبر نیست.")}
    }

    private fun showTranslator(){
        val box=page("🌐 مترجم آفلاین پایه")
        val input=EditText(this).apply{hint="متن فارسی یا انگلیسی";minLines=5;gravity=48}
        val output=EditText(this).apply{hint="ترجمه آفلاین";minLines=5;gravity=48}
        btn(box,"🔄 ترجمه آفلاین"){output.setText(offlineTranslate(input.text.toString()))}
        btn(box,"📋 کپی ترجمه"){copyText(output.text.toString());toast("ترجمه کپی شد.")}
        box.addView(TextView(this).apply{text="این نسخه یک واژه‌نامه آفلاین پایه دارد و برای ترجمه کامل چندزبانه به موتور ترجمه نیاز است.";setTextColor(0xFF9FCBC1.toInt())},1)
        box.addView(input,2);box.addView(output,4);back(box);setContentView(box)
    }

    private fun offlineTranslate(t:String):String{
        val dict=mapOf("hello" to "سلام","hi" to "سلام","thanks" to "ممنون","thank you" to "متشکرم","yes" to "بله","no" to "خیر","good" to "خوب","bad" to "بد","سلام" to "hello","ممنون" to "thanks","بله" to "yes","خیر" to "no","خوب" to "good")
        return dict[t.trim().lowercase()] ?: "برای این عبارت، ترجمه آفلاین در واژه‌نامه فعلی موجود نیست."
    }

    private fun showVoiceTools(){
        val box=page("🎙️ ابزار صوت و گفتار")
        box.addView(TextView(this).apply{text="امکانات صوتی پایه آفلاین\n\n• تبدیل متن به گفتار با موتور داخلی Android\n• پخش و کنترل صوت\n\nتبدیل/کلون‌سازی صدای حرفه‌ای هنوز موتور اختصاصی می‌خواهد و در این نسخه به‌صورت محلی شبیه‌سازی نمی‌شود.";setTextColor(0xFFEAF7F4.toInt());setPadding(0,0,0,16)})
        val input=EditText(this).apply{hint="متن برای خواندن";minLines=4}
        btn(box,"🔊 خواندن متن با صدای دستگاه"){if(input.text.isBlank())toast("متن را وارد کنید.")else{lateinit var tts: android.speech.tts.TextToSpeech
tts = android.speech.tts.TextToSpeech(this){status->if(status==android.speech.tts.TextToSpeech.SUCCESS){tts.speak(input.text.toString(), android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "securestudio_tts")}};toast("در حال آماده‌سازی موتور گفتار...")}}
        box.addView(input,1);back(box);setContentView(box)
    }

    private val ttsLocaleHack: Unit get() = Unit

    private fun validAdminPassword(p:String):Boolean{val symbols=p.count{!it.isLetterOrDigit()};return p.length in 8..22&&symbols>=2}
    private fun changeSecurityQuestion(){
        val box=page("🛡️ تغییر سؤال امنیتی مدیر")
        val question = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(
                "نام اولین مدرسه شما چه بود؟",
                "نام اولین شهر محل زندگی شما چه بود؟",
                "نام یک دوست دوران کودکی شما چه بود؟",
                "غذای مورد علاقه شما چیست؟"
            ))
            setSelection(prefs.getInt("security_question",0))
        }
        val answer=EditText(this).apply{hint="پاسخ جدید سؤال امنیتی"}
        btn(box,"💾 ذخیره سؤال امنیتی جدید"){
            val a=answer.text.toString().trim()
            if(a.length>=2){prefs.edit().putInt("security_question",question.selectedItemPosition).putString("security_answer",hash(a)).apply();toast("سؤال امنیتی تغییر کرد.");showAdminPanel()}
            else toast("پاسخ سؤال امنیتی را وارد کنید.")
        }
        box.addView(question);box.addView(answer);back(box);setContentView(box)
    }

    private fun changeAdminPassword(){
        val input=EditText(this).apply{hint="رمز جدید مدیر (8 تا 22 کاراکتر، حداقل 2 نماد)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialogBuilder("🔄 تغییر رمز مدیر",input){val p=input.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).apply();toast("رمز مدیر تغییر کرد.")}else toast("رمز شرایط لازم را ندارد.")}.show()
    }

    private fun setPin(){val input=EditText(this).apply{hint="PIN حداقل 6 رقم";inputType=2};AlertDialogBuilder("تنظیم PIN",input){val p=input.text.toString();if(p.length>=6){prefs.edit().putString("pin",hash(p)).apply();toast("PIN ذخیره شد.")}else toast("PIN باید حداقل 6 رقم باشد.")}.show()}
    private fun verifyPin(){val input=EditText(this).apply{hint="PIN";inputType=2};AlertDialogBuilder("باز کردن قفل",input){if(hash(input.text.toString())==prefs.getString("pin",null))toast("قفل باز شد.")else toast("PIN نادرست است.")}.show()}

    private fun copyText(value:String){
        val clip=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clip.setPrimaryClip(android.content.ClipData.newPlainText("SecureStudio",value))
    }

    private fun hash(s:String):String{val md=java.security.MessageDigest.getInstance("SHA-256");return Base64.getEncoder().encodeToString(md.digest(s.toByteArray(StandardCharsets.UTF_8)))}
    private fun encrypt(text:String):String{
        require(text.isNotEmpty())
        val key=getKey()
        val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)}
        val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE,key,GCMParameterSpec(128,nonce))
        val encrypted=c.doFinal(text.toByteArray(StandardCharsets.UTF_8))
        return Base64.getEncoder().encodeToString(nonce+encrypted)
    }
    private fun decrypt(encoded:String):String{
        val clean=encoded.trim()
        require(clean.isNotEmpty())
        val all=try{Base64.getDecoder().decode(clean)}catch(e:IllegalArgumentException){throw IllegalArgumentException("Base64 نامعتبر",e)}
        require(all.size>12)
        val nonce=all.copyOfRange(0,12)
        val payload=all.copyOfRange(12,all.size)
        require(payload.size>=16)
        val c=Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE,getKey(),GCMParameterSpec(128,nonce))
        return String(c.doFinal(payload),StandardCharsets.UTF_8)
    }
    private fun getKey():SecretKey{val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)};if(ks.containsAlias("SecureStudioKey"))return(ks.getKey("SecureStudioKey",null) as SecretKey);val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(KeyGenParameterSpec.Builder("SecureStudioKey",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return kg.generateKey()}
    private fun showExtracted(text:String){AlertDialogBuilder("پیام استخراج‌شده",TextView(this).apply{this.text=text;setTextColor(0xFFEAF7F4.toInt());setPadding(20,20,20,20)}){}.show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun AlertDialogBuilder(title:String,view:android.view.View,onOk:()->Unit):android.app.AlertDialog=android.app.AlertDialog.Builder(this).setTitle(title).setView(view).setNegativeButton("انصراف",null).setPositiveButton("تأیید"){_,_->onOk()}.create()
}
