package com.securestudio.v1

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.os.SystemClock
import android.os.Build
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.text.Normalizer
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private enum class AccessRole { ADMIN, A, M, S, TEMPORARY }
    private data class AuthSession(val role: AccessRole, val token: ByteArray, val startedAt: Long)
    private var authSession: AuthSession? = null
    private val sessionTimeoutMs = 30 * 60 * 1000L

    private fun establishSession(role: AccessRole) {
        authSession = AuthSession(role, ByteArray(32).also { SecureRandom().nextBytes(it) }, SystemClock.elapsedRealtime())
    }
    private fun clearSession() { authSession = null }
    private fun currentRole(): AccessRole? {
        val s = authSession ?: return null
        if (SystemClock.elapsedRealtime() - s.startedAt > sessionTimeoutMs) { clearSession(); return null }
        return s.role
    }
    private fun isAuthorized(): Boolean = currentRole() != null
    private fun isAdminSession(): Boolean = currentRole() == AccessRole.ADMIN
    private fun roleKey(role: AccessRole): String = when(role) {
        AccessRole.A -> "a"; AccessRole.M -> "m"; AccessRole.S -> "s"; AccessRole.TEMPORARY -> "temporary"; AccessRole.ADMIN -> "admin"
    }

    private val prefs by lazy { getSharedPreferences("secure_studio", MODE_PRIVATE) }
    private val rooms = mutableListOf<String>()
    private var currentRoom = "عمومی"
    private val chatCache = mutableMapOf<String, MutableList<String>>()
    // Access sequences are assembled rather than stored as searchable plain strings.
    private val ADMIN_TRIGGER = decodeSequence(intArrayOf(0x09,0x33,0x34,0x71,0x77,0x70,0x75,0x6B,0x6B,0x6F,0x6B,0x7F,0x67,0x6B,0x69,0x6C,0x62))
    private val ACCESS_CODE_A = decodeSequence(intArrayOf(0x0E,0x3B,0x34,0x75,0x71,0x77,0x70,0x7F,0x67,0x6F,0x6D))
    private val ACCESS_CODE_M = decodeSequence(intArrayOf(0x19,0x35,0x2E,0x70,0x71,0x7F,0x75,0x77,0x67,0x68,0x68))
    private val ACCESS_CODE_S = decodeSequence(intArrayOf(0x19,0x35,0x29,0x71,0x70,0x7F,0x77,0x75,0x67,0x6A,0x6B))
    private val ACCESS_CODE_TEMP = decodeSequence(intArrayOf(0x19,0x35,0x29,0x71,0x7F,0x7F,0x67,0x6A))
    private var pendingMessage: String = ""
    private val PICK_IMAGE = 1001
    private val PICK_FILE_ENCRYPT = 3001
    private val CREATE_FILE_ENCRYPT = 3002
    private val PICK_FILE_DECRYPT = 3003
    private val CREATE_FILE_DECRYPT = 3004
    private val PICK_STEGO_FILE = 3101
    private val PICK_STEGO_CARRIER = 3102
    private val PICK_STEGO_EXTRACT_IMAGE = 3103
    private val CREATE_STEGO_EXTRACT = 3104
    private var pendingFileUri: Uri? = null
    private var pendingStegoFileUri: Uri? = null
    private var pendingStegoImageUri: Uri? = null

    private fun decodeSequence(values: IntArray): String =
        values.map { (it xor 0x5A).toChar() }.joinToString("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rooms.addAll(prefs.getStringSet("rooms", setOf("عمومی"))!!.toList().sorted())
        if (rooms.isEmpty()) rooms.add("عمومی")
        currentRoom = rooms.first()
        // امنیت: در هر اجرای برنامه، جلسه قبلی مدیر/کاربر معتبر نیست و باید احراز هویت انجام شود.
        window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
        clearSession()
        if (SecurityGuard.isReleaseLike(this)) {
            if (SecurityGuard.isDebuggerAttached() || SecurityGuard.hasCommonRootArtifacts()) {
                toast("محیط اجرای ناامن شناسایی شد.")
                finishAndRemoveTask()
                return
            }
            val expectedCert = BuildConfig.SECURE_CERT_SHA256
            if (!SecurityGuard.signatureMatches(this, expectedCert)) {
                toast("امضای برنامه معتبر نیست.")
                finishAndRemoveTask()
                return
            }
        }
        // Legacy state cleanup only; there is no password/setup UI in this build.
        prefs.edit()
            .remove("program_unlocked")
            .remove("admin_session")
            .remove("license_prefix")
            .remove("temporary_session")
            .remove("pending_license_prefix")
            .remove("legacy_setup")
            .apply()

        // FIRST SCREEN: engineering calculator only.
        showProgramAccessGate()
    }

    private fun showProgramAccessGate() { showEngineeringCalculator() }

    private fun showEngineeringCalculator() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(7, 12, 20))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "Secure Studio"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, 52, 1f))
        header.addView(TextView(this).apply {
            text = "ENGINEERING"
            textSize = 10f
            setTextColor(Color.rgb(120, 210, 190))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(110, 52))
        root.addView(header)

        val display = EditText(this).apply {
            hint = "0"
            textSize = 30f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(100, 115, 130))
            setPadding(18, 10, 18, 10)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.rgb(17, 25, 37))
                setStroke(1, Color.rgb(40, 58, 72))
            }
        }
        root.addView(display, LinearLayout.LayoutParams(-1, 92).apply { topMargin = 12; bottomMargin = 8 })

        val history = TextView(this).apply {
            text = ""
            textSize = 13f
            gravity = Gravity.END
            setTextColor(Color.rgb(130, 155, 165))
            setPadding(8, 0, 8, 8)
        }
        root.addView(history, LinearLayout.LayoutParams(-1, 32))

        val grid = android.widget.GridLayout(this).apply {
            columnCount = 4
            rowCount = 8
            alignmentMode = android.widget.GridLayout.ALIGN_MARGINS
            useDefaultMargins = false
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        fun addKey(label: String, value: String = label, span: Int = 1, action: (() -> Unit)? = null) {
            val b = TextView(this).apply {
                text = label
                textSize = if (label.length > 3) 13f else 18f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = 20f
                    setColor(when {
                        label == "=" -> Color.rgb(38, 135, 112)
                        label == "AC" || label == "⌫" -> Color.rgb(92, 48, 57)
                        label == "sin" || label == "cos" || label == "tan" || label == "cot" || label == "√" || label == "x²" || label == "1/x" -> Color.rgb(27, 49, 64)
                        else -> Color.rgb(23, 34, 48)
                    })
                    setStroke(1, Color.rgb(48, 66, 82))
                }
                setOnClickListener { action?.invoke() ?: display.append(value) }
                isClickable = true
                isFocusable = true
            }
            val lp = android.widget.GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, span, 1f)
                rowSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1, 1f)
                setMargins(4, 4, 4, 4)
            }
            grid.addView(b, lp)
        }

        addKey("sin", "Sin")
        addKey("cos", "Cos")
        addKey("tan", "Tan")
        addKey("cot", "Cot")
        addKey("(")
        addKey(")")
        addKey("π") { display.append(Math.PI.toString()) }
        addKey("e") { display.append(Math.E.toString()) }
        addKey("7"); addKey("8"); addKey("9"); addKey("÷", "/")
        addKey("4"); addKey("5"); addKey("6"); addKey("×", "*")
        addKey("1"); addKey("2"); addKey("3"); addKey("−", "-")
        addKey("0"); addKey("."); addKey("%"); addKey("+")
        addKey("√") { applyUnary(display, history, "√") { Math.sqrt(it) } }
        addKey("x²") { applyUnary(display, history, "x²") { it * it } }
        addKey("1/x") { applyUnary(display, history, "1/x") { if (it == 0.0) throw ArithmeticException() else 1.0 / it } }
        addKey("AC") { display.setText(""); history.text = "" }
        addKey("⌫") { if (display.text.isNotEmpty()) display.text.delete(display.text.length - 1, display.text.length) }
        addKey("=") {
            val expr = display.text.toString().trim()
            when {
                expr.equals(ADMIN_TRIGGER, true) -> { establishSession(AccessRole.ADMIN); showAdminPanel() }
                expr.equals(ACCESS_CODE_A, true) -> openUserAfterCode("a")
                expr.equals(ACCESS_CODE_M, true) -> openUserAfterCode("m")
                expr.equals(ACCESS_CODE_S, true) -> openUserAfterCode("s")
                expr.equals(ACCESS_CODE_TEMP, true) -> openTemporaryAccess()
                else -> {
                    val result = evaluateEngineeringCalculator(expr)
                    if (result != null) { history.text = "$expr = $result"; display.setText(result) }
                    else toast("عبارت نامعتبر است.")
                }
            }
        }
        setContentView(root)
    }

    private fun applyUnary(display: EditText, history: TextView, label: String, operation: (Double) -> Double) {
        val value = display.text.toString().trim().toDoubleOrNull()
        if (value == null) { toast("ابتدا یک عدد وارد کنید."); return }
        try {
            val result = operation(value)
            if (!result.isFinite()) throw ArithmeticException()
            val shown = result.toString()
            history.text = "تاریخچه: $label($value) = $shown"
            display.setText(shown)
        } catch (_: Exception) { toast("محاسبه برای این عدد امکان‌پذیر نیست.") }
    }

    private fun evaluateEngineeringCalculator(expr: String): String? {
        if (expr.isBlank()) return null
        if (expr.any { !(it.isDigit() || it in "+-*/%.() ") }) return null
        return try {
            val normalized = expr.replace("%", "/100")
            val tokens = Regex("(?<=[+\\-*/()])|(?=[+\\-*/()])")
                .split(normalized).map { it.trim() }.filter { it.isNotEmpty() }
            val vals = java.util.ArrayDeque<Double>()
            val ops = java.util.ArrayDeque<Char>()
            fun prec(c: Char) = if (c == '+' || c == '-') 1 else 2
            fun apply() {
                if (vals.size < 2 || ops.isEmpty()) throw ArithmeticException()
                val b = vals.removeLast(); val a = vals.removeLast()
                when (ops.removeLast()) {
                    '+' -> vals.addLast(a + b)
                    '-' -> vals.addLast(a - b)
                    '*' -> vals.addLast(a * b)
                    '/' -> { if (b == 0.0) throw ArithmeticException(); vals.addLast(a / b) }
                    else -> throw ArithmeticException()
                }
            }
            for (t in tokens) {
                when {
                    t.matches(Regex("[0-9]+(?:\\.[0-9]+)?")) -> vals.addLast(t.toDouble())
                    t == "(" -> ops.addLast('(')
                    t == ")" -> {
                        while (ops.isNotEmpty() && ops.peekLast() != '(') apply()
                        if (ops.isEmpty()) throw ArithmeticException()
                        ops.removeLast()
                    }
                    t.length == 1 && t[0] in "+-*/" -> {
                        while (ops.isNotEmpty() && ops.peekLast() != '(' && prec(ops.peekLast()) >= prec(t[0])) apply()
                        ops.addLast(t[0])
                    }
                    else -> throw ArithmeticException()
                }
            }
            while (ops.isNotEmpty()) { if (ops.peekLast() == '(') throw ArithmeticException(); apply() }
            if (vals.size != 1) throw ArithmeticException()
            val result = vals.peekLast()
            if (!result.isFinite()) throw ArithmeticException()
            result.toString()
        } catch (_: Exception) { null }
    }

    private fun openTemporaryAccess(){
        if (prefs.getBoolean("temporary_code_consumed", false)) {
            toast("این کد موقت قبلاً مصرف شده و دیگر معتبر نیست.")
            return
        }
        // Mark consumption before creating the session: a crash/restart cannot replay the code.
        prefs.edit().putBoolean("temporary_code_consumed", true).apply()
        establishSession(AccessRole.TEMPORARY)
        showHome()
    }

    private fun openUserAfterCode(prefix:String){
        // دسترسی کاربران فقط با توالی مخفی ماشین‌حساب انجام می‌شود.
        // هیچ فرم ورود/تعیین/تغییر رمز شخصی در برنامه وجود ندارد.
        val role = when(prefix) {
            "a" -> AccessRole.A
            "m" -> AccessRole.M
            else -> AccessRole.S
        }
        prefs.edit()
            .remove("user_password_a")
            .remove("user_password_m")
            .remove("user_password_s")
            .remove("pending_license_prefix")
            .apply()
        establishSession(role)
        showHome()
    }

    private fun page(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(20, 20, 20, 20)
        setBackgroundColor(0xFF07110F.toInt())
        layoutParams = ViewGroup.LayoutParams(-1, -1)
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 25f; setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFFEAF7F4.toInt()); setPadding(4, 8, 4, 18)
        })
    }

    private fun btn(parent: LinearLayout, text: String, action: () -> Unit): Button {
        val button = Button(this).apply {
            this.text = text
            textSize = 15f
            isAllCaps = false
            isEnabled = true
            alpha = 1.0f
            setTextColor(0xFFEAF7F4.toInt())
            setPadding(18, 12, 18, 12)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 22f
                setColor(0xFF16312C.toInt())
                setStroke(1, 0xFF2B5A50.toInt())
            }
            elevation = 2f
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        return button
    }

    private fun back(parent: LinearLayout) = btn(parent, "← بازگشت") { showHome() }

    private fun encrypt(value: String): String = OfflineCryptoManager.encrypt(value)
    private fun decrypt(value: String): String = OfflineCryptoManager.decrypt(value)

    private fun showHome() {
        val role = currentRole() ?: run { showProgramAccessGate(); return }
        val root = page("")

        val branding = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 12)
        }
        val logo = ImageView(this).apply {
            val uri = prefs.getString("app_logo_uri", null)
            if (!uri.isNullOrBlank()) {
                try { setImageURI(Uri.parse(uri)) } catch (_: Exception) { setImageResource(android.R.drawable.ic_lock_lock) }
            } else setImageResource(android.R.drawable.ic_lock_lock)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        branding.addView(logo, LinearLayout.LayoutParams(58, 58).apply { marginEnd = 12 })
        branding.addView(TextView(this).apply {
            text = prefs.getString("app_display_name", "Secure Studio")
            textSize = 26f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFFEAF7F4.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(branding, 1)

        val roleName = when (role) {
            AccessRole.ADMIN -> "مدیریت"
            AccessRole.A -> "دسترسی کامل"
            AccessRole.M -> "دسترسی متوسط"
            AccessRole.S -> "دسترسی محدود"
            AccessRole.TEMPORARY -> "دسترسی موقت"
        }
        val roleColor = when (role) {
            AccessRole.ADMIN -> 0xFFF0C674.toInt()
            AccessRole.A -> 0xFF69D2B3.toInt()
            AccessRole.M -> 0xFF7FC8FF.toInt()
            AccessRole.S -> 0xFFA9B7C6.toInt()
            AccessRole.TEMPORARY -> 0xFFE7A66B.toInt()
        }
        val badge = TextView(this).apply {
            text = "●  $roleName"
            textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(roleColor)
            setPadding(14, 10, 14, 10)
            background = GradientDrawable().apply {
                cornerRadius = 22f
                setColor(0xFF10201D.toInt())
                setStroke(1, roleColor)
            }
        }
        root.addView(badge, 2)

        val subtitle = TextView(this).apply {
            text = when (role) {
                AccessRole.ADMIN -> "تنظیمات مدیریتی برنامه"
                AccessRole.A -> "تمام سرویس‌های کاربری فعال هستند"
                AccessRole.M -> "سرویس‌های مجاز سطح متوسط در دسترس هستند"
                AccessRole.S -> "سرویس‌های پایه در دسترس هستند"
                AccessRole.TEMPORARY -> "جلسه موقت؛ پس از خروج دوباره قابل استفاده نیست"
            }
            textSize = 13f
            setTextColor(0xFF8FAAA4.toInt())
            setPadding(2, 10, 2, 18)
        }
        root.addView(subtitle, 3)

        fun allowed(area: String) = when (role) {
            AccessRole.ADMIN, AccessRole.A -> true
            AccessRole.M -> area == "crypto" || area == "chat" || area == "image" || area == "binary" || area == "file"
            AccessRole.S -> area == "crypto" || area == "binary"
            AccessRole.TEMPORARY -> area == "crypto" || area == "binary"
        }

        fun section(title: String) {
            root.addView(TextView(this).apply {
                text = title
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(0xFFBBD4CE.toInt())
                setPadding(4, 10, 4, 8)
            })
        }

        section("خدمات اصلی")
        if (allowed("crypto")) btn(root, "🔐  رمزنگاری و رمزگشایی متن") { requireSecure("crypto") { showCrypto() } }
        if (allowed("binary")) btn(root, "💻  متن و Binary") { requireSecure("binary") { showBinary() } }
        if (allowed("file")) {
            btn(root, "📦  رمزنگاری فایل آفلاین") { requireSecure("file") { showFileCrypto() } }
            btn(root, "🖼️📦  قرار دادن فایل رمزنگاری‌شده داخل تصویر") { requireSecure("file") { showFileImageStego() } }
        }
        if (allowed("chat")) btn(root, "💬  اتاق‌های پیام خصوصی") { requireSecure("chat") { showChat() } }
        if (allowed("image")) btn(root, "🖼️  پیام رمزگذاری‌شده داخل تصویر") { requireSecure("image") { showStego() } }

        section("امنیت و حساب")
        btn(root, "🛡️  وضعیت امنیت و جلسه") { requireSecure("security") { showSecurity() } }
        if (role == AccessRole.ADMIN) {
            btn(root, "⚙️  تنظیمات مدیریتی") { showAdminPanel() }
        }
        btn(root, "🚪  خروج امن") {
            clearSession()
                showProgramAccessGate()
        }
        setContentView(root)
    }

    private fun showAdminPanel() {
        if (!isAdminSession()) { showProgramAccessGate(); return }
        val box = page("⚙️ تنظیمات مدیریتی")
        box.addView(TextView(this).apply {
            text = "ورود مدیر فقط از طریق توالی مخفی ماشین‌حساب انجام می‌شود. هیچ فرم ورود متنی برای مدیریت در برنامه وجود ندارد."
            textSize = 14f
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 0, 0, 18)
        })
        btn(box, "🚪 خروج امن از مدیریت") { clearSession(); showProgramAccessGate() }
        setContentView(box)
    }

    private fun requireSecure(area: String, onSuccess: () -> Unit) {
        val role = currentRole() ?: run { showProgramAccessGate(); return }
        val prefix = when (role) {
            AccessRole.ADMIN, AccessRole.A -> "a"
            AccessRole.M -> "m"
            AccessRole.S -> "s"
            AccessRole.TEMPORARY -> "temporary"
        }
        val allowed = when (prefix) {
            "s", "temporary" -> area == "crypto" || area == "binary" || area == "security"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary" || area == "file" || area == "security"
            "a" -> true
            else -> false
        }
        if (allowed) { onSuccess(); return }
        showProgramAccessGate()
    }

    private fun areaTitle(area: String) = when(area) {
        "crypto" -> "رمزنگاری پیام"
        "chat" -> "پیام‌های خصوصی"
        "image" -> "پیام مخفی در تصویر"
        "binary" -> "رمزنگاری و Binary"
        "file" -> "رمزنگاری فایل آفلاین"
        else -> "بخش محافظت‌شده"
    }

    private fun showSecurity() {
        val box = page("🛡️ امنیت و جلسه")
        val role = currentRole()
        val roleText = when (role) {
            AccessRole.ADMIN -> "مدیر"
            AccessRole.A -> "دسترسی کامل"
            AccessRole.M -> "دسترسی متوسط"
            AccessRole.S -> "دسترسی محدود"
            AccessRole.TEMPORARY -> "دسترسی موقت"
            null -> "بدون جلسه"
        }
        box.addView(TextView(this).apply {
            text = "جلسه فعلی: $roleText\n\n• Screenshot/recording protection فعال است.\n• جلسه‌ها در حافظه نگهداری می‌شوند.\n• پس از خروج، جلسه پاک می‌شود.\n• برنامه برای کارکرد اصلی به اینترنت نیاز ندارد."
            setTextColor(0xFFEAF7F4.toInt())
            textSize = 15f
            setPadding(4, 8, 4, 18)
        })
        btn(box, "🚪 پایان جلسه فعلی") {
            clearSession()
                showProgramAccessGate()
        }
        back(box)
        setContentView(box)
    }

    private fun showCrypto() {
        val box = page("🔐 رمزنگاری متن")
        val input = EditText(this).apply {
            hint = "هر زبان Unicode: فارسی، العربية، English، Русский، 中文، 日本語 و متون باستانی…"
            minLines = 5
            gravity = 48
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val output = EditText(this).apply { hint = "خروجی رمزنگاری‌شده / متن رمزگشایی‌شده"; minLines = 7; gravity = 48 }
        btn(box,"🔐 رمزنگاری") {
            val value = Normalizer.normalize(input.text.toString(), Normalizer.Form.NFC)
            if (value.isBlank()) {
                toast("متن را وارد کنید.")
            } else {
                try {
                    output.setText(encrypt(value))
                    toast("رمزنگاری با موفقیت انجام شد.")
                } catch (e: Exception) {
                    output.setText("")
                    toast("خطا در رمزنگاری: ${e.message ?: "خطای نامشخص"}")
                }
            }
        }
        btn(box,"🔓 رمزگشایی") {
            // اگر کاربر بلافاصله بعد از رمزنگاری روی رمزگشایی بزند، ciphertext داخل خروجی است.
            // بنابراین ابتدا ورودی و در صورت خالی بودن آن، خروجی را امتحان می‌کنیم.
            val candidate = input.text.toString().trim().ifBlank { output.text.toString().trim() }
            if (candidate.isBlank()) {
                toast("متن رمزنگاری‌شده را وارد کنید یا ابتدا رمزنگاری کنید.")
            } else {
                try {
                    val plain = decrypt(candidate)
                    output.setText(plain)
                    toast("رمزگشایی با موفقیت انجام شد.")
                } catch (e: Exception) {
                    toast("رمزگشایی ناموفق؛ متن رمزنگاری‌شده معتبر نیست یا با این دستگاه تولید نشده است.")
                }
            }
        }
        btn(box,"↔️ انتقال خروجی به ورودی") {
            val value = output.text.toString()
            if (value.isBlank()) toast("خروجی خالی است.") else { input.setText(value); toast("خروجی به ورودی منتقل شد.") }
        }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input, 1); box.addView(output, 6); back(box); setContentView(box)
    }

    private fun showFileCrypto() {
        val box = page("📦 رمزنگاری فایل آفلاین")
        val info = TextView(this).apply {
            text = "هر نوع فایل قابل خواندن توسط Android را می‌توانید انتخاب کنید. رمزنگاری به‌صورت جریان‌محور (streaming) انجام می‌شود و سقف مصنوعی برای حجم فایل تعریف نشده است؛ محدودیت عملی فقط حافظه، فضای ذخیره‌سازی و توان دستگاه است."
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 0, 0, 18)
        }
        val status = TextView(this).apply { text = "آماده"; setTextColor(0xFFEAF7F4.toInt()) }
        btn(box, "🔐 انتخاب فایل و رمزنگاری") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, PICK_FILE_ENCRYPT)
        }
        btn(box, "🔓 انتخاب فایل رمزنگاری‌شده و رمزگشایی") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-ssf", "*/*"))
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, PICK_FILE_DECRYPT)
        }
        btn(box, "ℹ️ وضعیت") { toast(status.text.toString()) }
        box.addView(info, 1)
        box.addView(status)
        back(box)
        setContentView(box)
    }

    private fun showBinary() {
        val box = page("💻 متن و Binary")
        val input = EditText(this).apply { hint = "متن یا Binary با فاصله"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"متن → Binary") { output.setText(input.text.toString().toByteArray(StandardCharsets.UTF_8).joinToString(" ") { String.format("%8s", Integer.toBinaryString(it.toInt() and 255)).replace(' ','0') }) }
        btn(box,"Binary → متن") { try { output.setText(String(input.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.toInt(2).toByte() }.toByteArray(), StandardCharsets.UTF_8)) } catch (_: Exception) { output.setText("Binary معتبر نیست.") } }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input,1); box.addView(output,6); back(box); setContentView(box)
    }

    private fun showChat() {
        val box = page("💬 اتاق‌های پیام خصوصی")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rooms)
        spinner.setSelection(rooms.indexOf(currentRoom).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { currentRoom = rooms[pos]; refreshChat() }
        }
        box.addView(TextView(this).apply { text="اتاق فعلی"; setTextColor(0xFFEAF7F4.toInt()) })
        box.addView(spinner)
        val messages = TextView(this).apply { minHeight=260; setTextColor(0xFFEAF7F4.toInt()); setPadding(8,16,8,16) }
        val input = EditText(this).apply { hint="پیام" }
        val send = Button(this).apply { text="ارسال رمزگذاری‌شده"; isAllCaps=false }
        send.setOnClickListener {
            val msg=input.text.toString(); if(msg.isNotBlank()) { val list=chatCache.getOrPut(currentRoom){mutableListOf()}; list.add("شما: "+encrypt(msg)); input.text.clear(); refreshChat(messages) }
        }
        btn(box,"➕ ساخت اتاق جدید") { createRoomAndRefresh() }
        box.addView(messages); box.addView(input); box.addView(send); back(box)
        refreshChat(messages); setContentView(box)
    }

    private fun refreshChat(target: TextView? = null) {
        val t = target ?: return
        val list=chatCache.getOrPut(currentRoom){mutableListOf()}
        t.text = if(list.isEmpty()) "این اتاق هنوز پیامی ندارد." else list.joinToString("\n\n")
    }

    private fun createRoomAndRefresh() {
        val input=EditText(this).apply { hint="نام اتاق" }
        AlertDialogBuilder("ساخت اتاق", input) { val n=input.text.toString().trim(); if(n.isNotEmpty()&&!rooms.contains(n)){rooms.add(n);prefs.edit().putStringSet("rooms",rooms.toSet()).apply();currentRoom=n;showChat()} }.show()
    }

    private fun showBusy(title: String, message: String): android.app.AlertDialog {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(28, 12, 28, 20)
        }
        val progress = android.widget.ProgressBar(this).apply {
            isIndeterminate = true
        }
        val text = TextView(this).apply {
            this.text = message
            setTextColor(0xFFEAF7F4.toInt())
            setPadding(20, 0, 0, 0)
        }
        layout.addView(progress, LinearLayout.LayoutParams(56, 56))
        layout.addView(text, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(layout)
            .setCancelable(false)
            .create().also { it.show() }
    }

    private fun showFileImageStego() {
        val box = page("🖼️📦 فایل رمزنگاری‌شده داخل تصویر")
        val info = TextView(this).apply {
            text = "فایل ابتدا با AES-GCM به‌صورت آفلاین و Streaming رمزنگاری می‌شود، سپس ciphertext به‌صورت LSB داخل تصویر قرار می‌گیرد. محدودیت مصنوعی حجمی وجود ندارد؛ محدودیت واقعی فقط ظرفیت تصویر، فضای ذخیره‌سازی، حافظه و توان دستگاه است. خروجی همیشه PNG است."
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(4, 8, 4, 18)
        }
        val status = TextView(this).apply {
            text = "وضعیت: آماده"
            setTextColor(0xFFEAF7F4.toInt())
            setPadding(4, 4, 4, 14)
        }
        box.addView(info, 1)
        box.addView(status)
        lateinit var embedButton: Button
        lateinit var extractButton: Button
        embedButton = btn(box, "📦➡️🖼️ انتخاب فایل و تصویر برای جاسازی") {
            status.text = "وضعیت: انتخاب فایل…"
            embedButton.isEnabled = false
            extractButton.isEnabled = false
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, PICK_STEGO_FILE)
        }
        extractButton = btn(box, "🖼️➡️📦 استخراج فایل از تصویر") {
            status.text = "وضعیت: انتخاب تصویر…"
            embedButton.isEnabled = false
            extractButton.isEnabled = false
            startActivityForResult(createImagePickerIntent(), PICK_STEGO_EXTRACT_IMAGE)
        }
        // Selection happens asynchronously; restore buttons whenever the user returns.
        box.tag = status
        back(box)
        setContentView(box)
    }

    private fun showStego() {
        val box=page("🖼️ پیام رمزگذاری‌شده داخل تصویر")
        val message=EditText(this).apply{
            hint="پیام با هر زبان Unicode؛ فارسی، عربی، اردو، عبری، یونانی، لاتین، چینی، ژاپنی و خط‌های باستانیِ پشتیبانی‌شده توسط Unicode/فونت دستگاه"
            minLines=5
            gravity=48
            inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextDirection(android.view.View.TEXT_DIRECTION_ANY_RTL)
        }
        val info=TextView(this).apply{
            text="ورودی: هر قالب تصویری که Android دستگاه بتواند decode کند. پیام با UTF-8 و NFC پردازش و قبل از جاسازی AES-GCM می‌شود. سقف مصنوعی برای حجم پیام وجود ندارد؛ ظرفیت واقعی تصویر و محدودیت‌های فیزیکی دستگاه تنها محدودکننده‌اند. خروجی استگانوگرافی همیشه PNG است."
            setTextColor(0xFF9FCBC1.toInt())
            setPadding(0, 8, 0, 14)
        }
        val status=TextView(this).apply{ text="وضعیت: آماده"; setTextColor(0xFFEAF7F4.toInt()); setPadding(0,0,0,12) }
        lateinit var embedButton: Button
        lateinit var extractButton: Button
        embedButton=btn(box,"📂 انتخاب تصویر و جاسازی پیام"){
            val value=Normalizer.normalize(message.text.toString(), Normalizer.Form.NFC)
            if(value.isBlank()){ toast("ابتدا پیام را وارد کنید."); return@btn }
            pendingMessage=value
            status.text="وضعیت: انتخاب تصویر…"
            embedButton.isEnabled=false; extractButton.isEnabled=false
            startActivityForResult(createImagePickerIntent(),PICK_IMAGE)
        }
        extractButton=btn(box,"📂 انتخاب تصویر و استخراج پیام"){
            status.text="وضعیت: انتخاب تصویر…"
            embedButton.isEnabled=false; extractButton.isEnabled=false
            startActivityForResult(createImagePickerIntent(),PICK_IMAGE+1)
        }
        box.addView(message,1);box.addView(info,2);box.addView(status,3);back(box);setContentView(box)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null){ if(requestCode==PICK_IMAGE){ pendingMessage="" }; return };val uri=data.data!!
        if(requestCode==PICK_FILE_ENCRYPT){
            pendingFileUri = uri
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "application/octet-stream"
                putExtra(Intent.EXTRA_TITLE, "SecureStudio_${System.currentTimeMillis()}.ssf")
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, CREATE_FILE_ENCRYPT)
        } else if(requestCode==PICK_FILE_DECRYPT){
            pendingFileUri = uri
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_TITLE, "SecureStudio_decrypted_${System.currentTimeMillis()}")
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, CREATE_FILE_DECRYPT)
        } else if(requestCode==CREATE_FILE_ENCRYPT){
            val source = pendingFileUri
            pendingFileUri = null
            if(source == null){ toast("فایل ورودی مشخص نیست."); return }
            runFileOperation(source, uri, true)
        } else if(requestCode==CREATE_FILE_DECRYPT){
            val source = pendingFileUri
            pendingFileUri = null
            if(source == null){ toast("فایل رمزنگاری‌شده مشخص نیست."); return }
            runFileOperation(source, uri, false)
        } else if(requestCode==PICK_STEGO_FILE){
            pendingStegoFileUri = uri
            startActivityForResult(createImagePickerIntent(), PICK_STEGO_CARRIER)
        } else if(requestCode==PICK_STEGO_CARRIER){
            val source = pendingStegoFileUri
            pendingStegoFileUri = null
            if (source == null) { toast("فایل ورودی مشخص نیست."); return }
            runFileIntoImage(source, uri)
        } else if(requestCode==PICK_STEGO_EXTRACT_IMAGE){
            pendingStegoImageUri = uri
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "application/octet-stream"
                putExtra(Intent.EXTRA_TITLE, "SecureStudio_extracted_${System.currentTimeMillis()}.bin")
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, CREATE_STEGO_EXTRACT)
        } else if(requestCode==CREATE_STEGO_EXTRACT){
            val image = pendingStegoImageUri
            pendingStegoImageUri = null
            if (image == null) { toast("تصویر ورودی مشخص نیست."); return }
            runFileFromImage(image, uri)
        } else if(requestCode==PICK_IMAGE){
            val messageForEmbedding = pendingMessage
            pendingMessage = ""
            val busy = showBusy("جاسازی پیام", "پیام در حال رمزنگاری و جاسازی داخل تصویر است…")
            Thread {
                var bmp: Bitmap? = null
                var result: Bitmap? = null
                try {
                    bmp = loadBitmap(uri) ?: error("تصویر قابل خواندن نیست.")
                    val normalized = Normalizer.normalize(messageForEmbedding, Normalizer.Form.NFC)
                    val encrypted=encrypt(normalized).toByteArray(StandardCharsets.UTF_8)
                    val capacity=SteganographyManager.capacity(bmp,encrypted.size)
                    require(capacity.requiredBytes.toLong() <= capacity.availableBytes) {
                        "ظرفیت تصویر کافی نیست. ظرفیت موجود: ${capacity.availableBytes} بایت؛ موردنیاز: ${capacity.requiredBytes} بایت."
                    }
                    result=SteganographyManager.embed(bmp,encrypted)
                    saveBitmap(result)
                    runOnUiThread { toast("پیام رمزگذاری‌شده با موفقیت داخل PNG قرار گرفت.") }
                } catch(e:Exception) {
                    runOnUiThread { toast(e.message ?: "جاسازی پیام ناموفق بود.") }
                } finally {
                    try { bmp?.recycle() } catch (_:Exception) {}
                    try { result?.recycle() } catch (_:Exception) {}
                    runOnUiThread { busy.dismiss(); showStego() }
                }
            }.start()
        } else if(requestCode==PICK_IMAGE+1){
            val busy = showBusy("استخراج پیام", "داده داخل تصویر در حال استخراج و رمزگشایی است…")
            Thread {
                var bmp: Bitmap? = null
                try {
                    bmp=loadBitmap(uri) ?: error("تصویر قابل خواندن نیست.")
                    val encrypted=SteganographyManager.extract(bmp)
                    val plain=decrypt(String(encrypted,StandardCharsets.UTF_8))
                    runOnUiThread { showExtracted(plain) }
                } catch(e:Exception) {
                    runOnUiThread { toast("پیام معتبر Secure Studio پیدا نشد؛ تصویر ممکن است فشرده، خراب یا دستکاری شده باشد.") }
                } finally {
                    try { bmp?.recycle() } catch (_:Exception) {}
                    runOnUiThread { busy.dismiss(); showStego() }
                }
            }.start()
        }
    }

    private fun runFileIntoImage(source: Uri, carrierUri: Uri) {
        val busy = showBusy("جاسازی فایل", "فایل در حال رمزنگاری و قرارگیری داخل تصویر است…")
        Thread {
            var temp: java.io.File? = null
            var bitmap: Bitmap? = null
            var result: Bitmap? = null
            try {
                bitmap = loadBitmap(carrierUri) ?: error("تصویر قابل خواندن نیست.")
                val tempFile = java.io.File(cacheDir, "stego_${System.currentTimeMillis()}.ssf")
                temp = tempFile
                FileCryptoManager.encryptToFile(contentResolver, source, tempFile)
                val encryptedSize = tempFile.length()
                val capacity = FileImageSteganographyManager.capacity(bitmap, encryptedSize)
                require(capacity.requiredBytes <= capacity.availableBytes) {
                    "ظرفیت تصویر کافی نیست. لازم: ${capacity.requiredBytes} بایت؛ موجود: ${capacity.availableBytes} بایت."
                }
                result = FileImageSteganographyManager.embed(bitmap, { java.io.BufferedInputStream(java.io.FileInputStream(tempFile), 64 * 1024) }, encryptedSize)
                saveBitmap(result!!)
                runOnUiThread { toast("فایل با موفقیت رمزنگاری و داخل تصویر PNG جاسازی شد.") }
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: "جاسازی فایل داخل تصویر ناموفق بود.") }
            } finally {
                try { bitmap?.recycle() } catch (_: Exception) {}
                try { result?.recycle() } catch (_: Exception) {}
                try { temp?.delete() } catch (_: Exception) {}
                runOnUiThread { busy.dismiss(); showFileImageStego() }
            }
        }.start()
    }

    private fun runFileFromImage(imageUri: Uri, destination: Uri) {
        val busy = showBusy("استخراج فایل", "داده از تصویر استخراج و سپس رمزگشایی می‌شود…")
        Thread {
            var temp: java.io.File? = null
            var bitmap: Bitmap? = null
            try {
                bitmap = loadBitmap(imageUri) ?: error("تصویر قابل خواندن نیست.")
                temp = java.io.File(cacheDir, "extracted_${System.currentTimeMillis()}.ssf")
                java.io.BufferedOutputStream(java.io.FileOutputStream(temp), 64 * 1024).use { out ->
                    FileImageSteganographyManager.extract(bitmap!!, out)
                }
                FileCryptoManager.decryptFromFile(temp!!, contentResolver, destination)
                runOnUiThread { toast("فایل با موفقیت از تصویر استخراج و رمزگشایی شد.") }
            } catch (e: Exception) {
                try { contentResolver.delete(destination, null, null) } catch (_: Exception) {}
                runOnUiThread { toast("استخراج/رمزگشایی ناموفق؛ تصویر معتبر نیست یا فایل دستکاری شده است.") }
            } finally {
                try { bitmap?.recycle() } catch (_: Exception) {}
                try { temp?.delete() } catch (_: Exception) {}
                runOnUiThread { busy.dismiss(); showFileImageStego() }
            }
        }.start()
    }

    private fun runFileOperation(source: Uri, destination: Uri, encrypting: Boolean) {
        val busy = showBusy(
            if (encrypting) "رمزنگاری فایل" else "رمزگشایی فایل",
            if (encrypting) "فایل به‌صورت آفلاین و Streaming رمزنگاری می‌شود…" else "فایل در حال اعتبارسنجی و رمزگشایی است…"
        )
        Thread {
            try {
                if (encrypting) FileCryptoManager.encrypt(contentResolver, source, destination)
                else FileCryptoManager.decrypt(contentResolver, source, destination)
                runOnUiThread { toast(if (encrypting) "رمزنگاری فایل با موفقیت انجام شد." else "رمزگشایی فایل با موفقیت انجام شد.") }
            } catch (e: Exception) {
                try { contentResolver.delete(destination, null, null) } catch (_: Exception) {}
                runOnUiThread { toast(if (encrypting) "رمزنگاری فایل ناموفق بود: ${e.message ?: "خطای نامشخص"}" else "رمزگشایی ناموفق؛ فایل معتبر نیست یا با این دستگاه تولید نشده است.") }
            } finally {
                runOnUiThread { busy.dismiss() }
            }
        }.start()
    }

    private fun createImagePickerIntent(): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            // image/* lets Android and the installed document provider expose every image MIME
            // it supports; the explicit list improves filtering on providers with weak MIME metadata.
            type = "image/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "image/jpeg", "image/png", "image/webp", "image/gif", "image/bmp",
                "image/heic", "image/heif", "image/avif", "image/x-icon",
                "image/vnd.wap.wbmp", "image/x-adobe-dng"
            ))
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun saveBitmap(bmp:Bitmap){
        require(bmp.config == Bitmap.Config.ARGB_8888) { "تصویر خروجی باید ARGB_8888 باشد." }
        val values=ContentValues().apply{
            put(MediaStore.Images.Media.DISPLAY_NAME,"SecureStudio_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE,"image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/SecureStudio")
        }
        val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: throw Exception("ایجاد فایل خروجی ممکن نشد.")
        try {
            contentResolver.openOutputStream(uri)?.use{
                if (!bmp.compress(Bitmap.CompressFormat.PNG,100,it)) throw Exception("نوشتن PNG ناموفق بود.")
            } ?: throw Exception("دسترسی به خروجی ممکن نشد.")
        } catch (e:Exception) {
            contentResolver.delete(uri,null,null)
            throw e
        }
    }

    private fun loadBitmap(uri:Uri):Bitmap? {
        return try {
            val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
                    decoder.isMutableRequired = false
                }
            } else {
                contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
            } ?: return null

            if (bmp.width <= 0 || bmp.height <= 0) {
                bmp.recycle()
                return null
            }
            // LSB embedding needs a predictable software bitmap; normalize every supported
            // source format to ARGB_8888 before reading/writing pixels.
            if (bmp.config == Bitmap.Config.ARGB_8888) bmp else bmp.copy(Bitmap.Config.ARGB_8888, false).also { bmp.recycle() }
        } catch (_:Exception) {
            // Fallback for document providers that expose a format ImageDecoder cannot parse.
            try {
                contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }?.let { bmp ->
                    if (bmp.width <= 0 || bmp.height <= 0) { bmp.recycle(); null }
                    else if (bmp.config == Bitmap.Config.ARGB_8888) bmp else bmp.copy(Bitmap.Config.ARGB_8888, false)
                }
            } catch (_:Exception) { null }
        }
    }

    private fun showExtracted(text:String){
        val view=TextView(this).apply{
            this.text=Normalizer.normalize(text, Normalizer.Form.NFC)
            setTextColor(0xFFEAF7F4.toInt())
            setPadding(20,20,20,20)
            textDirection = android.view.View.TEXT_DIRECTION_ANY_RTL
            textIsSelectable = true
        }
        AlertDialogBuilder("پیام استخراج‌شده",view){}.show()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun AlertDialogBuilder(title:String,view:android.view.View,onOk:()->Unit):android.app.AlertDialog=android.app.AlertDialog.Builder(this).setTitle(title).setView(view).setNegativeButton("انصراف",null).setPositiveButton("تأیید"){_,_->onOk()}.create()
}
