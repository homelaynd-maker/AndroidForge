# راهنمای Build نهایی Secure Studio V5.9.6

## وضعیت پروژه
- اولین صفحه برنامه: **ماشین‌حساب مهندسی**؛ هیچ صفحه «رمز مدیر اولیه» در startup وجود ندارد.
- مسیر Admin فقط از توالی مخفی ماشین‌حساب عبور می‌کند.
- برنامه برای سرویس‌های اصلی به اینترنت نیاز ندارد.
- `targetSdk = 35` و `compileSdk = 35`.
- Java/Kotlin روی JVM 17 تنظیم شده‌اند.
- Release با R8 و resource shrinking فعال است.
- در نسخه Release، اگر `secureCertSha256` تنظیم شود، امضای APK هنگام اجرا بررسی می‌شود.

## Build با Android Studio
1. پروژه را در Android Studio باز کنید.
2. اجازه دهید Gradle Sync کامل شود.
3. SDK Platform 35 و Android SDK Build-Tools مربوطه را نصب کنید.
4. برای تست اولیه: `Build > Make Project`.
5. برای APK تستی: `Build > Build APK(s)`.
6. برای نسخه نهایی: `Build > Generate Signed Bundle / APK` و یک keystore اختصاصی بسازید یا `keystore.properties` را تنظیم کنید.

## Build از ترمینال
این پروژه عمداً به Gradle Wrapper وابسته نشده است؛ بنابراین Gradle نصب‌شده یا Android Studio باید در محیط Build موجود باشد.

```text
gradle :app:assembleDebug
gradle :app:assembleRelease
```

## امضای Release
فایل `keystore.properties.example` را به `keystore.properties` کپی کنید و مقادیر واقعی را قرار دهید. فایل واقعی را منتشر یا commit نکنید.

برای فعال‌کردن بررسی certificate fingerprint، مقدار SHA-256 گواهی Release را به شکل زیر در `gradle.properties` قرار دهید:

```text
secureCertSha256=AA:BB:CC:...
```

اگر مقدار خالی باشد، بررسی certificate در runtime انجام نمی‌شود؛ این برای Build اولیه لازم است چون fingerprint فقط بعد از انتخاب keystore قطعی است.

## نصب نسخه جدید روی گوشی
برای تست دقیق startup، نسخه قدیمی برنامه را uninstall کنید تا state قدیمی باقی نماند؛ سپس APK جدید را نصب کنید. اگر داده‌های رمزنگاری‌شده وابسته به Android Keystore دارید، قبل از uninstall آن‌ها را نگه دارید، چون حذف برنامه ممکن است کلیدهای Keystore را حذف کند.

## انتظار بعد از نصب
صفحه اول باید مستقیماً **ماشین‌حساب مهندسی** باشد. اگر صفحه «راه‌اندازی اولیه برنامه / رمز مدیر» دیده شد، APK قدیمی نصب/اجرا شده است یا نصب قبلی پاک نشده است.
