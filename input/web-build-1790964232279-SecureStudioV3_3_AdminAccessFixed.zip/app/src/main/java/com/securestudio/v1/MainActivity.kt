package com.securestudio.v1

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("secure_studio", MODE_PRIVATE) }
    private val rooms = mutableListOf<String>()
    private var currentRoom = "عمومی"
    private val chatCache = mutableMapOf<String, MutableList<String>>()
    private val ADMIN_TRIGGER = "مدیر-ورود-2026"
    private val DEFAULT_GATE_ENABLED = true
    private var pendingImage: Bitmap? = null
    private var pendingMessage: String = ""
    private val PICK_IMAGE = 1001
    private val PICK_LOGO = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rooms.addAll(prefs.getStringSet("rooms", setOf("عمومی"))!!.toList().sorted())
        if (rooms.isEmpty()) rooms.add("عمومی")
        currentRoom = rooms.first()
        if (!prefs.contains("secure_gate")) prefs.edit().putBoolean("secure_gate", DEFAULT_GATE_ENABLED).apply()
        showHome()
    }

    private fun page(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(0xFF0B1412.toInt())
        layoutParams = ViewGroup.LayoutParams(-1, -1)
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 25f; setTextColor(0xFFEAF7F4.toInt()); setPadding(0, 8, 0, 18)
        })
    }

    private fun btn(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            isEnabled = true
            alpha = 1.0f
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun back(parent: LinearLayout) = btn(parent, "← بازگشت") { showHome() }

    private fun showHome() {
        val root = page("")
        val branding = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 10)
        }
        val logo = ImageView(this).apply {
            val uri = prefs.getString("app_logo_uri", null)
            if (!uri.isNullOrBlank()) {
                try { setImageURI(Uri.parse(uri)) } catch (_: Exception) { setImageResource(android.R.drawable.ic_lock_lock) }
            } else setImageResource(android.R.drawable.ic_lock_lock)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        branding.addView(logo, LinearLayout.LayoutParams(64,64).apply { marginEnd = 12 })
        branding.addView(TextView(this).apply {
            text = prefs.getString("app_display_name", "Secure Studio")
            textSize = 28f; setTextColor(0xFFEAF7F4.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(branding, 1)
        root.addView(TextView(this).apply {
            text = "نسخه ۳ • پنل مدیریت ویژه، کنترل دسترسی رمزنگاری و پیام خصوصی"
            textSize = 14f; setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,18)
        }, 2)
        btn(root, "🔐 رمزنگاری / رمزگشایی متن") { requireSecure("crypto") { showCrypto() } }
        btn(root, "💬 اتاق‌های پیام خصوصی") { requireSecure("chat") { showChat() } }
        btn(root, "🖼️ پیام رمزگذاری‌شده داخل تصویر") { requireSecure("image") { showStego() } }
        btn(root, "💻 متن ↔ Binary") { requireSecure("binary") { showBinary() } }
        btn(root, "🛡️ قفل برنامه و امنیت") { showSecurity() }
        btn(root, "📸 ویرایشگر تصویر — در بخش بعدی") { toast("ویرایشگر حرفه‌ای تصویر در بخش بعدی توسعه داده می‌شود.") }
        btn(root, "🎬 ویرایشگر ویدیو — در بخش بعدی") { toast("ویرایشگر ویدیو در بخش بعدی توسعه داده می‌شود.") }
        btn(root, "🎵 ویرایشگر صوت — در بخش بعدی") { toast("ویرایشگر صوت در بخش بعدی توسعه داده می‌شود.") }
        btn(root, "🌐 مترجم — در بخش بعدی") { toast("مترجم چندزبانه در بخش بعدی اضافه می‌شود.") }
        setContentView(root)
    }

    private fun requireSecure(area: String, onSuccess: () -> Unit) {
        // کد ویژه مدیر از همین پنجره قابل ورود است؛ بنابراین حتی وقتی
        // محافظت کاربر فعال شده، مسیر ورود مدیر مسدود نمی‌شود.
        val accessHash = prefs.getString("access_password", null)
        if (!prefs.getBoolean("secure_gate", true) || accessHash.isNullOrBlank()) {
            if (prefs.getBoolean("secure_gate", true) && accessHash.isNullOrBlank()) {
                toast("این بخش فعلاً بدون رمز اولیه باز می‌شود. برای مدیریت، کد ویژه مدیر را وارد کنید.")
            }
            onSuccess()
            return
        }
        val input = EditText(this).apply {
            hint = "پسورد کاربر یا کد ویژه مدیر"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialogBuilder("🔒 ورود امن به ${areaTitle(area)}", input) {
            val p = input.text.toString().trim()
            when {
                p == ADMIN_TRIGGER -> showAdminLogin()
                p.isNotEmpty() && hash(p) == accessHash -> onSuccess()
                else -> toast("پسورد نادرست است.")
            }
        }.show()
    }

    private fun areaTitle(area: String) = when(area) {
        "crypto" -> "رمزنگاری پیام"
        "chat" -> "پیام‌های خصوصی"
        "image" -> "پیام مخفی در تصویر"
        "binary" -> "رمزنگاری و Binary"
        else -> "بخش محافظت‌شده"
    }

    private fun showCrypto() {
        val box = page("🔐 رمزنگاری متن")
        val input = EditText(this).apply { hint = "متن یا متن رمزگذاری‌شده\n\nکد ویژه مدیر برای ورود: $ADMIN_TRIGGER"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"🔐 رمزنگاری") {
            val value = input.text.toString().trim()
            if (value == ADMIN_TRIGGER) { showAdminLogin(); return@btn }
            output.setText(encrypt(value))
        }
        btn(box,"🔓 رمزگشایی") {
            val value = input.text.toString().trim()
            if (value == ADMIN_TRIGGER) { showAdminLogin(); return@btn }
            try { output.setText(decrypt(value)) } catch (_: Exception) { output.setText("رمزگشایی ناموفق؛ کلید یا داده معتبر نیست.") }
        }
        box.addView(input, 1); box.addView(output, 4); back(box); setContentView(box)
    }

    private fun showBinary() {
        val box = page("💻 متن و Binary")
        val input = EditText(this).apply { hint = "متن یا Binary با فاصله"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"متن → Binary") { output.setText(input.text.toString().toByteArray(StandardCharsets.UTF_8).joinToString(" ") { String.format("%8s", Integer.toBinaryString(it.toInt() and 255)).replace(' ','0') }) }
        btn(box,"Binary → متن") { try { output.setText(String(input.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.toInt(2).toByte() }.toByteArray(), StandardCharsets.UTF_8)) } catch (_: Exception) { output.setText("Binary معتبر نیست.") } }
        box.addView(input,1); box.addView(output,4); back(box); setContentView(box)
    }

    private fun showChat() {
        val box = page("💬 اتاق‌های پیام خصوصی")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rooms)
        spinner.setSelection(rooms.indexOf(currentRoom).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { currentRoom = rooms[pos]; refreshChat() }
        }
        box.addView(TextView(this).apply { text="اتاق فعلی"; setTextColor(0xFFEAF7F4.toInt()) })
        box.addView(spinner)
        val messages = TextView(this).apply { minHeight=260; setTextColor(0xFFEAF7F4.toInt()); setPadding(8,16,8,16) }
        val input = EditText(this).apply { hint="پیام" }
        val send = Button(this).apply { text="ارسال رمزگذاری‌شده"; isAllCaps=false }
        send.setOnClickListener {
            val msg=input.text.toString(); if(msg.isNotBlank()) { val list=chatCache.getOrPut(currentRoom){mutableListOf()}; list.add("شما: "+encrypt(msg)); input.text.clear(); refreshChat(messages) }
        }
        btn(box,"➕ ساخت اتاق جدید") { createRoomAndRefresh() }
        box.addView(messages); box.addView(input); box.addView(send); back(box)
        refreshChat(messages); setContentView(box)
    }

    private fun refreshChat(target: TextView? = null) {
        val t = target ?: return
        val list=chatCache.getOrPut(currentRoom){mutableListOf()}
        t.text = if(list.isEmpty()) "این اتاق هنوز پیامی ندارد." else list.joinToString("\n\n")
    }

    private fun createRoomAndRefresh() {
        val input=EditText(this).apply { hint="نام اتاق" }
        AlertDialogBuilder("ساخت اتاق", input) { val n=input.text.toString().trim(); if(n.isNotEmpty()&&!rooms.contains(n)){rooms.add(n);prefs.edit().putStringSet("rooms",rooms.toSet()).apply();currentRoom=n;showChat()} }.show()
    }

    private fun showStego() {
        val box=page("🖼️ پیام رمزگذاری‌شده داخل تصویر")
        val message=EditText(this).apply{hint="پیامی که باید داخل تصویر قرار بگیرد";minLines=4;gravity=48}
        val info=TextView(this).apply{text="برای حفظ کیفیت، خروجی به PNG ذخیره می‌شود. تصویر اصلی تغییر محتوایی قابل مشاهده ندارد.";setTextColor(0xFF9FCBC1.toInt())}
        btn(box,"📂 انتخاب تصویر و جاسازی پیام"){pendingMessage=message.text.toString(); if(pendingMessage.isBlank()){toast("ابتدا پیام را وارد کنید.")}else{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE)}}
        btn(box,"📂 انتخاب تصویر و استخراج پیام"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/png";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE+1)}
        box.addView(message,1);box.addView(info,2);back(box);setContentView(box)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!
        if(requestCode==PICK_LOGO){
            try{
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }catch(_:Exception){}
            prefs.edit().putString("app_logo_uri",uri.toString()).apply()
            toast("لوگوی برنامه ذخیره شد.")
            showHome()
        } else if(requestCode==PICK_IMAGE){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{saveBitmap(embedMessage(bmp,pendingMessage))}catch(e:Exception){toast("خطا: ظرفیت تصویر کافی نیست یا فرمت مناسب نیست.")}}
        else if(requestCode==PICK_IMAGE+1){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{showExtracted(decrypt(extractMessage(bmp)))}catch(e:Exception){toast("پیام رمزگذاری‌شده معتبری در تصویر پیدا نشد.")}}
    }

    private fun embedMessage(src:Bitmap,text:String):Bitmap{val data=encrypt(text).toByteArray(StandardCharsets.UTF_8);val payload=ByteBuffer.allocate(4+data.size).putInt(data.size).put(data).array();val capacity=src.width*src.height*3;require(payload.size*8<=capacity);val out=src.copy(Bitmap.Config.ARGB_8888,true);var bit=0;for(y in 0 until out.height)for(x in 0 until out.width){val p=out.getPixel(x,y);val c=intArrayOf((p shr 16)and255,(p shr 8)and255,p and255);for(i in 0..2){if(bit<payload.size*8){val by=payload[bit/8].toInt()and255;val v=(by shr (7-(bit%8)))and1;c[i]=(c[i]and254)or v;bit++}}out.setPixel(x,y,android.graphics.Color.argb(255,c[0],c[1],c[2]));if(bit>=payload.size*8)return out};return out}
    private fun extractMessage(bmp:Bitmap):String{val bits=ArrayList<Int>();for(y in 0 until bmp.height)for(x in 0 until bmp.width){val p=bmp.getPixel(x,y);bits.add((p shr 16)and1);bits.add((p shr 8)and1);bits.add(p and1)};fun readInt(start:Int):Int{var v=0;for(i in 0..31)v=(v shl 1)or bits[start+i];return v};val len=readInt(0);require(len>0&&len<10000000&&32+len*8<=bits.size);val out=ByteArray(len);for(i in 0 until len){var v=0;for(j in 0..7)v=(v shl 1)or bits[32+i*8+j];out[i]=v.toByte()};return String(out,StandardCharsets.UTF_8)}
    private fun saveBitmap(bmp:Bitmap){val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"SecureStudio_${System.currentTimeMillis()}.png");put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/SecureStudio")};val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:throw Exception();contentResolver.openOutputStream(uri)!!.use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)};toast("تصویر در Pictures/SecureStudio ذخیره شد.")}
    private fun loadBitmap(uri:Uri):Bitmap?=contentResolver.openInputStream(uri).use{BitmapFactory.decodeStream(it)}

    private fun showSecurity(){
        val box=page("🛡️ امنیت برنامه")
        val status=TextView(this).apply{setTextColor(0xFFEAF7F4.toInt())}
        status.text=if(prefs.contains("pin"))"قفل PIN فعال است." else "قفل PIN هنوز تنظیم نشده است."
        btn(box,"🔑 تنظیم / تغییر PIN"){setPin()}
        btn(box,"🗑️ حذف PIN"){prefs.edit().remove("pin").apply();status.text="قفل PIN غیرفعال شد."}
        btn(box,"🔒 آزمایش قفل"){if(prefs.contains("pin"))verifyPin()else toast("ابتدا PIN تنظیم کنید.")}
        btn(box,"👑 ورود به پنل مدیریت"){showAdminLogin()}
        box.addView(status,1); back(box); setContentView(box)
    }

    private fun showAdminLogin(){
        if(!prefs.contains("admin_password")){
            val first=EditText(this).apply{hint="رمز مدیر، حداقل 8 و حداکثر 22 کاراکتر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            AlertDialogBuilder("👑 ایجاد رمز اولیه مدیر",first){val p=first.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).apply();toast("رمز مدیر ثبت شد. آن را در جای امن نگه دارید.");showAdminPanel()}else toast("رمز باید 8 تا 22 کاراکتر و دارای حداقل 2 نماد باشد.")}.show()
            return
        }
        val input=EditText(this).apply{hint="رمز ورود پنل مدیر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialogBuilder("🔐 ورود مدیر",input){if(hash(input.text.toString())==prefs.getString("admin_password",null))showAdminPanel()else toast("رمز مدیر نادرست است.")}.show()
    }

    private fun showAdminPanel(){
        val box=page("👑 پنل مدیریت ویژه")
        box.addView(TextView(this).apply{text="دسترسی این بخش برای مدیر است. از اینجا می‌توانید رمز ورود کاربران به پیام‌ها، تصاویر و رمزنگاری را تولید و کنترل کنید.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)})
        val state=TextView(this).apply{setTextColor(0xFFEAF7F4.toInt())}
        fun refresh(){state.text=if(prefs.getBoolean("secure_gate",true))"🔒 محافظت از رمزنگاری: فعال\nرمز دسترسی: ${if(prefs.contains("access_password"))"تنظیم شده" else "تنظیم نشده"}" else "🔓 محافظت از رمزنگاری: غیرفعال"}
        refresh()
        btn(box,"🔑 تولید رمز ورود کاربر به پیام/تصویر/رمزنگاری"){generateAccessPassword()}
        btn(box,"🔒 فعال کردن درخواست رمز برای بخش‌های حساس"){prefs.edit().putBoolean("secure_gate",true).apply();refresh();toast("از این پس ورود به بخش‌های حساس رمز می‌خواهد.")}
        btn(box,"🔓 غیرفعال کردن درخواست رمز"){prefs.edit().putBoolean("secure_gate",false).apply();refresh()}
        btn(box,"🎨 تغییر نام و لوگوی برنامه"){showBrandingSettings()}
        btn(box,"🔄 تغییر رمز مدیر"){changeAdminPassword()}
        btn(box,"🗑️ لغو رمز دسترسی کاربران"){prefs.edit().remove("access_password").apply();refresh();toast("رمز دسترسی قبلی لغو شد.")}
        box.addView(state,1); back(box); setContentView(box)
    }

    private fun showBrandingSettings(){
        val box=page("🎨 نام و لوگوی برنامه")
        box.addView(TextView(this).apply{
            text="از این بخش مدیر می‌تواند نام نمایشی برنامه و لوگوی داخل برنامه را تغییر دهد. تغییرات روی صفحه اصلی برنامه ذخیره می‌شود."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val name=EditText(this).apply{
            hint="نام جدید برنامه"
            setText(prefs.getString("app_display_name","Secure Studio"))
        }
        btn(box,"💾 ذخیره نام برنامه"){
            val n=name.text.toString().trim()
            if(n.length in 2..40){prefs.edit().putString("app_display_name",n).apply();toast("نام برنامه تغییر کرد.");showHome()}
            else toast("نام برنامه باید بین ۲ تا ۴۰ کاراکتر باشد.")
        }
        btn(box,"🖼️ انتخاب لوگو از گالری"){
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            },PICK_LOGO)
        }
        btn(box,"↩️ بازگردانی نام و لوگوی پیش‌فرض"){
            prefs.edit().remove("app_display_name").remove("app_logo_uri").apply();toast("نام و لوگوی پیش‌فرض بازگردانده شد.");showHome()
        }
        back(box);setContentView(box)
    }

    private fun generateAccessPassword(){
        val password=generateStrongPassword(16)
        prefs.edit().putString("access_password",hash(password)).apply()
        val view=TextView(this).apply{text="رمز جدید دسترسی:\n\n$password\n\nاین رمز را فقط به کاربر موردنظر بدهید. برای امنیت، پس از بستن این پنجره دوباره نمایش داده نمی‌شود.";textSize=17f;setTextColor(0xFFEAF7F4.toInt());setPadding(24,24,24,24);setTextIsSelectable(true)}
        android.app.AlertDialog.Builder(this).setTitle("🔑 رمز تولید شد").setView(view).setPositiveButton("متوجه شدم",null).show()
    }

    private fun generateStrongPassword(length:Int):String{
        val letters="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
        val symbols="!@#$%&*_-+=?"
        val r=SecureRandom(); val chars=CharArray(length)
        chars[0]=symbols[r.nextInt(symbols.length)]; chars[1]=symbols[r.nextInt(symbols.length)]
        for(i in 2 until length) chars[i]=letters[r.nextInt(letters.length)]
        for(i in chars.indices.reversed()){val j=r.nextInt(i+1);val t=chars[i];chars[i]=chars[j];chars[j]=t}
        return String(chars)
    }

    private fun validAdminPassword(p:String):Boolean{val symbols=p.count{!it.isLetterOrDigit()};return p.length in 8..22&&symbols>=2}
    private fun changeAdminPassword(){
        val input=EditText(this).apply{hint="رمز جدید مدیر (8 تا 22 کاراکتر، حداقل 2 نماد)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialogBuilder("🔄 تغییر رمز مدیر",input){val p=input.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).apply();toast("رمز مدیر تغییر کرد.")}else toast("رمز شرایط لازم را ندارد.")}.show()
    }

    private fun setPin(){val input=EditText(this).apply{hint="PIN حداقل 6 رقم";inputType=2};AlertDialogBuilder("تنظیم PIN",input){val p=input.text.toString();if(p.length>=6){prefs.edit().putString("pin",hash(p)).apply();toast("PIN ذخیره شد.")}else toast("PIN باید حداقل 6 رقم باشد.")}.show()}
    private fun verifyPin(){val input=EditText(this).apply{hint="PIN";inputType=2};AlertDialogBuilder("باز کردن قفل",input){if(hash(input.text.toString())==prefs.getString("pin",null))toast("قفل باز شد.")else toast("PIN نادرست است.")}.show()}

    private fun hash(s:String):String{val md=java.security.MessageDigest.getInstance("SHA-256");return Base64.getEncoder().encodeToString(md.digest(s.toByteArray(StandardCharsets.UTF_8)))}
    private fun encrypt(text:String):String{val key=getKey();val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key,GCMParameterSpec(128,nonce));return Base64.getEncoder().encodeToString(nonce+c.doFinal(text.toByteArray(StandardCharsets.UTF_8)))}
    private fun decrypt(encoded:String):String{val all=Base64.getDecoder().decode(encoded);require(all.size>12);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getKey(),GCMParameterSpec(128,all.copyOfRange(0,12)));return String(c.doFinal(all.copyOfRange(12,all.size)),StandardCharsets.UTF_8)}
    private fun getKey():SecretKey{val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)};if(ks.containsAlias("SecureStudioKey"))return(ks.getKey("SecureStudioKey",null) as SecretKey);val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(KeyGenParameterSpec.Builder("SecureStudioKey",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return kg.generateKey()}
    private fun showExtracted(text:String){AlertDialogBuilder("پیام استخراج‌شده",TextView(this).apply{this.text=text;setTextColor(0xFFEAF7F4.toInt());setPadding(20,20,20,20)}){}.show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun AlertDialogBuilder(title:String,view:android.view.View,onOk:()->Unit):android.app.AlertDialog=android.app.AlertDialog.Builder(this).setTitle(title).setView(view).setNegativeButton("انصراف",null).setPositiveButton("تأیید"){_,_->onOk()}.create()
}
