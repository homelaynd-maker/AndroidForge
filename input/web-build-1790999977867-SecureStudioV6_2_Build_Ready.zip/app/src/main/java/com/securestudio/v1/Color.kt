package com.securestudio.v1

/**
 * Local compatibility shim for older AndroidForge workspace copies that
 * reference Color without importing android.graphics.Color.
 * It delegates to the Android framework using fully-qualified names.
 */
object Color {
    const val BLACK: Int = 0xFF000000.toInt()
    const val WHITE: Int = 0xFFFFFFFF.toInt()
    const val TRANSPARENT: Int = 0x00000000

    fun argb(alpha: Int, red: Int, green: Int, blue: Int): Int =
        android.graphics.Color.argb(alpha, red, green, blue)

    fun rgb(red: Int, green: Int, blue: Int): Int =
        android.graphics.Color.rgb(red, green, blue)

    fun parseColor(colorString: String): Int =
        android.graphics.Color.parseColor(colorString)
}
