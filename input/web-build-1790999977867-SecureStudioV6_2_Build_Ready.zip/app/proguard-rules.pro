# Release hardening for the offline app. R8 obfuscates application classes in release builds.
# Android framework and AppCompat rules are supplied by their dependencies.
-keep class com.securestudio.v1.MainActivity { <init>(...); }
-keep class com.securestudio.v1.Color { *; }
