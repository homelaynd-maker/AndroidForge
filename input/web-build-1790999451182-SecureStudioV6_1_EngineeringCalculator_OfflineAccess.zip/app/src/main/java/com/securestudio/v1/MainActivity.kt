package com.securestudio.v1

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.media.MediaPlayer
import android.widget.VideoView
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("secure_studio", MODE_PRIVATE) }
    private val rooms = mutableListOf<String>()
    private var currentRoom = "عمومی"
    private val chatCache = mutableMapOf<String, MutableList<String>>()
    private val ADMIN_TRIGGER = "مدیر-ورود-2026"
    private val DEFAULT_GATE_ENABLED = true
    private var pendingImage: Bitmap? = null
    private var pendingMessage: String = ""
    private val PICK_IMAGE = 1001
    private val PICK_LOGO = 2001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rooms.addAll(prefs.getStringSet("rooms", setOf("عمومی"))!!.toList().sorted())
        if (rooms.isEmpty()) rooms.add("عمومی")
        currentRoom = rooms.first()
        if (!prefs.contains("secure_gate")) prefs.edit().putBoolean("secure_gate", DEFAULT_GATE_ENABLED).apply()
        if (!prefs.contains("admin_password")) {
            showFirstRunSetup()
        } else {
            // هر بار اجرای برنامه نیاز به احراز هویت دارد؛ رمز/کد روی دستگاه باقی می‌ماند اما جلسه قبلی خودکار باز نمی‌شود.
            prefs.edit().putBoolean("program_unlocked", false).remove("license_prefix").remove("temporary_session").remove("admin_session").apply()
            showProgramAccessGate()
        }
    }

    private fun showFirstRunSetup() {
        val box = page("🔐 راه‌اندازی اولیه برنامه")
        box.addView(TextView(this).apply {
            text = "در اولین اجرا، خودتان رمز مدیر را تعیین کنید. این برنامه هیچ رمز پیش‌فرضی ندارد و رمز مدیر در صفحه ورود نمایش داده نمی‌شود. رمز را در جای امن نگه دارید؛ سپس مدیر می‌تواند برای کاربران کد دائمی یا موقت صادر کند."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val input = EditText(this).apply {
            hint = "رمز مدیر: ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val question = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(
                "نام اولین مدرسه شما چه بود؟",
                "نام اولین شهر محل زندگی شما چه بود؟",
                "نام یک دوست دوران کودکی شما چه بود؟",
                "غذای مورد علاقه شما چیست؟"
            ))
        }
        val answer = EditText(this).apply { hint = "پاسخ سؤال امنیتی را وارد کنید" }
        val adminTrigger = EditText(this).apply { hint = "کد مخفی ورود مدیر از ماشین حساب (حداقل 8 کاراکتر)"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        box.addView(adminTrigger)
        btn(box, "💾 ثبت رمز مدیر و سؤال امنیتی") {
            val p = input.text.toString()
            val a = answer.text.toString().trim()
            if (!validAdminPassword(p)) {
                toast("رمز مدیر باید ۸ تا ۲۲ کاراکتر و دارای حداقل ۲ نماد باشد.")
            } else if (adminTrigger.text.toString().length < 8) {
                toast("کد ورود مدیر از ماشین حساب باید حداقل ۸ کاراکتر باشد.")
            } else if (a.length < 2) {
                toast("پاسخ سؤال امنیتی را وارد کنید.")
            } else {
                prefs.edit().putString("admin_password", hash(p))
                    .putInt("security_question", question.selectedItemPosition)
                    .putString("security_answer", hash(a))
                    .putString("admin_calculator_trigger_hash", hash(adminTrigger.text.toString()))
                    .putBoolean("program_unlocked", true).apply()
                showAdminPanel()
            }
        }
        box.addView(input, 1)
        box.addView(TextView(this).apply { text = "سؤال امنیتی بازیابی رمز"; setTextColor(0xFFEAF7F4.toInt()); setPadding(0,12,0,6) })
        box.addView(question)
        box.addView(answer)
        setContentView(box)
    }

    private fun showProgramAccessGate() {
        val box = page("🧮 ماشین حساب مهندسی")
        box.addView(TextView(this).apply {
            text = "ماشین حساب مهندسی کامل\nبرای ورود به بخش مجاز، کد دسترسی را با دکمه‌های ماشین حساب وارد کرده و = را بزنید."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,12)
        })
        val display = EditText(this).apply {
            hint = "0"
            textSize = 28f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            inputType = InputType.TYPE_CLASS_TEXT
            isSingleLine = true
            isFocusable = false
            setTextColor(0xFFEAF7F4.toInt())
            setHintTextColor(0xFF6F8E86.toInt())
            setBackgroundColor(0xFF16231F.toInt())
            setPadding(18, 14, 18, 14)
        }
        box.addView(display, LinearLayout.LayoutParams(-1, 72).apply { bottomMargin = 12 })

        val rows = listOf(
            listOf("Sin","Cos","Tan","Cot","Log","Ln"),
            listOf("(",")","√","%","⌫","C"),
            listOf("7","8","9","/","M+","MR"),
            listOf("4","5","6","*","M-","MC"),
            listOf("1","2","3","-",".","="),
            listOf("0","+","00","Ans","(",")")
        )
        var expression = ""
        var memory = 0.0
        var lastAnswer = "0"
        fun render() { display.setText(expression) }
        fun append(value: String) { expression += value; render() }
        fun clear() { expression = ""; render() }

        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { key ->
                val b = Button(this).apply {
                    text = key
                    isAllCaps = false
                    textSize = if (key == "=") 20f else 15f
                    setOnClickListener {
                        when (key) {
                            "C" -> clear()
                            "⌫" -> { if (expression.isNotEmpty()) expression = expression.dropLast(1); render() }
                            "=" -> {
                                val codePrefixes = listOf("Tan+*-%=", "Cot/*+%-=", "Cos-*%/+=")
                                val next = expression + "="
                                if (codePrefixes.any { it.startsWith(next) }) {
                                    expression = next
                                    render()
                                    return@setOnClickListener
                                }
                                val access = handleCalculatorAccess(expression)
                                if (access) return@setOnClickListener
                                try {
                                    val result = evaluateCalculatorExpression(expression, memory, lastAnswer)
                                    lastAnswer = result.toString()
                                    expression = result.toString()
                                    render()
                                } catch (_: Exception) { toast("عبارت یا کد نامعتبر است.") }
                            }
                            "M+" -> { memory += evaluateCalculatorExpression(expression, memory, lastAnswer); toast("حافظه اضافه شد.") }
                            "M-" -> { memory -= evaluateCalculatorExpression(expression, memory, lastAnswer); toast("حافظه کم شد.") }
                            "MR" -> append(trimNumber(memory))
                            "MC" -> { memory = 0.0; toast("حافظه پاک شد.") }
                            "Ans" -> append(lastAnswer)
                            "Sin","Cos","Tan","Cot","Log","Ln","√" -> append(key + "(")
                            else -> append(key)
                        }
                    }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 54, 1f).apply { setMargins(3,3,3,3) })
            }
            box.addView(line)
        }
        box.addView(TextView(this).apply {
            text = "ورود سطحی: s / m / a و کدهای دائمی یا موقت همین نسخه قابل استفاده‌اند."
            setTextColor(0xFF6F8E86.toInt()); setPadding(0,10,0,8)
        })
        btn(box, "🔒 خروج / قفل") { prefs.edit().putBoolean("program_unlocked", false).remove("license_prefix").remove("temporary_session").remove("admin_session").apply(); showProgramAccessGate() }
        setContentView(box)
    }

    /** Returns true when the expression was an access code and navigation was handled. */
    private fun handleCalculatorAccess(raw: String): Boolean {
        val code = raw.trim()
        if (code.isEmpty()) { toast("عبارت خالی است."); return true }

        // The three level codes supplied for this offline build.
        val fixedLevel = when (code) {
            "Tan+*-%=57" -> "a"
            "Cot/*+%-=22" -> "m"
            "Cos-*%/+=01" -> "s"
            else -> null
        }
        if (fixedLevel != null) {
            openLevelAfterCode(fixedLevel, false)
            return true
        }

        // Built-in permanent/temporary codes and portable offline licenses.
        val result = validateLicense(code)
        if (result != null) {
            if (result.second) {
                consumeTemporaryLicense(code)
            }
            openLevelAfterCode(result.first, result.second)
            return true
        }

        // The manager code is deliberately not embedded as plaintext. It is established during first setup.
        val adminTriggerHash = prefs.getString("admin_calculator_trigger_hash", null)
        if (adminTriggerHash != null && hash(code) == adminTriggerHash) {
            showAdminLogin()
            return true
        }
        return false
    }

    private fun openLevelAfterCode(prefix: String, temporary: Boolean) {
        prefs.edit()
            .putBoolean("program_unlocked", true)
            .putBoolean("admin_session", false)
            .putString("license_prefix", prefix)
            .putBoolean("temporary_session", temporary)
            .apply()

        if (!prefs.getBoolean("user_password_initialized_$prefix", false)) {
            showRequiredUserPasswordSetup(prefix, temporary)
        } else {
            showUserPasswordLogin(prefix, temporary)
        }
    }

    private fun showRequiredUserPasswordSetup(prefix: String, temporary: Boolean) {
        val box = page("🔐 تعیین رمز شخصی")
        box.addView(TextView(this).apply {
            text = "کد سطح $prefix پذیرفته شد. برای استفاده از برنامه، اکنون یک رمز شخصی تعیین کنید. این مرحله فقط یک بار برای این سطح روی این دستگاه انجام می‌شود."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val p1 = EditText(this).apply { hint = "رمز شخصی"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val p2 = EditText(this).apply { hint = "تکرار رمز شخصی"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        box.addView(p1); box.addView(p2)
        btn(box, "ثبت رمز و ورود") {
            val a = p1.text.toString(); val b = p2.text.toString()
            if (!validUserPassword(a)) toast("رمز باید ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد داشته باشد.")
            else if (a != b) toast("دو رمز یکسان نیستند.")
            else {
                prefs.edit().putString("user_password_$prefix", hash(a)).putBoolean("user_password_initialized_$prefix", true).apply()
                showHome()
            }
        }
        setContentView(box)
    }

    private fun showUserPasswordLogin(prefix: String, temporary: Boolean) {
        val input = EditText(this).apply { hint = "رمز شخصی سطح $prefix"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        android.app.AlertDialog.Builder(this)
            .setTitle("🔐 ورود سطح $prefix")
            .setView(input)
            .setNegativeButton("لغو") { _, _ -> showProgramAccessGate() }
            .setPositiveButton("ورود") { _, _ ->
                if (hash(input.text.toString()) == prefs.getString("user_password_$prefix", null)) showHome()
                else toast("رمز شخصی نادرست است.")
            }.show()
    }

    private fun validUserPassword(value: String): Boolean {
        if (value.length !in 8..22) return false
        val symbols = value.count { !it.isLetterOrDigit() }
        return symbols >= 2
    }

    private fun trimNumber(value: Double): String =
        if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()

    private fun evaluateCalculatorExpression(input: String, memory: Double, ans: String): Double {
        var s = input.replace("×", "*").replace("÷", "/").replace("√", "sqrt")
            .replace("Ans", ans).replace(" ", "")
        if (s.isBlank()) throw IllegalArgumentException()
        class Parser(private val text: String) {
            var pos = 0
            fun parse(): Double { val v = expression(); skip(); if (pos != text.length) throw IllegalArgumentException(); return v }
            private fun skip(){ while(pos<text.length && text[pos].isWhitespace()) pos++ }
            private fun eat(c: Char): Boolean { skip(); if(pos<text.length && text[pos]==c){pos++;return true};return false }
            private fun expression(): Double { var v=term(); while(true){ when { eat('+')->v+=term(); eat('-')->v-=term(); else->return v } } }
            private fun term(): Double { var v=factor(); while(true){ when { eat('*')->v*=factor(); eat('/')->v/=factor(); eat('%')->v%=factor(); else->return v } } }
            private fun factor(): Double {
                skip(); if(eat('+')) return factor(); if(eat('-')) return -factor()
                val functions=listOf("sin","cos","tan","cot","log","ln","sqrt")
                for(fn in functions){ if(text.regionMatches(pos,fn,0,fn.length,true)){pos+=fn.length; if(!eat('(')) throw IllegalArgumentException(); val x=expression(); if(!eat(')')) throw IllegalArgumentException(); return when(fn.lowercase()){"sin"->kotlin.math.sin(Math.toRadians(x));"cos"->kotlin.math.cos(Math.toRadians(x));"tan"->kotlin.math.tan(Math.toRadians(x));"cot"->1.0/kotlin.math.tan(Math.toRadians(x));"log"->kotlin.math.log10(x);"ln"->kotlin.math.ln(x);else->kotlin.math.sqrt(x)} } }
                skip(); if(eat('(')){val v=expression();if(!eat(')'))throw IllegalArgumentException();return v}
                val st=pos; while(pos<text.length && (text[pos].isDigit()||text[pos]=='.'))pos++
                if(st==pos)throw IllegalArgumentException(); return text.substring(st,pos).toDouble()
            }
        }
        return Parser(s).parse()
    }

    private fun page(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(0xFF0B1412.toInt())
        layoutParams = ViewGroup.LayoutParams(-1, -1)
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 25f; setTextColor(0xFFEAF7F4.toInt()); setPadding(0, 8, 0, 18)
        })
    }

    private fun btn(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            isEnabled = true
            alpha = 1.0f
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun back(parent: LinearLayout) = btn(parent, "← بازگشت") { showHome() }

    private fun showHome() {
        val root = page("")
        val branding = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, 4, 0, 10)
        }
        val logo = ImageView(this).apply {
            val uri = prefs.getString("app_logo_uri", null)
            if (!uri.isNullOrBlank()) {
                try { setImageURI(Uri.parse(uri)) } catch (_: Exception) { setImageResource(android.R.drawable.ic_lock_lock) }
            } else setImageResource(android.R.drawable.ic_lock_lock)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        branding.addView(logo, LinearLayout.LayoutParams(64,64).apply { marginEnd = 12 })
        branding.addView(TextView(this).apply {
            text = prefs.getString("app_display_name", "Secure Studio")
            textSize = 28f; setTextColor(0xFFEAF7F4.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(branding, 1)
        root.addView(TextView(this).apply {
            text = if (prefs.getBoolean("admin_session", false)) "سطح دسترسی: مدیر (کامل)" else "سطح دسترسی: ${prefs.getString("license_prefix", "")}"
            textSize = 14f; setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,18)
        }, 2)

        val prefix = if (prefs.getBoolean("admin_session", false)) "a" else (prefs.getString("license_prefix", "") ?: "")
        fun allowed(area:String) = when(prefix) {
            "s" -> area == "crypto" || area == "binary"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary"
            "a" -> true
            else -> false
        }
        if (allowed("crypto")) btn(root, "🔐 رمزنگاری / رمزگشایی متن") { showCrypto() }
        if (allowed("chat")) btn(root, "💬 اتاق‌های پیام خصوصی") { showChat() }
        if (allowed("image")) btn(root, "🖼️ پیام رمزگذاری‌شده داخل تصویر") { showStego() }
        if (allowed("binary")) btn(root, "💻 متن ↔ Binary") { showBinary() }
        btn(root, "🛡️ قفل برنامه و امنیت") { showSecurity() }
        if (prefix == "a") {
            btn(root, "🧩 کارگاه ابزار و برنامه‌نویسی آفلاین") { showOfflineToolLab() }
            btn(root, "📸 ویرایشگر تصویر") { showImageEditor() }
            btn(root, "🎬 ویرایشگر ویدیو") { showVideoEditor() }
            btn(root, "🎵 ویرایشگر صوت") { showAudioEditor() }
            btn(root, "🌐 مترجم آفلاین") { showTranslator() }
            btn(root, "🎙️ ابزار صوت و گفتار") { showVoiceTools() }
        }
        btn(root, "🚪 خروج از حساب") { prefs.edit().putBoolean("program_unlocked", false).remove("license_prefix").remove("temporary_session").remove("admin_session").apply(); showProgramAccessGate() }
        setContentView(root)
    }

    private fun requireSecure(area: String, onSuccess: () -> Unit) {
        val prefix = if (prefs.getBoolean("admin_session", false)) "a" else (prefs.getString("license_prefix", "") ?: "")
        val allowed = when (prefix) {
            "s" -> area == "crypto" || area == "binary"
            "m" -> area == "crypto" || area == "chat" || area == "image" || area == "binary"
            "a" -> true
            else -> false
        }
        if (allowed) { onSuccess(); return }
        showProgramAccessGate()
    }

    private fun areaTitle(area: String) = when(area) {
        "crypto" -> "رمزنگاری پیام"
        "chat" -> "پیام‌های خصوصی"
        "image" -> "پیام مخفی در تصویر"
        "binary" -> "رمزنگاری و Binary"
        else -> "بخش محافظت‌شده"
    }

    private fun showCrypto() {
        val box = page("🔐 رمزنگاری متن")
        val input = EditText(this).apply { hint = "متن یا متن رمزگذاری‌شده"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"🔐 رمزنگاری") { val value = input.text.toString(); if(value.isBlank()) toast("متن را وارد کنید.") else output.setText(encrypt(value)) }
        btn(box,"🔓 رمزگشایی") { try { output.setText(decrypt(input.text.toString().trim())) } catch (_: Exception) { output.setText("رمزگشایی ناموفق؛ متن رمزنگاری‌شده معتبر نیست.") } }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input, 1); box.addView(output, 6); back(box); setContentView(box)
    }

    private fun showBinary() {
        val box = page("💻 متن و Binary")
        val input = EditText(this).apply { hint = "متن یا Binary با فاصله"; minLines = 5; gravity = 48 }
        val output = EditText(this).apply { hint = "خروجی"; minLines = 7; gravity = 48 }
        btn(box,"متن → Binary") { output.setText(input.text.toString().toByteArray(StandardCharsets.UTF_8).joinToString(" ") { String.format("%8s", Integer.toBinaryString(it.toInt() and 255)).replace(' ','0') }) }
        btn(box,"Binary → متن") { try { output.setText(String(input.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.map { it.toInt(2).toByte() }.toByteArray(), StandardCharsets.UTF_8)) } catch (_: Exception) { output.setText("Binary معتبر نیست.") } }
        btn(box,"📋 کپی کل متن ورودی") { copyText(input.text.toString()); toast("متن ورودی کپی شد.") }
        btn(box,"📋 کپی کل خروجی") { copyText(output.text.toString()); toast("کل خروجی کپی شد.") }
        box.addView(input,1); box.addView(output,6); back(box); setContentView(box)
    }

    private fun showChat() {
        val box = page("💬 اتاق‌های پیام خصوصی")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, rooms)
        spinner.setSelection(rooms.indexOf(currentRoom).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) { currentRoom = rooms[pos]; refreshChat() }
        }
        box.addView(TextView(this).apply { text="اتاق فعلی"; setTextColor(0xFFEAF7F4.toInt()) })
        box.addView(spinner)
        val messages = TextView(this).apply { minHeight=260; setTextColor(0xFFEAF7F4.toInt()); setPadding(8,16,8,16) }
        val input = EditText(this).apply { hint="پیام" }
        val send = Button(this).apply { text="ارسال رمزگذاری‌شده"; isAllCaps=false }
        send.setOnClickListener {
            val msg=input.text.toString(); if(msg.isNotBlank()) { val list=chatCache.getOrPut(currentRoom){mutableListOf()}; list.add("شما: "+encrypt(msg)); input.text.clear(); refreshChat(messages) }
        }
        btn(box,"➕ ساخت اتاق جدید") { createRoomAndRefresh() }
        box.addView(messages); box.addView(input); box.addView(send); back(box)
        refreshChat(messages); setContentView(box)
    }

    private fun refreshChat(target: TextView? = null) {
        val t = target ?: return
        val list=chatCache.getOrPut(currentRoom){mutableListOf()}
        t.text = if(list.isEmpty()) "این اتاق هنوز پیامی ندارد." else list.joinToString("\n\n")
    }

    private fun createRoomAndRefresh() {
        val input=EditText(this).apply { hint="نام اتاق" }
        AlertDialogBuilder("ساخت اتاق", input) { val n=input.text.toString().trim(); if(n.isNotEmpty()&&!rooms.contains(n)){rooms.add(n);prefs.edit().putStringSet("rooms",rooms.toSet()).apply();currentRoom=n;showChat()} }.show()
    }

    private fun showStego() {
        val box=page("🖼️ پیام رمزگذاری‌شده داخل تصویر")
        val message=EditText(this).apply{hint="پیامی که باید داخل تصویر قرار بگیرد";minLines=4;gravity=48}
        val info=TextView(this).apply{text="برای حفظ کیفیت، خروجی به PNG ذخیره می‌شود. تصویر اصلی تغییر محتوایی قابل مشاهده ندارد.";setTextColor(0xFF9FCBC1.toInt())}
        btn(box,"📂 انتخاب تصویر و جاسازی پیام"){pendingMessage=message.text.toString(); if(pendingMessage.isBlank()){toast("ابتدا پیام را وارد کنید.")}else{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE)}}
        btn(box,"📂 انتخاب تصویر و استخراج پیام"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/png";addCategory(Intent.CATEGORY_OPENABLE)},PICK_IMAGE+1)}
        box.addView(message,1);box.addView(info,2);back(box);setContentView(box)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;val uri=data.data!!
        if(requestCode==PICK_LOGO){
            try{
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }catch(_:Exception){}
            prefs.edit().putString("app_logo_uri",uri.toString()).apply()
            toast("لوگوی برنامه ذخیره شد.")
            showHome()
        } else if(requestCode==PICK_MEDIA_IMAGE){
            val bmp=loadBitmap(uri); if(bmp==null){toast("تصویر قابل خواندن نیست.");return}; selectedImageBitmap=bmp; showImageEditor()
        } else if(requestCode==PICK_MEDIA_VIDEO){
            // VideoView is created by the screen; reopen screen and store URI for future expansion.
            selectedMediaUri=uri; showVideoEditor(); toast("ویدیو انتخاب شد؛ برای پخش مستقیم دوباره انتخاب لازم است.")
        } else if(requestCode==PICK_MEDIA_AUDIO){
            try{audioPlayer?.release();audioPlayer=MediaPlayer.create(this,uri);showAudioEditor();toast("فایل صوتی آماده پخش است.")}catch(_:Exception){toast("فایل صوتی قابل پخش نیست.")}
        } else if(requestCode==PICK_IMAGE){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{saveBitmap(embedMessage(bmp,pendingMessage))}catch(e:Exception){toast("خطا: ظرفیت تصویر کافی نیست یا فرمت مناسب نیست.")}}
        else if(requestCode==PICK_IMAGE+1){val bmp=loadBitmap(uri);if(bmp==null){toast("تصویر قابل خواندن نیست.");return};try{showExtracted(decrypt(extractMessage(bmp)))}catch(e:Exception){toast("پیام رمزگذاری‌شده معتبری در تصویر پیدا نشد.")}}
    }

    private fun embedMessage(src: Bitmap, text: String): Bitmap {
        val data = encrypt(text).toByteArray(StandardCharsets.UTF_8)
        val payload = ByteBuffer.allocate(4 + data.size).putInt(data.size).put(data).array()
        val capacity = src.width * src.height * 3
        require(payload.size * 8 <= capacity)

        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        var bit = 0
        for (y in 0 until out.height) {
            for (x in 0 until out.width) {
                val pixel = out.getPixel(x, y)
                val channels = intArrayOf(
                    (pixel shr 16).and(255),
                    (pixel shr 8).and(255),
                    pixel.and(255)
                )
                for (channel in 0..2) {
                    if (bit < payload.size * 8) {
                        val byteValue = payload[bit / 8].toInt().and(255)
                        val bitValue = (byteValue shr (7 - (bit % 8))).and(1)
                        channels[channel] = channels[channel].and(254).or(bitValue)
                        bit++
                    }
                }
                out.setPixel(x, y, (0xFF000000.toInt() or (channels[0] shl 16) or (channels[1] shl 8) or channels[2]))
                if (bit >= payload.size * 8) return out
            }
        }
        return out
    }

    private fun extractMessage(bmp: Bitmap): String {
        val bits = ArrayList<Int>()
        for (y in 0 until bmp.height) {
            for (x in 0 until bmp.width) {
                val pixel = bmp.getPixel(x, y)
                bits.add((pixel shr 16).and(1))
                bits.add((pixel shr 8).and(1))
                bits.add(pixel.and(1))
            }
        }

        fun readInt(start: Int): Int {
            var value = 0
            for (i in 0 until 32) {
                value = value.shl(1).or(bits[start + i])
            }
            return value
        }

        require(bits.size >= 32)
        val length = readInt(0)
        require(length > 0 && length < 10_000_000 && 32 + length * 8 <= bits.size)

        val out = ByteArray(length)
        for (i in 0 until length) {
            var value = 0
            for (j in 0 until 8) {
                value = value.shl(1).or(bits[32 + i * 8 + j])
            }
            out[i] = value.toByte()
        }
        return String(out, StandardCharsets.UTF_8)
    }
    private fun saveBitmap(bmp:Bitmap){val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,"SecureStudio_${System.currentTimeMillis()}.png");put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/SecureStudio")};val uri=contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)?:throw Exception();contentResolver.openOutputStream(uri)!!.use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)};toast("تصویر در Pictures/SecureStudio ذخیره شد.")}
    private fun loadBitmap(uri:Uri):Bitmap?=contentResolver.openInputStream(uri).use{BitmapFactory.decodeStream(it)}

    private fun showSecurity(){
        val box=page("🛡️ امنیت برنامه")
        val status=TextView(this).apply{setTextColor(0xFFEAF7F4.toInt())}
        status.text=if(prefs.contains("pin"))"قفل PIN فعال است." else "قفل PIN هنوز تنظیم نشده است."
        btn(box,"🔑 تنظیم / تغییر PIN"){setPin()}
        btn(box,"🗑️ حذف PIN"){prefs.edit().remove("pin").apply();status.text="قفل PIN غیرفعال شد."}
        btn(box,"🔒 آزمایش قفل"){if(prefs.contains("pin"))verifyPin()else toast("ابتدا PIN تنظیم کنید.")}
        if (!prefs.contains("admin_calculator_trigger_hash")) {
            btn(box,"⚙️ تکمیل راه‌اندازی مدیر"){showAdminLogin()}
        }
        box.addView(status,1); back(box); setContentView(box)
    }

    private fun showAdminLogin(){
        if(!prefs.contains("admin_password")){
            val first=EditText(this).apply{hint="رمز مدیر، حداقل 8 و حداکثر 22 کاراکتر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            AlertDialogBuilder("👑 ایجاد رمز اولیه مدیر",first){val p=first.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).putBoolean("admin_session", true).putBoolean("program_unlocked", true).apply();toast("رمز مدیر ثبت شد. آن را در جای امن نگه دارید.");showAdminPanel()}else toast("رمز باید 8 تا 22 کاراکتر و دارای حداقل 2 نماد باشد.")}.show()
            return
        }
        val input=EditText(this).apply{hint="رمز ورود پنل مدیر";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        android.app.AlertDialog.Builder(this).setTitle("🔐 ورود مدیر").setView(input)
            .setNegativeButton("فراموشی رمز"){_,_->showAdminRecovery()}
            .setPositiveButton("ورود"){_,_->if(hash(input.text.toString())==prefs.getString("admin_password",null)){prefs.edit().putBoolean("admin_session",true).putBoolean("program_unlocked",true).remove("license_prefix").apply();showAdminPanel()}else toast("رمز مدیر نادرست است.")}
            .show()
    }

    private fun showAdminRecovery(){
        val qIndex = prefs.getInt("security_question", 0)
        val questions = listOf(
            "نام اولین مدرسه شما چه بود؟",
            "نام اولین شهر محل زندگی شما چه بود؟",
            "نام یک دوست دوران کودکی شما چه بود؟",
            "غذای مورد علاقه شما چیست?"
        )
        val box=page("🛡️ بازیابی رمز مدیر")
        box.addView(TextView(this).apply{
            text = "سؤال امنیتی ثبت‌شده:\n${questions.getOrElse(qIndex){questions[0]}}"
            setTextColor(0xFFEAF7F4.toInt()); setPadding(0,0,0,16)
        })
        val answer=EditText(this).apply{hint="پاسخ سؤال امنیتی"}
        val newPass=EditText(this).apply{hint="رمز جدید مدیر: ۸ تا ۲۲ کاراکتر و حداقل ۲ نماد"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        // تنظیم نوع ورودی جداگانه برای جلوگیری از نمایش رمز در صفحه
        newPass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        btn(box,"🔓 بازیابی و تعیین رمز جدید"){
            val a=answer.text.toString().trim(); val p=newPass.text.toString()
            if(hash(a)==prefs.getString("security_answer",null) && validAdminPassword(p)){
                prefs.edit().putString("admin_password",hash(p)).apply()
                toast("رمز مدیر با موفقیت تغییر کرد."); showAdminLogin()
            } else if(hash(a)!=prefs.getString("security_answer",null)) toast("پاسخ سؤال امنیتی نادرست است.")
            else toast("رمز جدید باید ۸ تا ۲۲ کاراکتر و دارای حداقل ۲ نماد باشد.")
        }
        box.addView(answer); box.addView(newPass); back(box); setContentView(box)
    }

    private fun changeAdminCalculatorTrigger(){
        val input=EditText(this).apply{hint="کد جدید ورود مدیر از ماشین حساب";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        android.app.AlertDialog.Builder(this).setTitle("🧮 تغییر کد ورود مدیر").setView(input)
            .setNegativeButton("لغو",null)
            .setPositiveButton("ذخیره"){_,_->
                val v=input.text.toString()
                if(v.length>=8){prefs.edit().putString("admin_calculator_trigger_hash",hash(v)).apply();toast("کد ورود مدیر تغییر کرد.")}
                else toast("کد باید حداقل ۸ کاراکتر باشد.")
            }.show()
    }

    private fun showAdminPanel(){
        val box=page("👑 پنل مدیریت ویژه")
        box.addView(TextView(this).apply{text="مدیر از اینجا می‌تواند کدهای دسترسی دائمی یا یک‌بارمصرف برای کاربران صادر کند. پیشوند کد سطح دسترسی را مشخص می‌کند: s، m یا a.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)})
        btn(box,"🔑 صدور کد جدید برای کاربر"){showLicenseGenerator()}
        btn(box,"📋 مدیریت کدهای صادرشده"){showLicenseList()}
        btn(box,"🎨 تغییر نام و لوگوی برنامه"){showBrandingSettings()}
        btn(box,"🔄 تغییر رمز مدیر"){changeAdminPassword()}
        btn(box,"🧮 تغییر کد ورود مخفی مدیر"){changeAdminCalculatorTrigger()}
        btn(box,"🛡️ تغییر سؤال امنیتی"){changeSecurityQuestion()}
        btn(box,"🔓 خروج از برنامه و بازگشت به صفحه ورود"){prefs.edit().putBoolean("program_unlocked",false).remove("license_prefix").apply();showProgramAccessGate()}
        btn(box,"🛡️ پاک‌سازی همه کدهای کاربران"){prefs.edit().remove("licenses").apply();toast("همه کدهای صادرشده لغو شدند.")}
        back(box); setContentView(box)
    }

    private fun showLicenseGenerator(){
        val box=page("🔑 صدور رمز کاربر")
        box.addView(TextView(this).apply{
            text="""این نسخه کاملاً آفلاین است. برای ۲۰۰۰ کاربر، ۴۰۰۰ رمز داخلی وجود دارد: برای هر کاربر یک رمز دائمی و یک رمز موقت. رمزها در خود نسخه برنامه قرار دارند و روی دستگاه‌های دیگر همین نسخه قابل اعتبارسنجی‌اند.

سطح‌ها به‌صورت متوازن بین s، m و a توزیع شده‌اند. رمز موقت روی هر دستگاه فقط یک‌بار مصرف می‌شود؛ مصرف سراسری بین چند دستگاه بدون همگام‌سازی ممکن نیست."""
            setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)
        })
        val type=Spinner(this)
        type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(
            "دائمی — ۲۰۰۰ رمز",
            "موقت/یک‌بارمصرف — ۲۰۰۰ رمز"
        ))
        box.addView(TextView(this).apply{text="نوع رمز";setTextColor(0xFFEAF7F4.toInt())})
        box.addView(type)
        val level=Spinner(this)
        level.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(
            "s — پیام + Binary",
            "m — پیام + چت + تصویر + Binary",
            "a — دسترسی کامل"
        ))
        box.addView(TextView(this).apply{text="سطح دسترسی";setTextColor(0xFFEAF7F4.toInt())})
        box.addView(level)
        btn(box,"🔑 صدور رمز"){
            val prefix=when(level.selectedItemPosition){0->"s";1->"m";else->"a"}
            val temporary=type.selectedItemPosition==1
            val code=generateBuiltinLicense(prefix,temporary)
            if(code==null){toast("ظرفیت رمزهای این سطح و نوع تمام شده است.");return@btn}
            addLicenseRecord(code,prefix,temporary)
            val label=if(temporary) "موقت / یک‌بارمصرف روی هر دستگاه" else "دائمی"
            val view=TextView(this).apply{
                text="""رمز صادرشده:

$code

نوع: $label
سطح: $prefix

این رمز برای همین نسخه برنامه به‌صورت آفلاین قابل اعتبارسنجی است."""
                textSize=17f;setTextColor(0xFFEAF7F4.toInt());setPadding(24,24,24,24);setTextIsSelectable(true)
            }
            android.app.AlertDialog.Builder(this).setTitle("رمز آماده شد").setView(view)
                .setPositiveButton("کپی رمز"){_,_->copyText(code);toast("رمز کپی شد.")}.setNegativeButton("بستن",null).show()
        }
        btn(box,"🧩 کارگاه ابزار و برنامه‌نویسی آفلاین"){showOfflineToolLab()}
        back(box);setContentView(box)
    }


    // کدهای جدید قابل انتقال بین دستگاه‌ها هستند. برای کارکرد آفلاین، اعتبار کد با HMAC داخلی برنامه بررسی می‌شود.
    // توجه: «یک‌بار مصرف سراسری بین همه دستگاه‌ها» بدون سرور/همگام‌سازی قابل تضمین نیست؛ کد موقت در هر دستگاه یک‌بار مصرف می‌شود.
    private val BUILTIN_LICENSES: Map<String, List<String>> = LicenseCatalog.BUILTIN_LICENSES

    private val LICENSE_SECRET = "SS7-LICENSE-2026-v1-7f3c9a2d4e6b8c1a5f0e9d3b7a6c2e4f"

    private fun generatePortableLicense(prefix:String, temporary:Boolean):String{
        val nonce=ByteArray(10).also{SecureRandom().nextBytes(it)}
        val id=Base64.getUrlEncoder().withoutPadding().encodeToString(nonce)
        val type=if(temporary) "T" else "P"
        val data="SS1|$prefix|$type|$id"
        val sig=hmac(data).take(16)
        return "SS1-$prefix-$type-$id-$sig"
    }

    private fun hmac(data:String):String{
        val mac=Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(LICENSE_SECRET.toByteArray(StandardCharsets.UTF_8),"HmacSHA256"))
        return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.toByteArray(StandardCharsets.UTF_8)))
    }

    private fun generateBuiltinLicense(prefix:String, temporary:Boolean):String?{
        val all=BUILTIN_LICENSES[prefix] ?: return null
        val issued=JSONArray(prefs.getString("licenses","[]"))
        val used=HashSet<String>()
        for(i in 0 until issued.length()) used.add(issued.getJSONObject(i).optString("code"))
        all.firstOrNull{!used.contains(it) && ((it.contains("-T-") == temporary))}?.let{return it}
        return null
    }

    private fun addLicenseRecord(code:String,prefix:String,temporary:Boolean){
        val arr=JSONArray(prefs.getString("licenses","[]"))
        arr.put(JSONObject().put("code",code).put("prefix",prefix).put("temporary",temporary).put("used",false))
        prefs.edit().putString("licenses",arr.toString()).apply()
    }

    private fun validatePortableLicense(code:String):Pair<String,Boolean>?{
        val parts=code.trim().split('-')
        if(parts.size!=5 || parts[0]!="SS1") return null
        val prefix=parts[1]
        val type=parts[2]
        val id=parts[3]
        val sig=parts[4]
        if(prefix !in listOf("s","m","a") || type !in listOf("P","T") || id.isBlank() || sig.isBlank()) return null
        val data="SS1|$prefix|$type|$id"
        if(!constantTimeEquals(hmac(data).take(16),sig)) return null
        return Pair(prefix,type=="T")
    }

    private fun constantTimeEquals(a:String,b:String):Boolean{
        val aa=a.toByteArray(StandardCharsets.UTF_8); val bb=b.toByteArray(StandardCharsets.UTF_8)
        if(aa.size!=bb.size) return false
        var diff=0
        for(i in aa.indices) diff = diff or (aa[i].toInt() xor bb[i].toInt())
        return diff==0
    }

    private fun temporaryLicenseId(code:String):String?{
        val parts=code.trim().split('-')
        return if(parts.size==5 && parts[0]=="SS1" && parts[2]=="T") parts[3] else null
    }

    private fun isTemporaryUsedOnThisDevice(id:String):Boolean =
        prefs.getStringSet("temporary_used_ids", emptySet())?.contains(id) == true

    private fun consumeTemporaryLicense(code:String){
        val id=temporaryLicenseId(code) ?: return
        val set=(prefs.getStringSet("temporary_used_ids", emptySet()) ?: emptySet()).toMutableSet()
        set.add(id)
        prefs.edit().putStringSet("temporary_used_ids",set).apply()
    }

    private fun validateLicense(code:String):Pair<String,Boolean>?{
        val clean=code.trim()
        for((prefix,list) in BUILTIN_LICENSES){
            if(list.contains(clean)) return Pair(prefix,false)
        }
        val portable=validatePortableLicense(clean)
        if(portable!=null){
            if(portable.second){
                val id=temporaryLicenseId(code) ?: return null
                if(isTemporaryUsedOnThisDevice(id)) return null
            }
            return portable
        }
        // سازگاری با کدهای قدیمی فقط روی همان گوشی؛ کدهای جدید همیشه قابل انتقال‌اند.
        if(code.length<2) return null
        val arr=JSONArray(prefs.getString("licenses","[]")); val h=hash(code)
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i)
            if(o.optString("hash")==h){
                if(o.optBoolean("temporary") && o.optBoolean("used")) return null
                return Pair(o.optString("prefix"),o.optBoolean("temporary"))
            }
        }
        return null
    }

    private fun showLicenseList(){
        val arr=JSONArray(prefs.getString("licenses","[]"));val text=StringBuilder()
        if (arr.length() == 0) {
            text.append("هنوز هیچ کدی صادر نشده است.")
        } else {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val typeLabel = if (o.optBoolean("temporary")) "موقت" else "دائمی"
                val statusLabel = if (o.optBoolean("used")) " — مصرف شده" else " — فعال"
                text.append(i + 1).append(". سطح ").append(o.optString("prefix"))
                    .append(" — ").append(typeLabel).append(statusLabel).append("\n")
            }
        }
        android.app.AlertDialog.Builder(this).setTitle("📋 کدهای صادرشده").setMessage(text.toString()).setPositiveButton("بستن",null).show()
    }

    private fun showOfflineToolLab(){
        val box=page("🧩 کارگاه ابزار و برنامه‌نویسی آفلاین")
        box.addView(TextView(this).apply{
            text="ابزار داخلی برای ساخت، بررسی، ذخیره و انتقال ابزارهای سفارشی. فهرست زبان‌ها گسترده است؛ آزمون ساختاری برای همه زبان‌ها انجام می‌شود و اجرای واقعی آفلاین برای HTML/JavaScript/SQL/JSON/XML فراهم شده است. برای زبان‌هایی که موتور اجرایی داخل APK ندارند، برنامه کد را تست ساختاری می‌کند و آن را به‌عنوان ابزار قابل انتقال ذخیره می‌کند."
            setTextColor(0xFF9FCBC1.toInt());setPadding(0,0,0,16)
        })
        val name=EditText(this).apply{hint="نام ابزار"}
        val language=Spinner(this)
        val languages=listOf("Kotlin","Java","JavaScript","TypeScript","Python","C","C++","C#","Go","Rust","Swift","Dart","PHP","Ruby","Lua","Bash","SQL","HTML","CSS","XML","JSON","Markdown","PowerShell","R","MATLAB","Scala","Groovy","Objective-C","Assembly","YAML","Perl","Haskell","Julia","Visual Basic")
        language.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,languages)
        val code=EditText(this).apply{hint="کد ابزار را اینجا بنویسید";minLines=12;gravity=48;setTextIsSelectable(true)}
        box.addView(name);box.addView(language);box.addView(code)
        btn(box,"🧪 تست آفلاین"){
            val result=testCode(language.selectedItem.toString(),code.text.toString())
            android.app.AlertDialog.Builder(this).setTitle("نتیجه تست").setMessage(result).setPositiveButton("باشه",null).show()
        }
        btn(box,"▶️ اجرا"){
            runCodeOffline(language.selectedItem.toString(),code.text.toString())
        }
        btn(box,"➕ افزودن ابزار به برنامه"){
            val n=name.text.toString().trim();val c=code.text.toString();val l=language.selectedItem.toString()
            if(n.isBlank()||c.isBlank()){toast("نام و کد ابزار را وارد کنید.");return@btn}
            val result=testCode(l,c)
            if(!result.startsWith("✅")){toast("ابتدا خطاهای تست را برطرف کنید.");return@btn}
            saveCustomTool(n,l,c);toast("ابزار به برنامه اضافه شد و آفلاین قابل استفاده است.");showHome()
        }
        btn(box,"📤 خروجی/انتقال ابزار به گوشی دیگر"){
            val n=name.text.toString().trim();val c=code.text.toString();val l=language.selectedItem.toString()
            if(n.isBlank()||c.isBlank()){toast("نام و کد ابزار را وارد کنید.");return@btn}
            val pkg=exportToolPackage(n,l,c)
            copyText(pkg)
            val share=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,pkg)}
            startActivity(Intent.createChooser(share,"انتقال آفلاین ابزار"))
        }
        btn(box,"📥 وارد کردن ابزار از گوشی دیگر"){
            val input=EditText(this).apply{hint="متن بسته ابزار را Paste کنید";minLines=8}
            android.app.AlertDialog.Builder(this).setTitle("وارد کردن بسته آفلاین").setView(input)
                .setNegativeButton("انصراف",null).setPositiveButton("وارد کردن"){_,_->
                    if(importToolPackage(input.text.toString())){toast("ابزار وارد شد.");showHome()}else toast("بسته ابزار معتبر نیست.")
                }.show()
        }
        btn(box,"📋 ابزارهای نصب‌شده") { showCustomToolList() }
        back(box);setContentView(box)
    }

    private fun testCode(language:String, code:String):String{
        if(code.isBlank()) return "❌ کد خالی است."
        val stack=ArrayDeque<Char>();var inSingle=false;var inDouble=false;var escaped=false
        for(ch in code){
            if(escaped){escaped=false;continue}
            if(ch=='\\' && (inSingle||inDouble)){escaped=true;continue}
            if(ch=='\'' && !inDouble){inSingle=!inSingle;continue}
            if(ch=='"' && !inSingle){inDouble=!inDouble;continue}
            if(inSingle||inDouble) continue
            when(ch){'(','[','{'->stack.addLast(ch);')',']','}'->{if(stack.isEmpty())return "❌ پرانتز/براکت بسته بدون بازشدن در کد پیدا شد.";val o=stack.removeLast();if((ch==')'&&o!='(')||(ch==']'&&o!='[')||(ch=='}'&&o!='{'))return "❌ جفت پرانتز/براکت‌ها ناسازگار است."}}
        }
        if(inSingle||inDouble)return "❌ رشته متنی بسته نشده است."
        if(stack.isNotEmpty())return "❌ بخشی از پرانتز/براکت‌ها بسته نشده است."
        val extra=when(language){
            "JSON"->try{JSONObject(code);null}catch(_:Exception){try{JSONArray(code);null}catch(_:Exception){"JSON معتبر نیست."}}
            "XML"->try{javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(org.xml.sax.InputSource(java.io.StringReader(code)));null}catch(_:Exception){"XML معتبر نیست."}
            else->null
        }
        return if(extra==null) "✅ تست ساختاری موفق بود. زبان: $language" else "❌ $extra"
    }

    private fun runCodeOffline(language:String, code:String){
        if(!testCode(language,code).startsWith("✅")){toast("کد ابتدا باید تست را با موفقیت بگذراند.");return}
        when(language){
            "HTML","CSS","JavaScript","TypeScript"->{
                val html=if(language=="HTML") code else if(language=="CSS") "<style>$code</style><body><h3>CSS preview</h3></body>" else "<html><body><pre id='out'></pre><script>$code</script></body></html>"
                val w=WebView(this).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;webViewClient=WebViewClient()}
                w.loadDataWithBaseURL(null,html,"text/html","UTF-8",null)
                android.app.AlertDialog.Builder(this).setTitle("▶️ اجرای آفلاین $language").setView(w).setPositiveButton("بستن",null).show()
            }
            "SQL"->{
                try{
                    val db=android.database.sqlite.SQLiteDatabase.create(null)
                    val statements=code.split(';').map{it.trim()}.filter{it.isNotBlank()};val out=StringBuilder()
                    for(st in statements){if(st.lowercase().startsWith("select")){val c=db.rawQuery(st,null);out.append("ستون‌ها: ").append(c.columnNames.joinToString()).append("\n");while(c.moveToNext())out.append((0 until c.columnCount).joinToString(" | "){c.getString(it)}).append("\n");c.close()}else db.execSQL(st)}
                    db.close();android.app.AlertDialog.Builder(this).setTitle("نتیجه SQL").setMessage(out.toString().ifBlank{"اجرای SQL با موفقیت انجام شد."}).setPositiveButton("بستن",null).show()
                }catch(e:Exception){toast("خطای SQL: ${e.message}")}
            }
            "JSON","XML","Markdown"->android.app.AlertDialog.Builder(this).setTitle("خروجی آفلاین").setMessage(code).setPositiveButton("بستن",null).show()
            else->toast("برای $language موتور اجرای واقعی داخل APK تعبیه نشده است؛ تست ساختاری و ذخیره/انتقال ابزار انجام شد.")
        }
    }

    private fun saveCustomTool(name:String,language:String,code:String){
        val arr=JSONArray(prefs.getString("custom_tools","[]"));arr.put(JSONObject().put("name",name).put("language",language).put("code",code));prefs.edit().putString("custom_tools",arr.toString()).apply()
    }

    private fun exportToolPackage(name:String,language:String,code:String):String = JSONObject().put("format","SecureStudioTool-1").put("name",name).put("language",language).put("code",code).toString()

    private fun importToolPackage(raw:String):Boolean = try{val o=JSONObject(raw);if(o.optString("format")!="SecureStudioTool-1")return false;val n=o.optString("name");val l=o.optString("language");val c=o.optString("code");if(n.isBlank()||c.isBlank())return false;if(!testCode(l,c).startsWith("✅"))return false;saveCustomTool(n,l,c);true}catch(_:Exception){false}

    private fun showCustomToolList(){
        val arr=JSONArray(prefs.getString("custom_tools","[]"));val box=page("📋 ابزارهای نصب‌شده")
        if(arr.length()==0)box.addView(TextView(this).apply{text="هنوز ابزار سفارشی نصب نشده است.";setTextColor(0xFFEAF7F4.toInt())})
        for(i in 0 until arr.length()){
            val o=arr.getJSONObject(i);val n=o.optString("name");val l=o.optString("language");val c=o.optString("code")
            btn(box,"🧩 $n — $l"){runCodeOffline(l,c)}
        }
        back(box);setContentView(box)
    }

    private fun showBrandingSettings(){
        val box=page("🎨 نام و لوگوی برنامه")
        box.addView(TextView(this).apply{
            text="از این بخش مدیر می‌تواند نام نمایشی برنامه و لوگوی داخل برنامه را تغییر دهد. تغییرات روی صفحه اصلی برنامه ذخیره می‌شود."
            setTextColor(0xFF9FCBC1.toInt()); setPadding(0,0,0,16)
        })
        val name=EditText(this).apply{
            hint="نام جدید برنامه"
            setText(prefs.getString("app_display_name","Secure Studio"))
        }
        btn(box,"💾 ذخیره نام برنامه"){
            val n=name.text.toString().trim()
            if(n.length in 2..40){prefs.edit().putString("app_display_name",n).apply();toast("نام برنامه تغییر کرد.");showHome()}
            else toast("نام برنامه باید بین ۲ تا ۴۰ کاراکتر باشد.")
        }
        btn(box,"🖼️ انتخاب لوگو از گالری"){
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
                type="image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            },PICK_LOGO)
        }
        btn(box,"↩️ بازگردانی نام و لوگوی پیش‌فرض"){
            prefs.edit().remove("app_display_name").remove("app_logo_uri").apply();toast("نام و لوگوی پیش‌فرض بازگردانده شد.");showHome()
        }
        back(box);setContentView(box)
    }


    private val PICK_MEDIA_IMAGE = 3001
    private val PICK_MEDIA_VIDEO = 3002
    private val PICK_MEDIA_AUDIO = 3003
    private var selectedMediaUri: Uri? = null
    private var selectedImageBitmap: Bitmap? = null
    private var audioPlayer: MediaPlayer? = null

    private fun showImageEditor(){
        val box=page("📸 ویرایشگر تصویر آفلاین")
        val preview=ImageView(this).apply{minimumHeight=260;scaleType=ImageView.ScaleType.CENTER_INSIDE;setBackgroundColor(0xFF17231F.toInt())}
        val info=TextView(this).apply{text="یک تصویر انتخاب کنید؛ عملیات اصلی کاملاً روی گوشی انجام می‌شود.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        var bitmap:Bitmap?=selectedImageBitmap
        btn(box,"📂 انتخاب تصویر"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_IMAGE)}
        btn(box,"↻ چرخش ۹۰ درجه"){bitmap?.let{val m=Matrix();m.postRotate(90f);bitmap=Bitmap.createBitmap(it,0,0,it.width,it.height,m,true);preview.setImageBitmap(bitmap)}?:toast("ابتدا تصویر را انتخاب کنید.")}
        btn(box,"⚫ سیاه‌وسفید"){bitmap?.let{val b=it.copy(Bitmap.Config.ARGB_8888,true);b.setHasAlpha(false);val c=ColorMatrix();c.setSaturation(0f);preview.colorFilter=ColorMatrixColorFilter(c);bitmap=b}?:toast("ابتدا تصویر را انتخاب کنید.")}
        btn(box,"💾 ذخیره تصویر"){bitmap?.let{saveBitmap(it);preview.clearColorFilter()}?:toast("ابتدا تصویر را انتخاب کنید.")}
        box.addView(info,1);box.addView(preview,2);back(box);setContentView(box)
        bitmap?.let { preview.setImageBitmap(it) }
    }

    private fun showVideoEditor(){
        val box=page("🎬 ابزار ویدیو آفلاین")
        val vv=VideoView(this).apply{setBackgroundColor(0xFF17231F.toInt())}
        val info=TextView(this).apply{text="انتخاب، پخش، توقف و مرور ویدیو روی خود دستگاه انجام می‌شود. برای ویرایش‌های سنگین مثل برش/افکت، موتور رسانه‌ای جداگانه در نسخه توسعه‌یافته لازم است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        btn(box,"📂 انتخاب ویدیو"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="video/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_VIDEO)}
        btn(box,"▶️ پخش"){if(vv.duration>0)vv.start()else toast("ابتدا ویدیو را انتخاب کنید.")}
        btn(box,"⏸ توقف"){vv.pause()}
        box.addView(info,1);box.addView(vv,2,LinearLayout.LayoutParams(-1,320));back(box);setContentView(box)
        selectedMediaUri?.let { try { vv.setVideoURI(it) } catch (_:Exception) { toast("ویدیو قابل پخش نیست.") } }
    }

    private fun showAudioEditor(){
        val box=page("🎵 ابزار صوت آفلاین")
        val status=TextView(this).apply{text="فایلی انتخاب نشده است.";setTextColor(0xFF9FCBC1.toInt());setPadding(0,8,0,12)}
        btn(box,"📂 انتخاب فایل صوتی"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE)},PICK_MEDIA_AUDIO)}
        btn(box,"▶️ پخش"){audioPlayer?.start()?:toast("ابتدا فایل صوتی را انتخاب کنید.")}
        btn(box,"⏸ توقف"){audioPlayer?.pause()?:toast("فایل صوتی انتخاب نشده است.")}
        btn(box,"⏹ توقف کامل"){audioPlayer?.stop();audioPlayer?.release();audioPlayer=null;status.text="پخش متوقف شد."}
        box.addView(status,1);back(box);setContentView(box)
    }

    private fun showTranslator(){
        val box=page("🌐 مترجم آفلاین پایه")
        val input=EditText(this).apply{hint="متن فارسی یا انگلیسی";minLines=5;gravity=48}
        val output=EditText(this).apply{hint="ترجمه آفلاین";minLines=5;gravity=48}
        btn(box,"🔄 ترجمه آفلاین"){output.setText(offlineTranslate(input.text.toString()))}
        btn(box,"📋 کپی ترجمه"){copyText(output.text.toString());toast("ترجمه کپی شد.")}
        box.addView(TextView(this).apply{text="این نسخه یک واژه‌نامه آفلاین پایه دارد و برای ترجمه کامل چندزبانه به موتور ترجمه نیاز است.";setTextColor(0xFF9FCBC1.toInt())},1)
        box.addView(input,2);box.addView(output,4);back(box);setContentView(box)
    }

    private fun offlineTranslate(t:String):String{
        val dict=mapOf("hello" to "سلام","hi" to "سلام","thanks" to "ممنون","thank you" to "متشکرم","yes" to "بله","no" to "خیر","good" to "خوب","bad" to "بد","سلام" to "hello","ممنون" to "thanks","بله" to "yes","خیر" to "no","خوب" to "good")
        return dict[t.trim().lowercase()] ?: "برای این عبارت، ترجمه آفلاین در واژه‌نامه فعلی موجود نیست."
    }

    private fun showVoiceTools(){
        val box=page("🎙️ ابزار صوت و گفتار")
        box.addView(TextView(this).apply{text="امکانات صوتی پایه آفلاین\n\n• تبدیل متن به گفتار با موتور داخلی Android\n• پخش و کنترل صوت\n\nتبدیل/کلون‌سازی صدای حرفه‌ای هنوز موتور اختصاصی می‌خواهد و در این نسخه به‌صورت محلی شبیه‌سازی نمی‌شود.";setTextColor(0xFFEAF7F4.toInt());setPadding(0,0,0,16)})
        val input=EditText(this).apply{hint="متن برای خواندن";minLines=4}
        btn(box,"🔊 خواندن متن با صدای دستگاه"){if(input.text.isBlank())toast("متن را وارد کنید.")else{lateinit var tts: android.speech.tts.TextToSpeech
tts = android.speech.tts.TextToSpeech(this){status->if(status==android.speech.tts.TextToSpeech.SUCCESS){tts.speak(input.text.toString(), android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "securestudio_tts")}};toast("در حال آماده‌سازی موتور گفتار...")}}
        box.addView(input,1);back(box);setContentView(box)
    }

    private val ttsLocaleHack: Unit get() = Unit

    private fun validAdminPassword(p:String):Boolean{val symbols=p.count{!it.isLetterOrDigit()};return p.length in 8..22&&symbols>=2}
    private fun changeSecurityQuestion(){
        val box=page("🛡️ تغییر سؤال امنیتی مدیر")
        val question = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf(
                "نام اولین مدرسه شما چه بود؟",
                "نام اولین شهر محل زندگی شما چه بود؟",
                "نام یک دوست دوران کودکی شما چه بود؟",
                "غذای مورد علاقه شما چیست؟"
            ))
            setSelection(prefs.getInt("security_question",0))
        }
        val answer=EditText(this).apply{hint="پاسخ جدید سؤال امنیتی"}
        btn(box,"💾 ذخیره سؤال امنیتی جدید"){
            val a=answer.text.toString().trim()
            if(a.length>=2){prefs.edit().putInt("security_question",question.selectedItemPosition).putString("security_answer",hash(a)).apply();toast("سؤال امنیتی تغییر کرد.");showAdminPanel()}
            else toast("پاسخ سؤال امنیتی را وارد کنید.")
        }
        box.addView(question);box.addView(answer);back(box);setContentView(box)
    }

    private fun changeAdminPassword(){
        val input=EditText(this).apply{hint="رمز جدید مدیر (8 تا 22 کاراکتر، حداقل 2 نماد)";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialogBuilder("🔄 تغییر رمز مدیر",input){val p=input.text.toString();if(validAdminPassword(p)){prefs.edit().putString("admin_password",hash(p)).apply();toast("رمز مدیر تغییر کرد.")}else toast("رمز شرایط لازم را ندارد.")}.show()
    }

    private fun setPin(){val input=EditText(this).apply{hint="PIN حداقل 6 رقم";inputType=2};AlertDialogBuilder("تنظیم PIN",input){val p=input.text.toString();if(p.length>=6){prefs.edit().putString("pin",hash(p)).apply();toast("PIN ذخیره شد.")}else toast("PIN باید حداقل 6 رقم باشد.")}.show()}
    private fun verifyPin(){val input=EditText(this).apply{hint="PIN";inputType=2};AlertDialogBuilder("باز کردن قفل",input){if(hash(input.text.toString())==prefs.getString("pin",null))toast("قفل باز شد.")else toast("PIN نادرست است.")}.show()}

    private fun copyText(value:String){
        val clip=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clip.setPrimaryClip(android.content.ClipData.newPlainText("SecureStudio",value))
    }

    private fun hash(s:String):String{val md=java.security.MessageDigest.getInstance("SHA-256");return Base64.getEncoder().encodeToString(md.digest(s.toByteArray(StandardCharsets.UTF_8)))}
    private fun encrypt(text:String):String{val key=getKey();val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key,GCMParameterSpec(128,nonce));return Base64.getEncoder().encodeToString(nonce+c.doFinal(text.toByteArray(StandardCharsets.UTF_8)))}
    private fun decrypt(encoded:String):String{val all=Base64.getDecoder().decode(encoded);require(all.size>12);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,getKey(),GCMParameterSpec(128,all.copyOfRange(0,12)));return String(c.doFinal(all.copyOfRange(12,all.size)),StandardCharsets.UTF_8)}
    private fun getKey():SecretKey{val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply{load(null)};if(ks.containsAlias("SecureStudioKey"))return(ks.getKey("SecureStudioKey",null) as SecretKey);val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");kg.init(KeyGenParameterSpec.Builder("SecureStudioKey",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return kg.generateKey()}
    private fun showExtracted(text:String){AlertDialogBuilder("پیام استخراج‌شده",TextView(this).apply{this.text=text;setTextColor(0xFFEAF7F4.toInt());setPadding(20,20,20,20)}){}.show()}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun AlertDialogBuilder(title:String,view:android.view.View,onOk:()->Unit):android.app.AlertDialog=android.app.AlertDialog.Builder(this).setTitle(title).setView(view).setNegativeButton("انصراف",null).setPositiveButton("تأیید"){_,_->onOk()}.create()
}
