package com.securestudio.v1

import android.content.Context
import android.os.SystemClock
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Entry gate (rewritten for V6).
 *
 * - No plaintext or XOR-obfuscated codes in the APK: only salted PBKDF2-HMAC-SHA256 hashes
 *   (see GateHashes.kt, produced by tools/make_hashes.py).
 * - The code is the exact key sequence typed on the calculator, ending with "=".
 * - Constant-time comparison.
 * - Persistent back-off after repeated wrong attempts (survives app restarts).
 * - Normal calculations never reach this class: it is only consulted when the expression is
 *   NOT a valid calculation and looks like a function-key sequence.
 */
object Gate {
    private const val PREFS = "gate_guard"          // separate from studio_state, never wiped
    private const val MAX_FREE_TRIES = 5
    private const val BASE_LOCK_MS = 30_000L
    private const val MAX_LOCK_MS = 15 * 60_000L

    fun looksLikeAttempt(expr: String): Boolean =
        expr.length >= 7 && (expr.startsWith("Sin") || expr.startsWith("Cos") ||
                expr.startsWith("Tan") || expr.startsWith("Cot"))

    /** @return role name ("ADMIN","A","M","S","TEMPORARY") or null. Blocking: call off the UI thread. */
    fun verify(ctx: Context, expr: String): String? {
        if (remainingLockMs(ctx) > 0) return null
        val typed = "$expr="
        val skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        var found: String? = null
        // Always test every entry so timing doesn't reveal which role was close.
        for (e in GateHashes.ENTRIES) {
            val h = skf.generateSecret(
                PBEKeySpec(typed.toCharArray(), unhex(e.salt), GateHashes.ITER, 256)
            ).encoded
            if (MessageDigest.isEqual(h, unhex(e.hash)) && found == null) found = e.role
        }
        if (found != null) reset(ctx) else fail(ctx)
        return found
    }

    fun remainingLockMs(ctx: Context): Long {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val until = p.getLong("until_wall", 0L)
        val now = System.currentTimeMillis()
        return if (until > now) until - now else 0L
    }

    private fun fail(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val n = p.getInt("fails", 0) + 1
        val e = p.edit().putInt("fails", n)
        if (n >= MAX_FREE_TRIES) {
            val steps = (n - MAX_FREE_TRIES).coerceAtMost(10)
            val lock = (BASE_LOCK_MS shl steps).coerceAtMost(MAX_LOCK_MS)
            e.putLong("until_wall", System.currentTimeMillis() + lock)
        }
        e.apply()
    }

    private fun reset(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    private fun unhex(s: String): ByteArray =
        ByteArray(s.length / 2) { ((Character.digit(s[it * 2], 16) shl 4) or Character.digit(s[it * 2 + 1], 16)).toByte() }
}
