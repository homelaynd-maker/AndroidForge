package com.securestudio.v1

import android.graphics.Bitmap
import java.io.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

object FileStego {
    private val MAGIC="SSFS3".toByteArray(Charsets.US_ASCII)
    private const val HEADER=5+1+8+32
    private const val BUFFER=64*1024
    fun capacity(bitmap: Bitmap): Long=(bitmap.width.toLong()*bitmap.height.toLong()*3L)/8L

    fun embed(bitmap: Bitmap, source: File, output: Bitmap): Bitmap {
        val need=HEADER+source.length(); require(need<=capacity(bitmap)){"ظرفیت تصویر کافی نیست. ظرفیت موجود: ${capacity(bitmap)} بایت؛ موردنیاز: $need بایت."}
        val hash=MessageDigest.getInstance("SHA-256")
        FileInputStream(source).use { input -> val b=ByteArray(BUFFER); while(true){val n=input.read(b); if(n<0)break; if(n>0)hash.update(b,0,n)} }
        val header=ByteBuffer.allocate(HEADER).order(ByteOrder.BIG_ENDIAN).put(MAGIC).put(1).putLong(source.length()).put(hash.digest()).array()
        FileInputStream(source).use { input ->
            var byteIndex=0; var bitIn=0; var total=0L
            fun nextBit():Int{
                if(total<header.size*8L){ val bit=(header[total.toInt()/8].toInt() ushr (7-(total.toInt()%8))) and 1; total++; return bit }
                if(bitIn==0){ byteIndex=input.read(); if(byteIndex<0) error("فایل رمزنگاری ناقص است.") }
                val bit=(byteIndex ushr (7-bitIn)) and 1; bitIn++; if(bitIn==8)bitIn=0; total++; return bit
            }
            loop@ for(y in 0 until output.height) for(x in 0 until output.width){
                val p=output.getPixel(x,y); var r=p ushr 16 and 255; var g=p ushr 8 and 255; var bl=p and 255
                if(total<need*8) r=(r and 0xFE) or nextBit()
                if(total<need*8) g=(g and 0xFE) or nextBit()
                if(total<need*8) bl=(bl and 0xFE) or nextBit()
                output.setPixel(x,y,(p and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or bl)
                if(total>=need*8) break@loop
            }
        }
        return output
    }

    fun extract(bitmap: Bitmap, destination: File): Long {
        require(capacity(bitmap)>=HEADER){"تصویر برای فایل کافی نیست."}
        val header=ByteArray(HEADER); readBytes(bitmap,0,header)
        require(header.copyOfRange(0,5).contentEquals(MAGIC)){"فایل داخل تصویر پیدا نشد."}
        require(header[5].toInt()==1){"نسخه فایل داخل تصویر پشتیبانی نمی‌شود."}
        val len=ByteBuffer.wrap(header,6,8).order(ByteOrder.BIG_ENDIAN).long
        require(len>=0 && HEADER+len<=capacity(bitmap)){"طول فایل داخل تصویر نامعتبر است."}
        val expected=header.copyOfRange(14,46); val hash=MessageDigest.getInstance("SHA-256")
        destination.parentFile?.mkdirs()
        FileOutputStream(destination).use { out ->
            val buf=ByteArray(BUFFER); var bufPos=0; var acc=0; var bits=0; var written=0L
            val start=HEADER*8L; val end=(HEADER+len)*8L
            var p=start
            while(p<end){ acc=(acc shl 1) or readBit(bitmap,p.toInt()); bits++; p++; if(bits==8){buf[bufPos++]=acc.toByte(); acc=0; bits=0; written++; if(bufPos==buf.size){out.write(buf);hash.update(buf);bufPos=0}} }
            if(bufPos>0){out.write(buf,0,bufPos);hash.update(buf,0,bufPos)}
            out.flush()
            require(MessageDigest.isEqual(expected,hash.digest())){"فایل داخل تصویر خراب یا دستکاری شده است."}
            return written
        }
    }
    private fun readBytes(bitmap:Bitmap,start:Int,out:ByteArray){ for(i in out.indices) for(b in 0 until 8) out[i]=(out[i].toInt() shl 1 or readBit(bitmap,start+i*8+b) ).toByte() }
    private fun readBit(bitmap:Bitmap,pos:Int):Int{val ch=pos%3;val pix=pos/3;val x=pix%bitmap.width;val y=pix/bitmap.width;val p=bitmap.getPixel(x,y);return when(ch){0->p ushr 16 and 1;1->p ushr 8 and 1;else->p and 1}}
}
