package com.securestudio.v1

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object Crypto {
    private const val STORE = "AndroidKeyStore"
    private const val ALIAS = "SecureStudio.Master.v2"
    private const val PREFIX = "SS2."
    private const val AAD = "SecureStudio/v2"
    private const val IV = 12

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(STORE).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, STORE)
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setKeySize(256)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .build())
        return kg.generateKey()
    }

    fun encrypt(text: String): String {
        val iv = ByteArray(IV).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(), GCMParameterSpec(128, iv))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        val body = cipher.doFinal(text.toByteArray(Charsets.UTF_8))
        return PREFIX + Base64.getEncoder().encodeToString(iv + body)
    }

    fun decrypt(value: String): String {
        require(value.startsWith(PREFIX)) { "قالب رمزنگاری معتبر نیست." }
        val packed = Base64.getDecoder().decode(value.removePrefix(PREFIX))
        require(packed.size > IV) { "داده رمزنگاری ناقص است." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, packed.copyOfRange(0, IV)))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        return String(cipher.doFinal(packed.copyOfRange(IV, packed.size)), Charsets.UTF_8)
    }
}
