package com.securestudio.v1

import android.app.Activity
import android.os.Bundle

object Security {
    fun secureWindow(activity: Activity){ activity.window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE) }
    fun clearLegacyState(activity: Activity){ activity.getSharedPreferences("secure_studio", Activity.MODE_PRIVATE).edit().clear().apply() }
}
