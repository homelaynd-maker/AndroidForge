package com.securestudio.v1

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import java.io.InputStream

object ImageCodec {
    fun decode(resolver: ContentResolver, uri: Uri): Bitmap {
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val source = ImageDecoder.createSource(resolver, uri)
                return ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    decoder.isMutableRequired = false
                }.copy(Bitmap.Config.ARGB_8888, false)
            } catch (_: Throwable) { }
        }
        resolver.openInputStream(uri)?.use { input ->
            return BitmapFactory.decodeStream(input)?.copy(Bitmap.Config.ARGB_8888, false)
                ?: error("فرمت تصویر توسط دستگاه قابل خواندن نیست.")
        } ?: error("تصویر قابل خواندن نیست.")
    }

    fun savePng(bitmap: Bitmap, resolver: ContentResolver, uri: Uri) {
        resolver.openOutputStream(uri)?.use { out ->
            check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "ذخیره PNG ناموفق بود." }
        } ?: error("فایل خروجی قابل نوشتن نیست.")
    }
}
