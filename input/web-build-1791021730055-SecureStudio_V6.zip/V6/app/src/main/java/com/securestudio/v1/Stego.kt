package com.securestudio.v1

import android.graphics.Bitmap
import java.nio.ByteBuffer
import java.nio.ByteOrder

object Stego {
    private val MAGIC = "SSTG3".toByteArray(Charsets.US_ASCII)
    private const val VERSION: Byte = 1
    private const val HEADER = 5 + 1 + 8

    fun capacity(bitmap: Bitmap): Long = (bitmap.width.toLong() * bitmap.height.toLong() * 3L) / 8L

    fun embed(bitmap: Bitmap, payload: ByteArray): Bitmap {
        require(payload.size.toLong() + HEADER <= capacity(bitmap)) { "ظرفیت تصویر کافی نیست." }
        val out = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val header = ByteBuffer.allocate(HEADER).order(ByteOrder.BIG_ENDIAN).put(MAGIC).put(VERSION).putLong(payload.size.toLong()).array()
        val data = header + payload
        var bit=0
        loop@ for(y in 0 until out.height) for(x in 0 until out.width){
            val p=out.getPixel(x,y); var r=p ushr 16 and 255; var g=p ushr 8 and 255; var b=p and 255
            if(bit < data.size*8){ r=(r and 0xFE) or ((data[bit/8].toInt() ushr (7-bit%8)) and 1); bit++ }
            if(bit < data.size*8){ g=(g and 0xFE) or ((data[bit/8].toInt() ushr (7-bit%8)) and 1); bit++ }
            if(bit < data.size*8){ b=(b and 0xFE) or ((data[bit/8].toInt() ushr (7-bit%8)) and 1); bit++ }
            out.setPixel(x,y,(p and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b)
            if(bit>=data.size*8) break@loop
        }
        return out
    }

    fun extract(bitmap: Bitmap): ByteArray {
        val cap=capacity(bitmap); require(cap>=HEADER){"تصویر کوچک است."}
        val header=read(bitmap,0,HEADER); require(header.copyOfRange(0,5).contentEquals(MAGIC)){"پیام Secure Studio در تصویر پیدا نشد."}; require(header[5]==VERSION){"نسخه استگانوگرافی پشتیبانی نمی‌شود."}
        val len=ByteBuffer.wrap(header,6,8).order(ByteOrder.BIG_ENDIAN).long; require(len>=0 && len+HEADER<=cap){"طول پیام نامعتبر است."}
        return read(bitmap,HEADER,len.toInt())
    }

    private fun read(bitmap: Bitmap,startByte:Int,len:Int):ByteArray{
        val out=ByteArray(len); val start=startByte*8; val end=start+len*8; var pos=start
        while(pos<end){ val bit=readBit(bitmap,pos); val i=(pos-start)/8; out[i]=(out[i].toInt() shl 1 or bit).toByte(); pos++ }
        return out
    }
    private fun readBit(bitmap: Bitmap,pos:Int):Int{ val ch=pos%3; val pix=pos/3; val x=pix%bitmap.width; val y=pix/bitmap.width; val p=bitmap.getPixel(x,y); return when(ch){0->p ushr 16 and 1;1->p ushr 8 and 1;else->p and 1} }
}
