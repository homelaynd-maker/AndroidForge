package com.securestudio.v1

import android.content.ContentResolver
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.*
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object FileCrypto {
    private const val STORE = "AndroidKeyStore"
    private const val ALIAS = "SecureStudio.File.v2"
    private const val MAGIC = "SSF2"
    private const val IV = 12
    private const val BUFFER = 64 * 1024
    private val aad = "SecureStudio/File/v2".toByteArray(Charsets.UTF_8)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(STORE).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, STORE)
        kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }

    fun encrypt(resolver: ContentResolver, source: Uri, destination: File) {
        destination.parentFile?.mkdirs()
        val iv = ByteArray(IV).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(), GCMParameterSpec(128, iv)); cipher.updateAAD(aad)
        resolver.openInputStream(source)?.use { input ->
            BufferedOutputStream(FileOutputStream(destination), BUFFER).use { raw ->
                raw.write(MAGIC.toByteArray(Charsets.US_ASCII)); raw.write(iv)
                CipherOutputStream(raw, cipher).use { out ->
                    val buf = ByteArray(BUFFER); while (true) { val n=input.read(buf); if(n<0) break; if(n>0) out.write(buf,0,n) }
                }
            }
        } ?: error("فایل ورودی قابل خواندن نیست.")
    }

    fun decrypt(resolver: ContentResolver, source: File, destination: Uri) {
        BufferedInputStream(FileInputStream(source), BUFFER).use { input ->
            val magic = ByteArray(4); readFully(input, magic)
            require(magic.contentEquals(MAGIC.toByteArray(Charsets.US_ASCII))) { "فایل رمزنگاری‌شده معتبر نیست." }
            val iv = ByteArray(IV); readFully(input, iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv)); cipher.updateAAD(aad)
            resolver.openOutputStream(destination)?.use { raw ->
                BufferedOutputStream(raw, BUFFER).use { out ->
                    CipherInputStream(input, cipher).use { dec ->
                        val buf=ByteArray(BUFFER); while(true){ val n=dec.read(buf); if(n<0) break; if(n>0) out.write(buf,0,n) }
                    }
                }
            } ?: error("فایل خروجی قابل نوشتن نیست.")
        }
    }
    private fun readFully(input: InputStream, out: ByteArray) { var p=0; while(p<out.size){ val n=input.read(out,p,out.size-p); require(n>=0){"فایل ناقص است."}; p+=n } }
}
