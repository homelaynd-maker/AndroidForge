# Calculator vault V6

- App opens straight to a plain calculator (no setup screen, no title/labels, launcher name "Calculator").
- Entry is in `Gate.kt` (new). Codes live only as salted PBKDF2 hashes in `GateHashes.kt`.
- Unlock: type the key sequence, then press `=`.
  ADMIN `Sin+-*/1151%1368=` | A `Tan/+-*%57=` | M `Cot*+%/-22=` | S `Cos+*%-/01=` | TEMP `Cos+%%0=`
- 5 wrong attempts -> lock 30s, doubling up to 15 min (persists across restarts).
- Change codes: write codes.json, run `python3 tools/make_hashes.py codes.json`, rebuild. Delete codes.json afterwards.
- Build: open in Android Studio, or `gradle assembleRelease` (needs Android SDK 35 + JDK 17).
- Same applicationId and Keystore aliases as DELTA, so installing over a DELTA build signed with the same key keeps old .ssf files readable.
