# Secure Studio release hardening
# Android manifest components are kept by R8 automatically.

# Strip common debug logging from release builds.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
}

# Keep cryptographic provider entry points used through reflection.
-keep class org.conscrypt.** { *; }

# R8 optimizes and obfuscates the application code; do not keep MainActivity wholesale.
