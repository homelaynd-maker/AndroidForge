package com.securestudio.v1

import android.graphics.Bitmap
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * Streams an already-encrypted file into an ARGB_8888 carrier image using RGB LSBs.
 * The encrypted payload itself is never materialized as one ByteArray.
 * Physical limits still apply: the encrypted file must fit the carrier's RGB-bit capacity.
 */
object FileImageSteganographyManager {
    private val MAGIC = "SSFSTG02".toByteArray(Charsets.US_ASCII)
    private const val VERSION: Byte = 1
    private const val HASH_BYTES = 32
    private const val HEADER_BYTES = 8 + 1 + 8 + HASH_BYTES

    data class Capacity(val availableBytes: Long, val requiredBytes: Long)

    fun capacity(bitmap: Bitmap, encryptedBytes: Long): Capacity {
        require(encryptedBytes >= 0) { "حجم فایل نامعتبر است." }
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        require(pixels > 0) { "ابعاد تصویر نامعتبر است." }
        val available = pixels * 3L / 8L
        val required = HEADER_BYTES.toLong() + encryptedBytes
        return Capacity(available, required)
    }

    fun embed(bitmap: Bitmap, openEncryptedStream: () -> InputStream, encryptedBytes: Long): Bitmap {
        val cap = capacity(bitmap, encryptedBytes)
        require(cap.requiredBytes <= cap.availableBytes) {
            "ظرفیت تصویر کافی نیست. ظرفیت لازم: ${cap.requiredBytes} بایت؛ ظرفیت موجود: ${cap.availableBytes} بایت."
        }
        val out = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val hash = MessageDigest.getInstance("SHA-256")
        val header = ByteBuffer.allocate(HEADER_BYTES).order(ByteOrder.BIG_ENDIAN)
            .put(MAGIC).put(VERSION).putLong(encryptedBytes)
            // Hash is filled after streaming below; reserve the bytes first.
            .put(ByteArray(HASH_BYTES)).array()

        // First pass computes the hash. The caller can provide a fresh/re-opened stream.
        val buffer = ByteArray(64 * 1024)
        openEncryptedStream().use { encryptedInput ->
            var remaining = encryptedBytes
            while (remaining > 0) {
                val n = encryptedInput.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                require(n > 0) { "فایل رمزنگاری‌شده ناقص است." }
                hash.update(buffer, 0, n)
                remaining -= n
            }
        }
        val digest = hash.digest()
        System.arraycopy(digest, 0, header, 17, HASH_BYTES)
        val reader = BitByteReader(openEncryptedStream(), encryptedBytes, header)
        var bitIndex = 0L
        val totalBits = cap.requiredBytes * 8L
        loop@ for (y in 0 until out.height) {
            for (x in 0 until out.width) {
                val p = out.getPixel(x, y)
                var r = (p ushr 16) and 0xFF
                var g = (p ushr 8) and 0xFF
                var b = p and 0xFF
                if (bitIndex < totalBits) r = (r and 0xFE) or reader.nextBit(bitIndex++)
                if (bitIndex < totalBits) g = (g and 0xFE) or reader.nextBit(bitIndex++)
                if (bitIndex < totalBits) b = (b and 0xFE) or reader.nextBit(bitIndex++)
                out.setPixel(x, y, (p and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b)
                if (bitIndex >= totalBits) break@loop
            }
        }
        reader.close()
        return out
    }

    fun extract(bitmap: Bitmap, output: OutputStream): Long {
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        val available = pixels * 3L / 8L
        require(available >= HEADER_BYTES) { "تصویر برای فایل رمزگذاری‌شده بسیار کوچک است." }
        val header = ByteArray(HEADER_BYTES)
        readBits(bitmap, header, 0L, HEADER_BYTES.toLong() * 8L)
        require(header.copyOfRange(0, 8).contentEquals(MAGIC)) { "هدر فایل Secure Studio پیدا نشد." }
        require(header[8] == VERSION) { "نسخه فایل داخل تصویر پشتیبانی نمی‌شود." }
        val length = ByteBuffer.wrap(header, 9, 8).order(ByteOrder.BIG_ENDIAN).long
        require(length >= 0 && HEADER_BYTES.toLong() + length <= available) { "طول فایل داخل تصویر نامعتبر است." }
        val expected = header.copyOfRange(17, 17 + HASH_BYTES)
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        var written = 0L
        var accumulator = 0
        var bits = 0
        for (bitPos in (HEADER_BYTES.toLong() * 8L) until ((HEADER_BYTES.toLong() + length) * 8L)) {
            val bit = readBitAt(bitmap, bitPos)
            accumulator = (accumulator shl 1) or bit
            bits++
            if (bits == 8) {
                if (written < length) {
                    buffer[(written % buffer.size).toInt()] = accumulator.toByte()
                    if ((written + 1) % buffer.size == 0L) {
                        output.write(buffer)
                        digest.update(buffer)
                    }
                    written++
                }
                accumulator = 0
                bits = 0
            }
        }
        val tail = (written % buffer.size).toInt()
        if (tail > 0) {
            output.write(buffer, 0, tail)
            digest.update(buffer, 0, tail)
        }
        output.flush()
        require(MessageDigest.isEqual(expected, digest.digest())) { "فایل داخل تصویر دستکاری یا خراب شده است." }
        return length
    }

    private fun readBits(bitmap: Bitmap, out: ByteArray, startBit: Long, count: Long) {
        for (i in 0 until count) {
            val bit = readBitAt(bitmap, startBit + i)
            val index = (i / 8).toInt()
            out[index] = ((out[index].toInt() shl 1) or bit).toByte()
        }
    }

    private fun readBitAt(bitmap: Bitmap, bitPosition: Long): Int {
        val channel = (bitPosition % 3L).toInt()
        val pixelIndex = bitPosition / 3L
        val x = (pixelIndex % bitmap.width.toLong()).toInt()
        val y = (pixelIndex / bitmap.width.toLong()).toInt()
        val p = bitmap.getPixel(x, y)
        return when (channel) {
            0 -> (p ushr 16) and 1
            1 -> (p ushr 8) and 1
            else -> p and 1
        }
    }

    private class BitByteReader(
        private val input: InputStream,
        private val payloadLength: Long,
        private val header: ByteArray
    ) : AutoCloseable {
        private var payloadByte = -1
        private var payloadBit = 8
        private var headerBit = 0
        private var payloadRead = 0L

        override fun close() {
            try { input.close() } catch (_: Exception) {}
        }

        fun nextBit(position: Long): Int {
            return if (position < HEADER_BYTES.toLong() * 8L) {
                val b = header[(position / 8L).toInt()].toInt() and 0xFF
                (b ushr (7 - (position % 8L).toInt())) and 1
            } else {
                if (payloadBit >= 8) {
                    require(payloadRead < payloadLength) { "فایل رمزنگاری‌شده ناقص است." }
                    payloadByte = input.read()
                    require(payloadByte >= 0) { "فایل رمزنگاری‌شده ناقص است." }
                    payloadRead++
                    payloadBit = 0
                }
                val bit = (payloadByte ushr (7 - payloadBit)) and 1
                payloadBit++
                bit
            }
        }
    }
}
