package com.securestudio.v1

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Debug
import java.io.File
import java.security.MessageDigest

/** Local, offline hardening checks. These are defense-in-depth, not a guarantee against a modified APK. */
object SecurityGuard {
    fun isReleaseLike(context: Context): Boolean =
        (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) == 0

    fun isDebuggerAttached(): Boolean = Debug.isDebuggerConnected() || Debug.waitingForDebugger()

    fun hasCommonRootArtifacts(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/data/adb/magisk", "/data/adb/ksu", "/system/app/Superuser.apk"
        )
        return paths.any { File(it).exists() }
    }

    /**
     * If a SHA-256 certificate fingerprint is supplied at build time, verify the installed APK.
     * Leave it unset for unsigned/debug development builds.
     */
    fun signatureMatches(context: Context, expectedHex: String): Boolean {
        if (expectedHex.isBlank()) return true
        return try {
            val pm = context.packageManager
            val pkg = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(context.packageName, android.content.pm.PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION") pm.getPackageInfo(context.packageName, 0)
            }
            val signatures = if (Build.VERSION.SDK_INT >= 28) {
                pkg.signingInfo.apkContentsSigners
            } else {
                @Suppress("DEPRECATION") pkg.signatures
            }
            signatures.any { cert ->
                val digest = MessageDigest.getInstance("SHA-256").digest(cert.toByteArray())
                digest.joinToString("") { b -> "%02X".format(b) }.equals(expectedHex.replace(":", "").trim(), true)
            }
        } catch (_: Throwable) { false }
    }
}
