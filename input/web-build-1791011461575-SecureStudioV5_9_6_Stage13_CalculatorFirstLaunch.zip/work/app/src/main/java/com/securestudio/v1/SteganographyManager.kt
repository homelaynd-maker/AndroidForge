package com.securestudio.v1

import android.graphics.Bitmap
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/**
 * Binary LSB container for already-encrypted Secure Studio payloads.
 * There is no artificial application-defined payload or pixel cap.
 * Physical limits still apply: a payload must fit in the selected carrier image and
 * Android/Java arrays and the device must have enough memory.
 * The carrier is written as PNG because lossy JPEG recompression destroys LSB data.
 */
object SteganographyManager {
    private val MAGIC = byteArrayOf('S'.code.toByte(), 'S'.code.toByte(), 'S'.code.toByte(), 'T'.code.toByte(), 'E'.code.toByte(), 'G'.code.toByte(), '0'.code.toByte(), '1'.code.toByte())
    private const val VERSION: Byte = 1
    private const val CHECKSUM_BYTES = 16
    private const val HEADER_BYTES = 8 + 1 + 4 + CHECKSUM_BYTES

    data class Capacity(val availableBytes: Long, val requiredBytes: Int)

    fun capacity(bitmap: Bitmap, encryptedPayloadBytes: Int): Capacity {
        require(encryptedPayloadBytes > 0) { "حجم پیام رمزنگاری‌شده باید بیشتر از صفر باشد." }
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        require(pixels > 0) { "ابعاد تصویر نامعتبر است." }
        val available = (pixels * 3L) / 8L
        val required = HEADER_BYTES.toLong() + encryptedPayloadBytes.toLong()
        require(required <= Int.MAX_VALUE) { "پیام برای ساخت یک payload واحد بیش از ظرفیت آرایه داده دستگاه است." }
        return Capacity(available, required.toInt())
    }

    fun embed(bitmap: Bitmap, encryptedPayload: ByteArray): Bitmap {
        require(encryptedPayload.isNotEmpty()) { "پیام رمزنگاری‌شده خالی است." }
        val envelope = pack(encryptedPayload)
        val cap = capacity(bitmap, encryptedPayload.size)
        require(envelope.size.toLong() <= cap.availableBytes) {
            "ظرفیت تصویر کافی نیست. یک تصویر بزرگ‌تر انتخاب کنید."
        }

        val out = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        var bitIndex = 0
        val totalBits = envelope.size * 8
        loop@ for (y in 0 until out.height) {
            for (x in 0 until out.width) {
                val p = out.getPixel(x, y)
                var r = (p ushr 16) and 0xFF
                var g = (p ushr 8) and 0xFF
                var b = p and 0xFF
                if (bitIndex < totalBits) r = setLsb(r, envelope, bitIndex++)
                if (bitIndex < totalBits) g = setLsb(g, envelope, bitIndex++)
                if (bitIndex < totalBits) b = setLsb(b, envelope, bitIndex++)
                out.setPixel(x, y, (p and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b)
                if (bitIndex >= totalBits) break@loop
            }
        }
        return out
    }

    fun extract(bitmap: Bitmap): ByteArray {
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        require(pixels > 0) { "ابعاد تصویر نامعتبر است." }
        val available = (pixels * 3L) / 8L
        require(available >= HEADER_BYTES) { "تصویر برای این قالب بسیار کوچک است." }

        val header = ByteArray(HEADER_BYTES)
        readBits(bitmap, header, 0, HEADER_BYTES * 8)
        validateHeader(header)
        val length = ByteBuffer.wrap(header, 9, 4).order(ByteOrder.BIG_ENDIAN).int
        require(length > 0) { "طول payload نامعتبر است." }
        require(HEADER_BYTES.toLong() + length.toLong() <= available) { "payload خارج از ظرفیت تصویر است." }

        val out = ByteArray(length)
        readBits(bitmap, out, HEADER_BYTES * 8, length * 8)
        val expectedHash = header.copyOfRange(13, 13 + CHECKSUM_BYTES)
        val actualHash = MessageDigest.getInstance("SHA-256").digest(out).copyOf(CHECKSUM_BYTES)
        require(MessageDigest.isEqual(expectedHash, actualHash)) { "checksum استگانوگرافی معتبر نیست." }
        return out
    }

    private fun pack(payload: ByteArray): ByteArray {
        val hash = MessageDigest.getInstance("SHA-256").digest(payload).copyOf(CHECKSUM_BYTES)
        return ByteBuffer.allocate(HEADER_BYTES + payload.size).order(ByteOrder.BIG_ENDIAN)
            .put(MAGIC)
            .put(VERSION)
            .putInt(payload.size)
            .put(hash)
            .put(payload)
            .array()
    }

    private fun validateHeader(header: ByteArray) {
        require(header.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) { "هدر Secure Studio پیدا نشد." }
        require(header[8] == VERSION) { "نسخه استگانوگرافی پشتیبانی نمی‌شود." }
    }

    private fun setLsb(value: Int, data: ByteArray, bitIndex: Int): Int {
        val byte = data[bitIndex ushr 3].toInt() and 0xFF
        val bit = (byte ushr (7 - (bitIndex and 7))) and 1
        return (value and 0xFE) or bit
    }

    private fun readBits(bitmap: Bitmap, out: ByteArray, startBit: Int, bitCount: Int) {
        var sourceBit = 0L
        val endBit = startBit.toLong() + bitCount.toLong()
        val totalBits = bitmap.width.toLong() * bitmap.height.toLong() * 3L
        require(endBit <= totalBits)
        for (y in 0 until bitmap.height) {
            for (x in 0 until bitmap.width) {
                val p = bitmap.getPixel(x, y)
                val channels = intArrayOf((p ushr 16) and 1, (p ushr 8) and 1, p and 1)
                for (channel in channels) {
                    if (sourceBit >= startBit.toLong() && sourceBit < endBit) {
                        val outIndex = ((sourceBit - startBit.toLong()) ushr 3).toInt()
                        out[outIndex] = ((out[outIndex].toInt() shl 1) or channel).toByte()
                    }
                    sourceBit++
                    if (sourceBit >= endBit) return
                }
            }
        }
    }
}
