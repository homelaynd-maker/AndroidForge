package com.securestudio.v1

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Offline AES-GCM encryption backed by Android Keystore. No application-defined message-size cap. */
object OfflineCryptoManager {
    private const val KEYSTORE = "AndroidKeyStore"
    private const val ALIAS = "SecureStudio.Text.v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val PREFIX = "SS1."
    private const val AAD = "SecureStudio/OfflineText/v1"
    private const val IV_BYTES = 12

    private fun key(): SecretKey {
        val store = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key(), GCMParameterSpec(128, ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        val body = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val packed = ByteArray(IV_BYTES + body.size)
        System.arraycopy(cipher.iv, 0, packed, 0, IV_BYTES)
        System.arraycopy(body, 0, packed, IV_BYTES, body.size)
        return PREFIX + Base64.getEncoder().encodeToString(packed)
    }

    fun decrypt(encoded: String): String {
        require(encoded.startsWith(PREFIX)) { "قالب رمزنگاری پشتیبانی نمی‌شود." }
        val packed = Base64.getDecoder().decode(encoded.removePrefix(PREFIX))
        require(packed.size > IV_BYTES) { "داده رمزنگاری‌شده ناقص است." }
        val iv = packed.copyOfRange(0, IV_BYTES)
        val body = packed.copyOfRange(IV_BYTES, packed.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        return String(cipher.doFinal(body), Charsets.UTF_8)
    }
}
