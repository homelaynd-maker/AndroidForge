package com.securestudio.v1

import android.content.ContentResolver
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Offline streaming file encryption. No application-defined file-size limit.
 * Format: SSF1 | 12-byte IV | AES-GCM ciphertext+tag.
 * The Android Keystore key intentionally makes files device-bound.
 */
object FileCryptoManager {
    private const val KEYSTORE = "AndroidKeyStore"
    private const val ALIAS = "SecureStudio.File.v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val AAD = "SecureStudio/OfflineFile/v1"
    private const val MAGIC = "SSF1"
    private const val IV_BYTES = 12
    private const val BUFFER = 64 * 1024

    private fun key(): SecretKey {
        val store = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return generator.generateKey()
    }

    fun encrypt(resolver: ContentResolver, source: Uri, destination: Uri) {
        val iv = ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(TRANSFORMATION).apply {
            init(Cipher.ENCRYPT_MODE, key(), GCMParameterSpec(128, iv))
            updateAAD(AAD.toByteArray(Charsets.UTF_8))
        }
        resolver.openInputStream(source)?.use { input ->
            resolver.openOutputStream(destination)?.use { output ->
                BufferedOutputStream(output, BUFFER).use { buffered ->
                    buffered.write(MAGIC.toByteArray(Charsets.US_ASCII))
                    buffered.write(iv)
                    CipherOutputStream(buffered, cipher).use { encrypted ->
                        val buffer = ByteArray(BUFFER)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            if (n > 0) encrypted.write(buffer, 0, n)
                        }
                    }
                }
            } ?: error("فایل خروجی قابل نوشتن نیست.")
        } ?: error("فایل ورودی قابل خواندن نیست.")
    }

    fun decrypt(resolver: ContentResolver, source: Uri, destination: Uri) {
        resolver.openInputStream(source)?.use { raw ->
            val input = BufferedInputStream(raw, BUFFER)
            val magic = ByteArray(MAGIC.length)
            readFully(input, magic)
            require(magic.contentEquals(MAGIC.toByteArray(Charsets.US_ASCII))) { "قالب فایل Secure Studio معتبر نیست." }
            val iv = ByteArray(IV_BYTES)
            readFully(input, iv)
            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
                updateAAD(AAD.toByteArray(Charsets.UTF_8))
            }
            resolver.openOutputStream(destination)?.use { output ->
                BufferedOutputStream(output, BUFFER).use { buffered ->
                    CipherInputStream(input, cipher).use { decrypted ->
                        val buffer = ByteArray(BUFFER)
                        while (true) {
                            val n = decrypted.read(buffer)
                            if (n < 0) break
                            if (n > 0) buffered.write(buffer, 0, n)
                        }
                    }
                }
            } ?: error("فایل خروجی قابل نوشتن نیست.")
        } ?: error("فایل ورودی قابل خواندن نیست.")
    }

    private fun readFully(input: java.io.InputStream, target: ByteArray) {
        var offset = 0
        while (offset < target.size) {
            val n = input.read(target, offset, target.size - offset)
            require(n >= 0) { "فایل ناقص است." }
            offset += n
        }
    }
    fun encryptToFile(resolver: ContentResolver, source: Uri, destination: java.io.File) {
        destination.parentFile?.mkdirs()
        val iv = ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(TRANSFORMATION).apply {
            init(Cipher.ENCRYPT_MODE, key(), GCMParameterSpec(128, iv))
            updateAAD(AAD.toByteArray(Charsets.UTF_8))
        }
        resolver.openInputStream(source)?.use { input ->
            java.io.BufferedOutputStream(java.io.FileOutputStream(destination), BUFFER).use { out ->
                out.write(MAGIC.toByteArray(Charsets.US_ASCII)); out.write(iv)
                CipherOutputStream(out, cipher).use { encrypted ->
                    val buffer = ByteArray(BUFFER)
                    while (true) { val n=input.read(buffer); if(n<0) break; if(n>0) encrypted.write(buffer,0,n) }
                }
            }
        } ?: error("فایل ورودی قابل خواندن نیست.")
    }

    fun decryptFromFile(source: java.io.File, resolver: ContentResolver, destination: Uri) {
        java.io.BufferedInputStream(java.io.FileInputStream(source), BUFFER).use { input ->
            val magic = ByteArray(MAGIC.length); readFully(input, magic)
            require(magic.contentEquals(MAGIC.toByteArray(Charsets.US_ASCII))) { "قالب فایل Secure Studio معتبر نیست." }
            val iv = ByteArray(IV_BYTES); readFully(input, iv)
            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
                updateAAD(AAD.toByteArray(Charsets.UTF_8))
            }
            resolver.openOutputStream(destination)?.use { raw ->
                BufferedOutputStream(raw, BUFFER).use { out ->
                    CipherInputStream(input, cipher).use { decrypted ->
                        val buffer=ByteArray(BUFFER)
                        while(true){ val n=decrypted.read(buffer); if(n<0) break; if(n>0) out.write(buffer,0,n) }
                    }
                }
            } ?: error("فایل خروجی قابل نوشتن نیست.")
        }
    }

}
